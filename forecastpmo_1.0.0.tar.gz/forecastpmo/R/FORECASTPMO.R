#' FORECASTPMO 1.0: Load forecasting for PMO
#' @param dirinput directory containing the data files in CSV format or the name of the data.frame in the R environment.
#' @param dirout directory where the CSV files containing the load forecasts will be saved.
#' @param modelo model number (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11),
#' @param tipoinput 0 for data stored in a CSV file, 1 for data stored in an R data.frame.
#' @param tipotemp temperature data
#' \itemize{
#'   \item  `0`: for the week's maximum temperature
#'   \item  `1`: for the week's average temperature
#'   \item  `2`: for both average and maximum weekly temperatures
#'   \item  `3`: without temperature (default)
#' }
#' @param tipoestudo 0 for PMO revision, 1 for PMO (REV0)
#' @param conciliar selects the method used to reconcile the weekly forecasts with the monthly forecast for the first month
#' \itemize{
#'    \item  `0`: for the simplified method
#'    \item  `1`: for the MinT method
#'    \item  `2`: for the monthly forecast adjustment
#' }
#' @param nharm number of harmonic components in the dynamic regression model for weekly load forecasting, default value is 3.
#' @param pandemia 1 to account for the impact of the pandemic on load during the period from March to August 2020, 0 not to account for this effect (default)
#' @param grafico 1 to display the ACF, PACF, and histogram, and generate CSV files containing the forecasts; 0 not to display these plots or generate files (default)
#' @param hparmes can be either the vector of orders p,d,q,P,D,Q for the SARIMA modeling of the random term in the dynamic regression, the vector of orders p,d,q,P,D,Q for the SARIMA modeling of monthly load, or the load lags considered by the SVM for monthly load forecasting, the default option is automatic selection
#' @param hparsem1 orders p,d,q,P,D,Q for the SARIMA modeling of the random term in the dynamic regression fitted to forecast load for the first operating week of the forecast horizon, or the lags of the SVM model for weekly load forecasting, the default option is automatic selection
#' @param hparsem2 orders p,d,q,P,D,Q for the SARIMA modeling of the random term in the dynamic regression fitted to forecast load from the second operating week onward in the forecast horizon, the default option is automatic selection
#'
#' @return weekly and monthly load forecasts
#'
#' @author
#' Jose Pessanha
#
#' @export
previsorpmo<-function(dirinput,dirout,modelo,tipoinput,tipotemp=3,tipoestudo,conciliar,nharm=3,pandemia=0,grafico=0,hparmes=rep(NA,6),hparsem1=rep(NA,6),hparsem2=rep(NA,6)){
# dirinput = path dos dados e saida iu nome do datagrame com dados
# dirout = pasta onde serao gravados os arquivos resultados
# modelo = 0 SVM na previsao semanal e mensal
#          1 SVM na previsao semanal e HW na previsao mensal
#          2 SVM na previsao semanal e regressao dinamica na previsao mensal
#          3 SVM na previsao semanal e SARIMA na previsao mensal
#          4 regressao dinamica na previsao semanal e SVM na previsao mensal
#          5 regressao dinamica na previsao semanal e HW na previsao mensal
#          6 regressao dinamica na previsao semanal e mensal
#          7 regressao dinamica na previsao semanal e SARIMA na previsao mensal
#          8 HW na previsao semanal e SVM na previsao mensal
#          9 HW na previsao semanal e HW na previsao mensal
#          10 HW na previsao semanal e mensal
#          11 HW na previsao semanal e SARIMA na previsao mensal
# tipoinput = 0 importa arquivos csv
#             1 importa data.frame
# tipotemp  = 0 temperatura maxima da semana arquivo com dados horarios
#             1 temperatura media da semana arquivo com dados horarios
#             2 temperaturas media e maxima da semana arquivo com dados horarios
#             3 sem temperatura
#             4 arquivo de temperatura com dados diarios
# tipoestudo = 0 revisao semanal do PMO
#              1 PMO (REV0)
# pandemia = 1 # trata efeito da pandemia
#          = 0 # nao trata efeito da pandemia
# nharm usa 2*nharm componentes harmonicas na regressao dinamica semanal (fourier(K=nharm))
# grafico = 0 nao grava arquivos CSV com resultados
#         1 grava arquivos CSV com resultados
# conciliar = 0 se REV0 ajusta as previsoes semanais e mantem a previsao mensal , se demais revisoes atualiza a previsao mensal
#             1 faz conciliacao das previsoes semanais e mensais pelo metodo MINT
#             2 se REV0 a previsao mensal = media das previsoes semanais
# hparmes = hiperparametros do SARIMA e dos erros no modelo mensal / lags do SVM
# hparsem1 = hiperparametros do modelo do erro da regressao dinamica para a primeira semana / lags do SVM
# hparsem2 = hiperparametros do modelo do erro da regressao dinamica para as demais semanas

library(e1071) # pacote com rotinas para o SVM
library(forecast)
library(fpp3)
library(tsibble)
library(stringr)
library(bizdays)
library(janitor)
options("scipen"=100)

# renomeia variaveis de entrada
caminho=dirinput
extra=grafico
diretorioarquivosmodelo=dirout
if (modelo<0 & modelo>7) modelo=6
tipomodelo=modelo
desagrega=conciliar
if (tipomodelo<=3) weekmodel="SVM"
if (tipomodelo>3 & tipomodelo<=7) weekmodel="MRD"
if (tipomodelo>7) weekmodel="MHW"
if (tipomodelo==0 | tipomodelo==4 | tipomodelo==8) monthmodel="SVM"
if (tipomodelo==1 | tipomodelo==5 | tipomodelo==9) monthmodel="MHW"
if (tipomodelo==2 | tipomodelo==6 | tipomodelo==10) monthmodel="MRD"
if (tipomodelo==3 | tipomodelo==7 | tipomodelo==11) monthmodel="MBJ"
if (extra!=0 & extra!=1) extra=1
if (desagrega!=0 & desagrega!=1 & desagrega!=2) desagrega=0
if (tipotemp>=4) tipotemp=3
if (nharm>26) nharm=25 # K must be not be greater than period/2
if (nharm<=0) nharm=3
maximosemNA<<-function(X){max(X,na.rm=T)}
minimosemNA<<-function(X){min(X,na.rm=T)}
mediasemNA<<-function(X){mean(X,na.rm=T)}
somasemNA<<-function(X){sum(X,na.rm=T)}
medianasemNA<<-function(X){quantile(X,prob=0.5,na.rm=T)}
imprime_opcoes(tipoestudo,tipomodelo,weekmodel,monthmodel,tipoinput,tipotemp,nharm)

#===========================
# CHAMADA DA ROTINA LEITORA
#===========================
if (tipoinput==0) {
    if (dir.exists(caminho)) {
       arquivo="parametros.csv" # arquivo com parametros de execucao
       DADOS=LEITORA(caminho,arquivo,tipotemp) # leitura arquivo de dados em formato csv
    } else {
       stop("O diretorio informado em previsorpmo nao existe - Execucao cancelada")
    }
    if(file.exists(diretorioarquivosmodelo)==F) dir.create(diretorioarquivosmodelo)
} else {
    dataframes=caminho
    if (exists("dataframes")) {
       if(file.exists(diretorioarquivosmodelo)==F) dir.create(diretorioarquivosmodelo)
       DADOS=LEITORADATAFRAME(dataframes,tipotemp) # leitura de dados no formato data.frame
    } else {
       stop("O data.frame informado em previsorpmo nao existe - Execucao cancelada")
    }
}

datasprev=rownames(DADOS$DATAPREV) # PEGA DATAS DOS DIAS DO PERIODO PREVISAO
numdiasprev=length(datasprev) # numero de dias de previsao
separadordec=DADOS$separador
perfis=DADOS$DATAHIST
seriecarga=DADOS$SERIEHIST[,1]
seriediaria=DADOS$SERIEHIST # media diaria
#lags=c(1,7)

# se feriado_no_horizonte > 0 tem feriado no horizonte entao a previsao mensal e dada pela media das previsoes semanais
feriado_no_horizonte=sum(as.numeric(DADOS$DATAPREV$x_feriados_prev)) # se > 0 indica feriado no horizonte de previsao

#============================================================================================================================
# CALCULA PREVISAO DIARIA, A BASE PARA O FATOR DE PARTICIPACAO DO DIA NA SEMANA E DESAGREGAR MES EM SEMANAS E SEMANAS EM DIAS
#============================================================================================================================
#previsao.diaria=PREVDIA(DADOS,tipotemp,extra) # previsao calculada por regressao dinamica

#=================
# PREVISAO SEMANAL
#=================
# PREVISOES SEMANAIS POR SVM
SERIES_SEMANAIS=MONTASEMANAS(datasprev,DADOS) # MONTA SERIES SEMANAIS PARA PREVISAO POR SVM
previsaosemanacorrente=tail(SERIES_SEMANAIS$DADOS_SEMANAIS$carga.media.semanal,1)
datasemanacorrenteinic=tail(SERIES_SEMANAIS$data.inic.semana,1)
datasemanacorrentefim=tail(SERIES_SEMANAIS$data.fim.semana,1)

if (weekmodel=="SVM") print("================ PREVISAO DA CARGA SEMANAL COM SVM ===============")
PREVISOES_SEMANAIS<-PREVSEMANAL(SERIES_SEMANAIS,DADOS,tipotemp,diretorioarquivosmodelo,weekmodel,hparsem1,hparsem2) # FAZ A PREVISAO

if (weekmodel=="SVM") {
   # mostra graficos apenas se a regressao dinamica nao faz a previsao semanal
   if (extra==1){
      windows()
      par(mfrow=c(2,2))
      plot(PREVISOES_SEMANAIS$OBSERVADO,main="SVM fitted to weekly data",xlab="weeks",ylab="MW")
      lines(PREVISOES_SEMANAIS$ESTIMADO,col="blue")
      acf((PREVISOES_SEMANAIS$OBSERVADO-PREVISOES_SEMANAIS$ESTIMADO),main="ACF weekly residuals")
      pacf((PREVISOES_SEMANAIS$OBSERVADO-PREVISOES_SEMANAIS$ESTIMADO),main="PACF weekly residuals")
      hist((PREVISOES_SEMANAIS$OBSERVADO-PREVISOES_SEMANAIS$ESTIMADO),main="histogram of residuals",xlab="residuals")
   }
   METRICASINSAMPLE_SEMANAL=c(PREVISOES_SEMANAIS$MAD,PREVISOES_SEMANAIS$MAPE,PREVISOES_SEMANAIS$RMSE,PREVISOES_SEMANAIS$UTHEIL)
}

if (weekmodel=="MRD"){ # FAZENDO AQUI MUDA A PREVISAO MENSAL DE HOLT WINTERS QUANDO SVM OU REGRESSAO DINAMICA
   # PREVISAO SEMANAL POR MODELOS DE REGRESSAO DINAMICA
   print("======== PREVISAO DA CARGA SEMANAL COM REGRESSAO DINAMICA ========")
   previsao.semanal.REGDIN=PREVSEMREGDIN(DADOS,tipotemp,nharm,extra,diretorioarquivosmodelo,hparsem1) # previsao primeira semana
   METRICASINSAMPLE_SEMANAL=c(previsao.semanal.REGDIN$MAD,previsao.semanal.REGDIN$MAPE,previsao.semanal.REGDIN$RMSE,previsao.semanal.REGDIN$UTHEIL)
   previsao.semanal.REGDIN2=PREVSEMREGDIN2(DADOS,tipotemp,nharm,extra,diretorioarquivosmodelo,hparsem2) # previsao demais semanas
   previsao.semanal.REGDIN2$PREVISOES_SEMANAIS[1]=previsao.semanal.REGDIN$PREVISOES_SEMANAIS[1]
   previsao.semanal.REGDIN$PREVISOES_SEMANAIS=previsao.semanal.REGDIN2$PREVISOES_SEMANAIS
   rm(previsao.semanal.REGDIN2)
   # substitui previsoes semanais SVM pelas previsoes semanais da regressao dinamica
   PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes[1:length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)]=previsao.semanal.REGDIN$PREVISOES_SEMANAIS[1:length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)]
   indice00=which(names(PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$serie.semanal.completa)=="1")
   PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$serie.semanal.completa[indice00]=previsao.semanal.REGDIN$PREVISOES_SEMANAIS[1:length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)]
}

if (weekmodel=="MHW"){
   # PREVISAO SEMANAL POR MODELOS HW
   print("======== PREVISAO DA CARGA SEMANAL COM HOLT WINTERS ========")
   previsao.semanal.HW=PREVSEMHW(DADOS,tipotemp,nharm,extra,diretorioarquivosmodelo,hparsem1)
   METRICASINSAMPLE_SEMANAL=c(previsao.semanal.HW$MAD,previsao.semanal.HW$MAPE,previsao.semanal.HW$RMSE,previsao.semanal.HW$UTHEIL)
   # substitui previsoes semanais SVM pelas previsoes HW
   PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes[1:length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)]=previsao.semanal.HW$PREVISOES_SEMANAIS[1:length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)]
   indice00=which(names(PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$serie.semanal.completa)=="1")
   PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$serie.semanal.completa[indice00]=previsao.semanal.HW$PREVISOES_SEMANAIS[1:length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)]
}
PREVISOES_SEMANAIS_ANTES=PREVISOES_SEMANAIS[-3] # remove HW que ha no SVM
PREVISOES_SEMANAIS_ANTES=PREVISOES_SEMANAIS_ANTES[-3] # remove HW que ha no SVM
names(PREVISOES_SEMANAIS_ANTES$PREV.SEMANAIS$previsoes)=PREVISOES_SEMANAIS_ANTES$PREV.SEMANAIS$datas.fim.semanas[1:length(PREVISOES_SEMANAIS_ANTES$PREV.SEMANAIS$previsoes)]

#================
# PREVISAO MENSAL
#================
# MONTA SERIES MENSAIS PARA PREVISAO POR SVM
SERIES_MENSAIS=MONTAMES(PREVISOES_SEMANAIS,DADOS)
# previsao do mes corrente (apenas para o caso de revisao do PMO, neste caso o mes corrente ainda nao se encerrou)
nomesmeses=c("janeiro","fevereiro","marco","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro")
numeromescorrente=as.numeric(substr(tail(names(SERIES_MENSAIS$total.dias.mes),1),6,7)) # mes corrente
numeroanocorrente=as.numeric(substr(tail(names(SERIES_MENSAIS$total.dias.mes),1),1,4)) # ano corrente
retira_ultimo_mes=0
if (tipoestudo==1) {
    # REV0 PMO
    if (tail(SERIES_MENSAIS$total.dias.mes,1)<=6) {
	     numeromescorrente = numeromescorrente-1 # retira o ultimo mes da serie
		   retira_ultimo_mes=1
		   if (numeromescorrente==0) {
		       numeromescorrente=12
			     numeroanocorrente=numeroanocorrente-1 # reduz um ano
		   }
		   SERIES_MENSAIS$total.dias.mes=SERIES_MENSAIS$total.dias.mes[-length(SERIES_MENSAIS$total.dias.mes)]
  	   SERIES_MENSAIS$total.feriados.mes=SERIES_MENSAIS$total.feriados.mes[-length(SERIES_MENSAIS$total.feriados.mes)]
       SERIES_MENSAIS$total.weekends.mes=SERIES_MENSAIS$total.weekends.mes[-length(SERIES_MENSAIS$total.weekends.mes)]
		   SERIES_MENSAIS$serie.mensal.real=SERIES_MENSAIS$serie.mensal.real[-length(SERIES_MENSAIS$serie.mensal.real)]
	  }
	  if(tail(SERIES_MENSAIS$total.dias.mes,1)<=6 | tail(SERIES_MENSAIS$total.dias.mes,1)>=20) {
	     nomescorrente=nomesmeses[numeromescorrente]
       cargaglobalcorrente=SERIES_MENSAIS$serie.mensal.real[length(SERIES_MENSAIS$serie.mensal.real)] # carga global nos dias do mes corrente
       names(cargaglobalcorrente)=paste(nomescorrente,"/",numeroanocorrente,sep="")
    } else {
	     tipoestudo=0 # nuda de REV0 para revisao semanal do PMO
	     cargaglobalcorrente=-1 # indica que nao se trata de REV0 e nao mostra a carga do mes corrente
       print("mensagem: PMO com menos de 20 dias do mes corrente, deveria ser revisao do PMO")
   	   print("          tipo de estudo alterado para revisao PMO")
	  }
} else {
    cargaglobalcorrente=-1 # indica que nao se trata de REV0 e nao mostra a carga do mes corrente
}
#if (tipomodelo!=0){ # FAZENDO AQUI NAO MUDA A PREVISAO MENSAL DE HOLT WINTERS QUANDO SVM OU REGRESSAO DINAMICA
#   # substitui previsoes semanais SVM pelas previsoes semanais da regressao dinamica
#   PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes[1:length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)]=previsao.semanal.REGDIN$PREVISOES_SEMANAIS[1:length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)]
#   indice00=which(names(PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$serie.semanal.completa)=="1")
#   PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$serie.semanal.completa[indice00]=previsao.semanal.REGDIN$PREVISOES_SEMANAIS[1:length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)]
#}
if (monthmodel=="SVM") print("================ PREVISAO DA CARGA MENSAL COM SVM ===============")
PREVISOES_MENSAIS<-PREVMENSAL(SERIES_MENSAIS,DADOS,tipoestudo,diretorioarquivosmodelo,monthmodel,hparmes,pandemia) # COM SVM
if (monthmodel=="SVM"){
   # mostra grafico apenas se previsao mensal feita por SVM
   if (extra==1){
      windows()
      par(mfrow=c(2,2))
      plot(PREVISOES_MENSAIS$DADOS[,1],main="SVM fitted to monthly data",xlab="months",ylab="MW")
      lines(PREVISOES_MENSAIS$DADOS[,2],col="blue")
      acf((PREVISOES_MENSAIS$DADOS[,1]-PREVISOES_MENSAIS$DADOS[,2]),main="ACF monthly residuals")
      pacf((PREVISOES_MENSAIS$DADOS[,1]-PREVISOES_MENSAIS$DADOS[,2]),main="PACF monthly residuals")
      hist((PREVISOES_MENSAIS$DADOS[,1]-PREVISOES_MENSAIS$DADOS[,2]),main="histogram of residuals",xlab="residuals")
   }
   METRICASINSAMPLE_MENSAL=c(PREVISOES_MENSAIS$MAD,PREVISOES_MENSAIS$MAPE,PREVISOES_MENSAIS$RMSE,PREVISOES_MENSAIS$UTHEIL)
}

if (monthmodel!="SVM"){
   # previsao mensal por regressao dinamica, HW ou SARIMA
   if (monthmodel=="MHW") {
       print("=========== PREVISAO DA CARGA MENSAL COM HOLT-WINTERS ===========")
       PREVISOES_HW=PREVMESHW(DADOS,extra,diretorioarquivosmodelo,tipoestudo,retira_ultimo_mes,pandemia) # PREVISAO DA CARGA MENSAL COM HOLT-WINTERS
	     METRICASINSAMPLE_MENSAL=c(PREVISOES_HW$MAD,PREVISOES_HW$MAPE,PREVISOES_HW$RMSE,PREVISOES_HW$UTHEIL)
   }
   if (monthmodel=="MRD") {
       # PREVISAO DA CARGA MENSAL COM REGRESSAO DINAMICA
       print("=========== PREVISAO DA CARGA MENSAL COM REG.DINAMICA ===========")
       if (tipoestudo==0){
	        # nao REV0
          previsao.mensal.REGDIN=PREVMESREGDIN(DADOS,1,extra,diretorioarquivosmodelo,hparmes,retira_ultimo_mes,pandemia) # previsao para o mes corrente
      	  METRICASINSAMPLE_MENSAL=c(previsao.mensal.REGDIN$MAD,previsao.mensal.REGDIN$MAPE,previsao.mensal.REGDIN$RMSE,previsao.mensal.REGDIN$UTHEIL)
          previsao.mensal.REGDIN.base=previsao.mensal.REGDIN$PREVISOES_MENSAIS # previsao para o mes corrente
          previsao.mensal.REGDIN=PREVMESREGDIN(DADOS,-1,extra,diretorioarquivosmodelo,hparmes,retira_ultimo_mes,pandemia) # previsoes para o mes corrente e demais meses
          previsao.mensal.REGDIN$PREVISOES_MENSAIS=previsao.mensal.REGDIN.base*previsao.mensal.REGDIN$PREVISOES_MENSAIS/previsao.mensal.REGDIN$PREVISOES_MENSAIS[1] # previsoes corrigidas
       } else {
	        # REV0
          previsao.mensal.REGDIN=PREVMESREGDIN(DADOS,0,extra,diretorioarquivosmodelo,hparmes,retira_ultimo_mes,pandemia)
    	    METRICASINSAMPLE_MENSAL=c(previsao.mensal.REGDIN$MAD,previsao.mensal.REGDIN$MAPE,previsao.mensal.REGDIN$RMSE,previsao.mensal.REGDIN$UTHEIL)
       }
   }
   if (monthmodel=="MBJ") {
       print("=========== PREVISAO DA CARGA MENSAL COM BOX & JENKINS ==========")
       PREVISOES_SARIMA=PREVMESSARIMA(DADOS,hparmes,extra,diretorioarquivosmodelo,tipoestudo,retira_ultimo_mes,pandemia) # PREVISAO DA CARGA MENSAL COM SARIMA
   	   METRICASINSAMPLE_MENSAL=c(PREVISOES_SARIMA$MAD,PREVISOES_SARIMA$MAPE,PREVISOES_SARIMA$RMSE,PREVISOES_SARIMA$UTHEIL)
   }
   # coloca saida dos previsores no formato da previsao mensal que ja existia no SVM
   if (tipoestudo==1){
      # REV0 PMO
      if (monthmodel=="MRD") PREVISOES_MENSAIS$previsaomes1=previsao.mensal.REGDIN$PREVISOES_MENSAIS[1]
      if (monthmodel=="MRD") PREVISOES_MENSAIS$previsaomes2=previsao.mensal.REGDIN$PREVISOES_MENSAIS[2]
      if (monthmodel=="MRD") cargaglobalcorrente=previsao.mensal.REGDIN$cargamescorrente # agosto_2022
	    if (monthmodel=="MBJ") PREVISOES_MENSAIS$previsaomes1=PREVISOES_SARIMA$PREVISOES_MENSAIS[1]
	    if (monthmodel=="MBJ") PREVISOES_MENSAIS$previsaomes2=PREVISOES_SARIMA$PREVISOES_MENSAIS[2]
      if (monthmodel=="MBJ") cargaglobalcorrente=PREVISOES_SARIMA$cargamescorrente #
	    if (monthmodel=="MHW") PREVISOES_MENSAIS$previsaomes1=PREVISOES_HW$PREVISOES_MENSAIS[1]
	    if (monthmodel=="MHW") PREVISOES_MENSAIS$previsaomes2=PREVISOES_HW$PREVISOES_MENSAIS[2]
      if (monthmodel=="MHW") cargaglobalcorrente=PREVISOES_HW$cargamescorrente
      names(cargaglobalcorrente)=paste(nomescorrente,"/",numeroanocorrente,sep="") # agosto_2022
   }else{
      if (monthmodel=="MRD") PREVISOES_MENSAIS$previsaomes1=previsao.mensal.REGDIN$PREVISOES_MENSAIS[1]
      if (monthmodel=="MRD") PREVISOES_MENSAIS$previsaomes2=previsao.mensal.REGDIN$PREVISOES_MENSAIS[2]
 	    if (monthmodel=="MBJ") PREVISOES_MENSAIS$previsaomes1=PREVISOES_SARIMA$PREVISOES_MENSAIS[1]
	    if (monthmodel=="MBJ") PREVISOES_MENSAIS$previsaomes2=PREVISOES_SARIMA$PREVISOES_MENSAIS[2]
 	    if (monthmodel=="MHW") PREVISOES_MENSAIS$previsaomes1=PREVISOES_HW$PREVISOES_MENSAIS[1]
	    if (monthmodel=="MHW") PREVISOES_MENSAIS$previsaomes2=PREVISOES_HW$PREVISOES_MENSAIS[2]
	    cargaglobalcorrente=-1 # agosto_2022
   }
}
PREVISOES_MENSAIS_ANTES=c(PREVISOES_MENSAIS$previsaomes1,PREVISOES_MENSAIS$previsaomes2)

#===========================================================
# RECONCILIA PREVISOES SEMANAIS E MENSAL PARA O PRIMEIRO MES
#===========================================================
print("== RECONCILIA PREVISOES SEMANAIS E MENSAL PARA O PRIMEIRO MES ===")

primeiromes=as.character(PREVISOES_MENSAIS$datames$mes1) # identifica o primeiro mes da previsao
previsao_primeiromes=PREVISOES_MENSAIS$previsaomes1 # previsao para o primeiro mes
aux1=as.Date(rownames(DADOS$DATAPREV)[1])-32
aux2=as.Date(tail(rownames(DADOS$DATAPREV),1))
datas_do_horizonte_previsao=as.character(seq(aux1,aux2,1))
flag_datas=rep(-1,length(datas_do_horizonte_previsao))
aux=which(months(as.Date(datas_do_horizonte_previsao))==primeiromes) # meses pertencentes ao horizonte de previsao no primeiros mes
flag_datas[aux]=0 # indica dias no primeiro mes, a semana corrente fica marcada com 0
previsoes_semanas=PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes # previsoes semanais
# transforma marcacoes diarias de feriados em marcacoes semanais
numsemanashorizonte=length(DADOS$DATAPREV$x_feriados_prev)/7
feriados_semanais=apply(matrix(as.numeric(DADOS$DATAPREV$x_feriados_prev),numsemanashorizonte,7,byrow=T),1,sum)
datas_inic_semanas=PREVISOES_SEMANAIS$PREV.SEMANAIS$datas.inic.semanas # inicio da semana
datas_fim_semanas=PREVISOES_SEMANAIS$PREV.SEMANAIS$datas.fim.semanas # fim da semana

# identifica semanas no primeiros mes
for (i in 1:length(previsoes_semanas)) {
     # percorre semanas de previsao
     if ((months(datas_inic_semanas[i])==primeiromes) & (months(datas_fim_semanas[i])==primeiromes)) {
        # semana i comeca e termina dentro do primeiro mes do horizonte
        aux=seq(datas_inic_semanas[i],datas_fim_semanas[i],1)
        for (j in 1:7) {
            k=grep(aux[j],datas_do_horizonte_previsao)
            flag_datas[k]=i # marca o numero da semana de previsao
        }
     } else {
        if ((months(datas_inic_semanas[i])==primeiromes)|(months(datas_fim_semanas[i])==primeiromes)) {
           # semana i comeca no primeiro mes do horizonte e termina no segundo mes do horizonte
		       # ou semana i termina no primeiro mes do horizonte e comeca no mes anterior do horizonte
           aux=seq(datas_inic_semanas[i],datas_fim_semanas[i],1)
           for (j in 1:7) {
                k=grep(aux[j],datas_do_horizonte_previsao)
                if (months(aux[j])==primeiromes) flag_datas[k]=i # marca o numero da semana de previsao
           }
        }
     }
}
# ao final a semana marcada com 0 comeca no mes anterior ao mes da previsao
matriz_previsoes_primeiros_mes=pesos=vetordatas=contador=c() # inicializa

# semana corrente
data_primeira_semana=seq(as.Date(datas_inic_semanas[1]),as.Date(datas_fim_semanas[1]),1) # dias da primeira semana do horizonte de previsão
if (length(which(flag_datas==0))>0) {
    datas_semana_corrente=datas_do_horizonte_previsao[which(flag_datas==0)]
    # identifica dias da semana corrente no historico
    for (i in 1:length(datas_semana_corrente)) {
         ii=grep(datas_semana_corrente[i],rownames(DADOS$DATAHIST)) # busca dia no historico
         if (length(ii)>0) {
             matriz_previsoes_primeiros_mes=c(matriz_previsoes_primeiros_mes,as.numeric(DADOS$DATAHIST[ii,1]))
             pesos=c(pesos,1)
             vetordatas=c(vetordatas,datas_semana_corrente[i])
             contador=c(contador,0)
         }
    }
    # identifica dias do primeiro mes na semana corrente no horizonte de previsao
    for (i in 1:length(datas_semana_corrente)) {
         ii=grep(datas_semana_corrente[i],rownames(DADOS$DATAPREV)) # busca dia no horizonte de previsao
         if (length(ii)>0) {
			       #matriz_previsoes_primeiros_mes=c(matriz_previsoes_primeiros_mes,previsoes_semanas[min(flag_datas[which(flag_datas>0)])-1])
 			       matriz_previsoes_primeiros_mes=c(matriz_previsoes_primeiros_mes,head(previsoes_semanas[flag_datas[which(flag_datas>0)]],1))
             pesos=c(pesos,1)
             vetordatas=c(vetordatas,datas_semana_corrente[i])
             contador=c(contador,0)
         }
    }
}

# primeira semana do horizonte
if (min(flag_datas[which(flag_datas>0)])==1) {
   # entra aqui se a primeira semana de previsao inicia no primeiro mes da previsao
   if (length(which(flag_datas==1))==7) {
       # primeira semana inteira no primeiro mes
       matriz_previsoes_primeiros_mes=c(matriz_previsoes_primeiros_mes,previsoes_semanas[1])
       pesos=c(pesos,7)
       vetordatas=c(vetordatas,as.character(datas_fim_semanas[1]))
       contador=c(contador,1)
   } else {
       # primeira semana parcialmente no primeiro mes
       datas_semana1=datas_do_horizonte_previsao[which(flag_datas==1)]
       matriz_previsoes_primeiros_mes=c(matriz_previsoes_primeiros_mes,previsoes_semanas[1])
       pesos=c(pesos,length(datas_semana1))
       vetordatas=c(vetordatas,as.character(datas_semana1[length(datas_semana1)]))
       contador=c(contador,1)
   }
   indiceinicial=2 # a proxima semqnq e a 2
} else {
   indiceinicial=min(flag_datas[which(flag_datas>0)])
}
if (indiceinicial<=max(flag_datas)){
    for (i in indiceinicial:max(flag_datas)) {
         if (length(which(flag_datas==i))==7) {
             # semana i inteira no primeiro mes
             matriz_previsoes_primeiros_mes=c(matriz_previsoes_primeiros_mes,previsoes_semanas[i])
             pesos=c(pesos,7)
             vetordatas=c(vetordatas,as.character(datas_fim_semanas[i]))
             contador=c(contador,i)
         } else {
             # semana i parcialmente no primeiro mes e pode ser a ultima semana
             datas_semanas=datas_do_horizonte_previsao[which(flag_datas==i)]
             conta_dia_semana_parcial_mes=0
             for (j in 1:length(datas_semanas)) {
                  if(months(as.Date(datas_semanas[j]))==primeiromes) conta_dia_semana_parcial_mes=conta_dia_semana_parcial_mes+1
             }
             matriz_previsoes_primeiros_mes=c(matriz_previsoes_primeiros_mes,previsoes_semanas[i])
             pesos=c(pesos,conta_dia_semana_parcial_mes)
             vetordatas=c(vetordatas,datas_semanas[length(datas_semanas)])
             contador=c(contador,i)
         }
    }
}

if (tipoestudo==1) { # estava assim versao anterior a 2.1 , apenas REV0
    previsao.primeiro.mes=previsao_primeiromes
    if (desagrega==1){
	    print("Reconcilia previsoes semanais e mensal para o primeiro mes pelo metodo MINT")
        # CONCILIA PREVISOES SEMANAIS E MENSAL PARA O PRIMEIRO MES
        CONCILIADA=concilia(pesos,matriz_previsoes_primeiros_mes,previsao_primeiromes,feriados_semanais)
        previsao.primeiro.mes=CONCILIADA[1]
	    matriz_previsoes_primeiros_mes=CONCILIADA[2:length(CONCILIADA)]
        #PREVISOES SEMANAIS PARA O PRIMEIRO MES
        for (i in min(flag_datas[which(flag_datas>0)]):max(contador)) {
            if (i<=length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)) PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes[i]=matriz_previsoes_primeiros_mes[which(contador==i)]
        }
	} else {
	    if (desagrega==0) {
		    if (desagrega==0) print("Ajusta previsoes semanais para que a media seja a previa mensal do primeiro mes")
		    # mantem a previsao do primeiro mes e ajusta as previsoes semanais
            fator_ajuste=previsao.primeiro.mes/(pesos%*%matriz_previsoes_primeiros_mes/sum(pesos))
            for (i in min(flag_datas[which(flag_datas>0)]):max(contador)) {
                 if (i<=length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)) {
			              matriz_previsoes_primeiros_mes[which(contador==i)]=fator_ajuste*matriz_previsoes_primeiros_mes[which(contador==i)]
			              PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes[i]=matriz_previsoes_primeiros_mes[which(contador==i)]
			           }
            }
        }else{
  		      if (desagrega==2) print("Previsao mensal para o primeiro mes = media das previsoes semanais")
		        # mantem as previsoes semanais e ajusta a previsao do primeiro mes
		        previsao.primeiro.mes=pesos%*%matriz_previsoes_primeiros_mes/sum(pesos)
            for (i in min(flag_datas[which(flag_datas>0)]):max(contador)) {
                 if (i<=length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)) {
			               PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes[i]=matriz_previsoes_primeiros_mes[which(contador==i)]
			           }
            }
        }
	}
}else{
    # se revisao PMO
    if (desagrega==1) {
	    print("Reconcilia previsoes semanais e mensal para o primeiro mes pelo metodo MINT")
 	    restricao=as.numeric(which(pesos==1))
	  	if(tail(pesos,1)==1) restricao=restricao[-length(restricao)] # se ultima semanna tem apenas um dia no mes corrente
      CONCILIADA=concilia_com_retricao(pesos,matriz_previsoes_primeiros_mes,previsao_primeiromes,restricao,feriados_semanais)
      previsao.primeiro.mes=CONCILIADA[1]
	    matriz_previsoes_primeiros_mes=CONCILIADA[2:length(CONCILIADA)]
      #PREVISOES SEMANAIS PARA O PRIMEIRO MES
      for (i in min(flag_datas[which(flag_datas>0)]):max(contador)) {
           if (i<=length(PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)) PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes[i]=matriz_previsoes_primeiros_mes[which(contador==i)]
      }
	} else {
	    print("Previsao mensal para o primeiro mes = media das previsoes semanais")
      # modifica apenas previsao do primeiro mes
      previsao.primeiro.mes=pesos%*%matriz_previsoes_primeiros_mes/sum(pesos)
	}
}
lista_feriados_semanais=feriados_semanais
names(pesos)=vetordatas
names(matriz_previsoes_primeiros_mes)=vetordatas
previsao.mes1=list(previsaomes1=previsao.primeiro.mes,pesos=pesos,previsoes.parciais=matriz_previsoes_primeiros_mes)

#===================
# RELATORIO DE SAIDA
#===================
saidaprev<<-PREVISOES_SEMANAIS
print("====================== GERANDO RELATORIOS =======================")
relatorios=RELATORIO(PREVISOES_SEMANAIS,PREVISOES_MENSAIS,DADOS,SERIES_SEMANAIS,separadordec,previsao.mes1,tipoinput,caminho,cargaglobalcorrente,previsaosemanacorrente,datasemanacorrenteinic,datasemanacorrentefim,diretorioarquivosmodelo,extra)
if (weekmodel=="MRD"){
    if (length(which(is.na(hparsem1)))==6 & length(which(is.na(hparsem2)))==6 ) {
	      modelo_semanal="REGRESSAO DINAMICA - AUTOMATICO"
	  }else{
        modelo_semanal="REGRESSAO DINAMICA"
	  }
	  serie_semanal=previsao.semanal.REGDIN$DADOS%>%select(.model,year_week,carga_sem,.fitted)
	  serie_semanal=serie_semanal%>%mutate(.model="REG.DINAMICA")
}
if (weekmodel=="MHW"){
    modelo_semanal="HOLT-WINTERS"
	  serie_semanal=previsao.semanal.HW$DADOS%>%select(.model,year_week,carga_sem,.fitted)
	  serie_semanal=serie_semanal%>%mutate(.model="HOLT-WINTERS")
}
if (weekmodel=="SVM"){
    modelo_semanal="SVM"
  	serie_semanal=data.frame(PREVISOES_SEMANAIS$OBSERVADO,PREVISOES_SEMANAIS$ESTIMADO)
  	names(serie_semanal)=c("carga_sem",".fitted")
}
if (monthmodel=="SVM"){
   modelo_mensal="SVM"
   serie_mensal = PREVISOES_MENSAIS$DADOS
   names(serie_mensal)=c("carga_mes",".fitted")
}
if (monthmodel=="MBJ"){
    if (length(which(is.na(hparmes)))==6) modelo_mensal="SARIMA - AUTOMATICO"
    if (length(which(is.na(hparmes)))!=6) modelo_mensal="SARIMA"
    serie_mensal = PREVISOES_SARIMA$DADOS
	  serie_mensal=serie_mensal%>%select(.model,year_month,carga_mes,.fitted)
	  serie_mensal=serie_mensal%>%mutate(.model="SARIMA")
}
if (monthmodel=="MRD") {
    if (length(which(is.na(hparmes)))==6) modelo_mensal="REGRESSAO DINAMICA - AUTOMATICO"
    if (length(which(is.na(hparmes)))!=6) modelo_mensal="REGRESSAO DINAMICA"
    serie_mensal = previsao.mensal.REGDIN$DADOS
	  serie_mensal=serie_mensal%>%select(.model,year_month,carga_mes,.fitted)
	  serie_mensal=serie_mensal%>%mutate(.model="REG.DINAMICA")
}
if (monthmodel=="MHW") {
    modelo_mensal="HOLT-WINTERS"
    serie_mensal = PREVISOES_HW$DADOS
  	serie_mensal=serie_mensal%>%select(.model,year_month,carga_mes,.fitted)
	  serie_mensal=serie_mensal%>%mutate(.model="HOLT-WINTERS")
}
tipo_estudo="REV0 do PMO"
if (tipoestudo==0) tipo_estudo="revisao semanal do PMO"
names(METRICASINSAMPLE_SEMANAL)=c("MAD_MW","MAPE%","RMSE_MW","U-Theil")
names(METRICASINSAMPLE_MENSAL)=c("MAD_MW","MAPE%","RMSE_MW","U-Theil")
if (tipoestudo==0) names(PREVISOES_MENSAIS_ANTES)=names(relatorios$MENSAL)
if (tipoestudo==1) names(PREVISOES_MENSAIS_ANTES)=names(relatorios$MENSAL)[-1]
print("Execucao realizada com sucesso")
return(list(previsao_mensal=relatorios$MENSAL,primeiro_mes_aberto=relatorios$PRIMEIROMES,previsao_semanal=relatorios$SEMANAL,tipo_estudo=tipo_estudo,modelo_mensal=modelo_mensal,modelo_semanal=modelo_semanal,serie_mensal=serie_mensal,serie_semanal=serie_semanal,metricas_insample_semanal=METRICASINSAMPLE_SEMANAL,metricas_insample_mensal=METRICASINSAMPLE_MENSAL,PREVISOES_SEMANAIS_ANTES=PREVISOES_SEMANAIS_ANTES,PREVISOES_MENSAIS_ANTES=PREVISOES_MENSAIS_ANTES,lista_feriados_semanais=lista_feriados_semanais))
options("scipen"=0)
# FIM
}

#' @title Programa LEITORA
#' @name LEITORA
#'
#' @description Realiza a a leitura dos dados em csv
#'
#' @param caminho caminho dos arquivos de dados ou deck
#' @param arquivo arquivo com parametros de execucao
#' @param tipotemp modelagem da temperatura
#'
#' @return Matriz com os dados lidos
LEITORA=function(caminho,arquivo,tipotemp){
# PARAMETROS DE ENTRADA: caminho: path onde esta o arquivo, exemplo "c:/forecastpmo/dados/"
#                        arquivo: arquivo com parametros (exemplo "parametros.csv")
#                        tipotemp: se igual a 3 nao considera temperatura
# VARIAVEIS DE SAIDA: DATAHIST: data.frame contendo dados para cada dia do historico
#                               cada linha representa um dia
#                               coluna 1 demanda media diaria
#                               coluna 2 indicacao de feriado
#                               coluna 3,4 e 5 guardam as temperaturas maxima, media e minima
#                     DATAPREV: data.frame contendo dados para cada dia do horizonte de previsao
#                               cada linha representa um dia
#                               coluna 1 indicacao de feriado
#                               colunas 2,3 e 4 guardam as temperaturas maxima, media e minima previstas
#                     SERIEHIST: data.frame contendo dados historicos de carga, temperatura, feriados
#                                e horario de verao na forma de serie temporais
#                                coluna 1 serie temporal da carga
#                                coluna 2 serie temporal com indicacao de feriados
#                                coluna 4 serie temporal da temperatura
#                     SERIEPREV: data.frame contendo dados previstos de temperatura e feriados
#                                coluna 1 serie temporal com indicacao de feriados
#                                colunas 2, 3 e 4 series temporais das temperaturas maxima, media e minima
#                     DATAHIST, DATAPREV, SERIEHIST e SERIEPREV sao gravados na lista DADOSLIDOS
#                     MERGE: DATA FRAME COM MERGE DE DADOS DO PERIODO HISTORICO E PREVISAO

#==============================================
# LEITURA DO ARQUIVO DE DADOS GERAIS PARAMETROS
#==============================================
conteudo=read.csv2(paste(caminho,"/",arquivo,sep=""),sep=";",header=T) # LEITURA DO ARQUIVO PARAMETROS
nome=conteudo[1,1] # nome da serie
arqcarga=paste(caminho,"/",conteudo[1,2],sep="") # nome do arquivo com dados de carga CARGAHIST
arqtemphist=paste(caminho,"/",conteudo[1,3],sep="") # nome do arquivo com temperatura EXOGENAHIST
arqtempprev=paste(caminho,"/",conteudo[1,4],sep="") # nome do arquivo com temperatura no horizonte de previsao EXOGENAPREV
arqferiados=paste(caminho,"/",conteudo[1,5],sep="") # nome do arquivo com feriados FERIADOS
arqhorizonte=paste(caminho,"/",conteudo[1,6],sep="") # nome do arquivo com dados do horizonte de previsao
separadordec=conteudo[1,7] # separador decimal 0 para ponto, diferente de 0 para virgula
print("Leitura do arquivo PARAMETROS.CSV")

#======================================================
# LEITURA DO ARQUIVO COM DADOS DO HORIZONTE DE PREVISAO
#======================================================
filename=paste(as.character(arqhorizonte),".csv",sep="")
if (file.exists(filename)) {
    dados=read.csv2(filename,sep=";",header=T)
} else {
    print(paste("Nao foi encontrado o arquivo com dados do horizonte de previsao ",filename,sep=""))
    stop("Execucao cancelada")
}
indice=which(dados[,1]=="Instante inicial da previsao") # identifica linha da data inicial da previsao
if (length(indice)>0) {
    data_inicio_prev=as.Date(paste(dados[indice,2],"-",dados[indice,3],"-",dados[indice,4],sep=""))
    hora_inicio_prev=paste(dados[indice,5],":",dados[indice,6],sep="")
} else {
    print(paste("Erro no arquivo ",filename,sep=""))
    print("Nao encontrada a linha Instante inicial da previsao")
    stop("Execucao cancelada")
}
indice=which(dados[,1]=="Data final da previsao") # identifica linha da data final da previsao
if (length(indice)>0) {
    data_final_prev=as.Date(paste(dados[indice,2],"-",dados[indice,3],"-",dados[indice,4],sep="")) # data final informada pelo usuario
} else {
    print(paste("Erro no arquivo ",filename,sep=""))
    print("Nao encontrada a Data final da previsao")
    stop("Execucao cancelada")
}

if (weekdays1(data_final_prev)=="sabado") delta = 6
if (weekdays1(data_final_prev)=="domingo") delta = 5
if (weekdays1(data_final_prev)=="segunda-feira") delta = 4
if (weekdays1(data_final_prev)=="terca-feira") delta = 3
if (weekdays1(data_final_prev)=="quarta-feira") delta = 2
if (weekdays1(data_final_prev)=="quinta-feira") delta = 1
if (weekdays1(data_final_prev)=="sexta-feira") delta = 0
if (delta!=0) {
    print(paste("Mensagem: Horizonte de previsao informado",data_final_prev))
    data_final_prev=data_final_prev+delta
    print(paste("Mensagem: Horizonte de previsao alterado para",data_final_prev))
} else {
    print(paste("Mensagem: Horizonte de previsao informado",data_final_prev))
}
hora_final_prev=paste(dados[indice,5],":",dados[indice,6],sep="")
dias_previsao=seq(as.Date(data_inicio_prev), as.Date(data_final_prev), "days") # datas dos dias de previsao
numdiasprev=length(dias_previsao)

# DATAS DOS FERIADOS NO HORIZONTE DE PREVISAO
indiceferiadoprev=which(dados[,1]=="feriado") # identifica linhas em dados com feriados
numferiados_prev=length(indiceferiadoprev)
x_feriados_prev=rep(0,numdiasprev)
if (numferiados_prev>0) {
    # entra aqui se ha feriados no horizonte de previsao
    for (i in 1:numferiados_prev) {
         ano=dados[indiceferiadoprev[i],2]
         mes=dados[indiceferiadoprev[i],3]
         dia=dados[indiceferiadoprev[i],4]
         feriados_horizonte=as.Date(paste(ano,"-",mes,"-",dia,sep=""))
         auxindice=grep(as.character(feriados_horizonte),as.character(dias_previsao),fixed=T)
         if (length(auxindice)>0) x_feriados_prev[auxindice]=dados[indiceferiadoprev[i],7]
    }
}
dadosprev=dados
print(paste("Leitura do arquivo",filename))
rm(dados)

#=====================================================================
# LEITURA DO ARQUIVO COM DADOS DE CARGA E MONTAGEM DA SERIE HISTORICA
#=====================================================================
filename=paste(as.character(arqcarga),".csv",sep="")
if (file.exists(filename)) {
    if (separadordec==0) {
        dados=read.csv2(filename,dec=".",sep=";",header=T)
    } else {
        dados=read.csv2(filename,dec=",",sep=";",header=T)
    }
} else {
    print(paste("Nao foi encontrado o arquivo com dados de carga ",filename,sep=""))
    stop("Execucao cancelada")
}
# IDENTIFICA E CORRIGE EVENTUAIS ERROS NO CARGAHIST
# DECORRENTES DE PROBLEMAS COM O FIM DO HORARIO DE VERAO
indice=duplicated(data.frame(dados$Data))
if (length(which(indice==T))>0){
   dados$Carga[(which(indice==T)-1)]=(dados$Carga[which(indice==T)]+dados$Carga[(which(indice==T)-1)])/2
   dados=dados[-which(indice==T),]
}
# FIM DO AJUSTE DO CARGAHIST
data_carga=dados$Data
carga=dados$Carga # serie de carga

# gera sequencia de datas dos dias no historico
data_inic_hist=data_carga[1]
data_fim_hist=tail(data_carga,1)
dias_historico=seq(as.Date(data_inic_hist), as.Date(data_fim_hist), "days") # datas dos perfis
numdias=length(dias_historico) # numero de dias no historico com dados completos e incompletos

print(paste("Leitura do arquivo",filename))
rm(dados)

#=================================
# LEITURA DO ARQUIVO COM FERIADOS
#=================================
filename=paste(as.character(arqferiados),".csv",sep="")
if (file.exists(filename)) {
    dados=read.csv2(filename,sep=";",header=T)
} else {
    print(paste("Nao foi encontrado o arquivo com dados de feriados ",filename,sep=""))
    stop("Execucao cancelada")
}
data_feriados=as.Date(dados$Data)
x_feriados=rep(0,length(dias_historico))
numferiados=length(data_feriados)
for (i in 1:numferiados) {
     indice=grep(data_feriados[i],as.character(dias_historico))
     x_feriados[indice]=dados[i,2]
}
rm(dados)
print(paste("Leitura do arquivo",filename))

#=============================================
# LEITURA DO ARQUIVO COM DADOS DE TEMPERATURA
#=============================================
perfis_temperatura=matrix(0,numdias,3) # inicializa matriz de perfis
if (tipotemp!=3){
    filename=paste(as.character(arqtemphist),".csv",sep="")
    if (file.exists(filename)) {
        if (separadordec==0) {
            dados=read.csv2(filename,dec=".",sep=";",header=T)
        } else {
            dados=read.csv2(filename,dec=",",sep=";",header=T)
        }
    } else {
        print(paste("Nao foi encontrado o arquivo com dados de temperatura ",filename,sep=""))
        stop("Execucao cancelada")
    }
	data_temp=as.Date(dados$Data)
    for (i in 1:numdias) {
         indice=grep(as.character(dias_historico[i]),data_temp,fixed=T) # procura data informada pelo ONS em dias_historico
		 if (length(indice)>0) perfis_temperatura[i,]=c(dados$Exo_TemperaturaMax[indice],dados$Exo_TemperaturaMed[indice],dados$Exo_TemperaturaMin[indice])
    }
    rownames(perfis_temperatura)=as.character(dias_historico)
    rm(dados)
    print(paste("Leitura do arquivo",filename))
}else{
    # previsao sem temperatura
    rownames(perfis_temperatura)=as.character(dias_historico)
}

#======================================
# CRIA DATA.FRAME COM DADOS HISTORICOS
#======================================
DATAHIST=data.frame(carga,x_feriados,perfis_temperatura)
SERIEHIST=data.frame(carga,x_feriados,perfis_temperatura)
colnames(SERIEHIST)=c("carga","feriado","temperatura_max","temperatura_media","temperatura_min")

#================================================
# LEITURA DO ARQUIVO COM PREVISAO DE TEMPERATURA
#================================================
perfis_temperatura_prev=matrix(0,numdiasprev,3) # inicializa matriz de perfis
if (tipotemp!=3) {
    filename=paste(as.character(arqtempprev),".csv",sep="")
    if (file.exists(filename)) {
        if (separadordec==0) {
            dados=read.csv2(filename,dec=".",sep=";",header=T)
        } else {
            dados=read.csv2(filename,dec=",",sep=";",header=T)
        }
    } else {
        print(paste("Nao foi encontrado o arquivo com dados de temperatura previstas ",filename,sep=""))
        stop("Execucao cancelada")
    }
    data_temprev=as.Date(dados$Data)
    data_inic_prev=data_temprev[1]
    data_fim_prev=as.Date(tail(data_temprev,1))+62 # 2 meses alem da ultima hora com temperatura prevista
    for (i in 1:numdiasprev) {
         indice=grep(as.character(dias_previsao[i]),data_temprev,fixed=T) # procura data informada pelo ONS em dias_historico
		 if (length(indice)>0) perfis_temperatura_prev[i,1:3]=c(dados$Exo_TemperaturaMax[indice],dados$Exo_TemperaturaMed[indice],dados$Exo_TemperaturaMin[indice])

    }
    rownames(perfis_temperatura_prev)=as.character(dias_previsao)
    rm(dados)
    print(paste("Leitura do arquivo",filename))
}else{
    # previsao sem temperatura
    rownames(perfis_temperatura_prev)=as.character(dias_previsao)
}

#====================================================
# CRIA DATA.FRAME COM DADOS DO HORIZONTE DE PREVISAO
#====================================================
DATAPREV=data.frame(x_feriados_prev,perfis_temperatura_prev)
SERIEPREV=data.frame(x_feriados_prev,perfis_temperatura_prev)

#=============================
# MERGE HISTORICO E HORIZONTE
#=============================
data_final_merge=as.Date(tail(dias_previsao,1))
datas=seq(as.Date(data_carga[1]),data_final_merge,1) # sequencia de datas desde o primeiro dia do historico
merge_feriados=rep(0,length(datas))
merge_feriados[1:length(x_feriados)]=x_feriados
if (numferiados_prev>0) {
    for (i in 1:numferiados_prev) {
         ano=dadosprev[indiceferiadoprev[i],2]
         mes=dadosprev[indiceferiadoprev[i],3]
         dia=dadosprev[indiceferiadoprev[i],4]
         feriados_horizonte=as.Date(paste(ano,"-",mes,"-",dia,sep=""))
         merge_feriados[which(datas==feriados_horizonte)]=dadosprev[indiceferiadoprev[i],7]
    }
}
MERGE=data.frame(merge_feriados) # MERGE HORARIO DE VERAO E FERIADOS
rownames(MERGE)=as.character(datas)

# EXPORTA LISTA DADOSLIDOS
DADOSLIDOS=list(DATAHIST=DATAHIST,DATAPREV=DATAPREV,SERIEHIST=SERIEHIST,SERIEPREV=SERIEPREV,MERGE=MERGE,separador=separadordec)
print("leitura de dados concluida com sucesso")
return(DADOSLIDOS)
}


#' @title Programa CABECALHO
#' @name CABECALHO
#'
#' @description Imprime o cabecalho do programa na tela
#'
#' @param versao numero da versao do programa
#'
#' @return Cabecalho do programa
cabecalho=function(versao){
num_versao=paste("FORECASTPMO VERSAO ",versao,sep="")
print(num_versao)
return(num_versao)
}

#' @title Programa MONTAMES
#' @name MONTAMES
#'
#' @description  MONTA SERIE DE CARGA MENSAL
#'
#' @param PREVISOES_SEMANAIS previsoes semanais
#' @param DADOS conjunto de dados
#'
#' @return SERIE CARGA MENSAL
MONTAMES<-function(PREVISOES_SEMANAIS,DADOS) {

# MONTA SERIE MENSAL A PARTIR DAS PREVISOES SEMANAIS
datas.inic.semanal.completa=PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$datas.inic.semanal.completa
datas.fim.semanal.completa=PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$datas.fim.semanal.completa
n.total.semanas=PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$n.total.semanas
serie.semanal.completa=PREVISOES_SEMANAIS$PREV.SEMANAIS.HIST$serie.semanal.completa

year1=as.numeric(substr(as.character(datas.inic.semanal.completa),1,4)) # ano do primeiro dia da semana operativa
meses1=months(datas.inic.semanal.completa) # mes do primeiro dia da semana operativa
year2=as.numeric(substr(as.character(datas.fim.semanal.completa),1,4)) # ano do ultimo dia da semana operativa
meses2=months(datas.fim.semanal.completa) # mes do ultimo dia da semana operativa
aux.mensal=contador=0
seriemensal=datames=c()
for (i in 1:n.total.semanas) {
       if (meses1[i]==meses2[i]) {
           if (i>1) {
               # para o caso do fim do mes coincidir com o fim da semana operativa
               if (meses1[i]!=meses2[i-1]) {
                   # entra aqui se trocou de mes na passagem da semana i-1 para i
                   seriemensal=c(seriemensal,aux.mensal/contador)
                   datames=c(datames,paste(year1[i-1],"/",meses1[i-1],sep=""))
                   aux.mensal=0
                   contador=0
               }
           }
           # semana comeca e termina no mesmo mes
           aux.mensal=aux.mensal+7*serie.semanal.completa[i]
           contador=contador+7
           if (i==n.total.semanas) {
               # fecha estimativa mensal com dados da ultima semana prevista
               seriemensal=c(seriemensal,aux.mensal/contador)
               datames=c(datames,paste(year1[i],"/",meses1[i],sep=""))
           }
       } else {
           # semana comeca em um mes e termina no outro
           auxdata=datas.inic.semanal.completa[i]+seq(0,6,1)
           frequencia.dias.em.cada.mes=table(months(auxdata)) # total de dias da semana em cada um dos dois meses
           i1=frequencia.dias.em.cada.mes[grep(meses1[i],names(frequencia.dias.em.cada.mes))]# total de dias no mes 1
           i2=frequencia.dias.em.cada.mes[grep(meses2[i],names(frequencia.dias.em.cada.mes))]# total de dias no mes 2
           aux.mensal=aux.mensal+i1*serie.semanal.completa[i]
           contador=contador+i1
           seriemensal=c(seriemensal,aux.mensal/contador)
           datames=c(datames,paste(year1[i],"/",meses1[i],sep=""))
           aux.mensal=i2*serie.semanal.completa[i]
           contador=i2
           if (i==n.total.semanas) {
               # fecha estimativa mensal com dados da ultima semana prevista
               seriemensal=c(seriemensal,aux.mensal/contador)
               datames=c(datames,paste(year2[i],"/",meses2[i],sep=""))
           }
       }
}
names(seriemensal)=datames

# MONTA SERIE MENSAL A PARTIR DOS DADOS DIARIOS DO HISTORICO
carga.media.diaria=DADOS$DATAHIST[,1]
datas.dias=rownames(DADOS$DATAHIST)

# marca feriados B3 nao marcados pelo ONS
diasemana2023=wday(datas.dias)
tipodia2023=is.bizday(datas.dias,cal="Brazil/B3")
feriados2023=which(tipodia2023==FALSE & (diasemana2023 >1 & diasemana2023 <7) )
aux2023=DADOS$DATAHIST[feriados2023,2]
DADOS$DATAHIST[feriados2023,2]=ifelse(aux2023>0,aux2023,1)

dias.semanas=weekdays1(as.Date(datas.dias))
total.dias.mes=table(substr(datas.dias,1,7))
datas.dias=names(table(substr(datas.dias,1,7)))
nmeses=length(datas.dias)
serie.mensal.real=total.feriados.mes=total.weekends.mes=c()
#auxferiados=rep(0,length(DADOS$DATAHIST[,2]))
#auxferiados[c(which(DADOS$DATAHIST[,2]==1),which(DADOS$DATAHIST[,2]==2),which(DADOS$DATAHIST[,2]==5))]=1

for (mes in 1:nmeses) {
     indice=grep(datas.dias[mes],substr(rownames(DADOS$DATAHIST),1,7))
     serie.mensal.real=c(serie.mensal.real,mean(carga.media.diaria[indice],na.rm=T))
     # total de feriados no mes
     if (length(which((DADOS$DATAHIST[indice,2]>0 & DADOS$DATAHIST[indice,2]<=4) | DADOS$DATAHIST[indice,2]==6))>0) {
         total.feriados.mes=c(total.feriados.mes,length(which((DADOS$DATAHIST[indice,2]>0 & DADOS$DATAHIST[indice,2]<=4) | DADOS$DATAHIST[indice,2]==6)))
     } else {
         total.feriados.mes=c(total.feriados.mes,0)
     }
     # total de sabados e domingos no mes
     total.weekends.mes=c(total.weekends.mes,length(grep("sabado",dias.semanas[indice]))+length(grep("domingo",dias.semanas[indice])))
}
names(serie.mensal.real)=datas.dias
DADOS_MES=list(total.dias.mes=total.dias.mes,total.feriados.mes=total.feriados.mes,total.weekends.mes=total.weekends.mes,serie.mensal.real=serie.mensal.real)
return(DADOS_MES)
}


#' @title Programa MONTASEMANAS
#' @name MONTASEMANAS
#'
#' @description  MONTA SERIE DE CARGA SEMANAL
#'
#' @param datasprev datas da previsao
#' @param DADOS conjunto de dados
#'
#' @return SERIE CARGA SEMANAL
MONTASEMANAS<-function(datasprev,DADOS){
# semanas operativas do periodo historico (semana operativa comeca no sabado e termina na sexta)
diasemana_historico=weekdays1(as.Date(rownames(DADOS$DATAHIST)))

inic_semana=which(diasemana_historico=="sabado") # indices dos sabados, semana operativa comeca nos sabados
fim_semana=inic_semana[2:length(inic_semana)]-1 # indices das sextas, semana operativa termina na sexta

# matriz com os indices do inicio e fim de cada semana
matriz_inic_fim_semana_operativa=matrix(0,length(inic_semana),2) # inicializa matriz
matriz_inic_fim_semana_operativa[,1]=inic_semana
matriz_inic_fim_semana_operativa[1:length(fim_semana),2]=fim_semana
matriz_inic_fim_semana_operativa[length(inic_semana),2]=matriz_inic_fim_semana_operativa[length(inic_semana),1]+6

# CONJUNTO DE DADOS A: perfis do periodo historico
indice=which(rownames(DADOS$DATAHIST)<datasprev[1])
conjuntoA=DADOS$DATAHIST[indice,1:2] # carga historica e feriados
colnames(conjuntoA)=c("carga","feriados")

# marca feriaddos do calendario B3
diasemana2023=wday(as.Date(rownames(conjuntoA)))
tipodia2023=is.bizday(as.Date(rownames(conjuntoA)),cal="Brazil/B3") # classifica dias em uteis e feriado/fim de semana
feriados2023=which(tipodia2023==FALSE & ((diasemana2023>1 & diasemana2023<7)|(conjuntoA$feriados==6 | conjuntoA$feriados==8))) # seleciona feriados em dias uteis e feriados em dezembro
aux2023=conjuntoA$feriados[feriados2023] # tipo de dias marcados pelo ONS nos feriados da B3
conjuntoA$feriados[feriados2023]=ifelse(aux2023>0,aux2023,1) # marca com 1 feriado B3 nao marcado pelo ONS
conjuntoA$feriados[which((diasemana2023==1|diasemana2023==7) & (month(as.Date(rownames(conjuntoA)))>1 & month(as.Date(rownames(conjuntoA)))<12))]=0 # cancela feriados em sabados e domingos entre fevereiro e novembro

# CONJUNTO DE DADOS C: temperaturas historicas
conjuntoC=DADOS$DATAHIST[indice,3:5] # perfis de temperatura historicas
colnames(conjuntoC)=seq(1,3,1)

# CONJUNTO DE DADOS D: temperaturas previstas
conjuntoD=DADOS$DATAPREV[,2:4] # perfis de temperatura prevista
colnames(conjuntoD)=seq(1,3,1)

# CONSOLIDA BASE DE DADOS COM PERFIS DE CARGA E TEMPERATURA HISTORICA E PREVISTA
dados_carga_completos=conjuntoA # carga historica
dados_temperatura_completos=rbind(conjuntoC,conjuntoD) # perfis de temperatura historica e previstas concatenadas

# BASE DE DADOS HISTORICOS PARA PREVISAO SEMANAL
# dados de semanas completas no historico, inclusive a ultima semana operativa
num.semanas.completas=dim(matriz_inic_fim_semana_operativa)[1] # numero de semanas completas no historico
dados_carga_semanais=c()
dados_temperatura_semanais=c()
dados_tipo_semanais_feriado=c()
for (i in 1:num.semanas.completas) {
     inicio=matriz_inic_fim_semana_operativa[i,1]
     fim=matriz_inic_fim_semana_operativa[i,2]

     auxcarga=as.vector(t(dados_carga_completos[inicio:fim,1]))
     auxtemp=as.vector(t(dados_temperatura_completos[inicio:fim,1]))
     auxtipo_feriado=as.vector(t(dados_carga_completos[inicio:fim,2]))

     dados_carga_semanais=rbind(dados_carga_semanais,auxcarga)
     dados_temperatura_semanais=rbind(dados_temperatura_semanais,auxtemp)
     dados_tipo_semanais_feriado=rbind(dados_tipo_semanais_feriado,auxtipo_feriado) # sequencia feriado em cada dia da semana
}
rm(auxcarga)
rm(auxtemp)
rm(auxtipo_feriado)

carga.media.semanal=apply(dados_carga_semanais[1:num.semanas.completas,],1,mediasemNA)
log.carga.media.semanal=log(carga.media.semanal)
diff.log.carga.media.semanal=diff(log.carga.media.semanal,1)
diff.log.carga.media.semanal=c(0,diff.log.carga.media.semanal)
data.inic.semana=as.Date(rownames(DADOS$DATAHIST[matriz_inic_fim_semana_operativa[,1],]))
data.fim.semana=as.Date(rownames(DADOS$DATAHIST[matriz_inic_fim_semana_operativa[,1],]))+6
Xmeses=c() # mes modal em cada semana
Xmesesorigem=c()
for (i in 1:length(data.inic.semana)){
     sequencia=seq(as.Date(data.inic.semana[i]),as.Date(data.fim.semana[i]),by = 1)
     aux=c()
     for (j in 1:7) {
          aux=c(aux,as.numeric(substr(sequencia[j],6,7))) # pega o mes na data
     }
     # pega o mes modal em cada semana
     Xmeses=c(Xmeses,as.numeric(names(which(table(aux)==max(table(aux))))))
     auxvetor=rep(0,11)
     if (aux[1]!=12) auxvetor[aux[1]]=1
     Xmesesorigem=rbind(Xmesesorigem,auxvetor) # matriz dummy mes de cada semana
}

rownames(dados_carga_semanais)=NULL
rownames(dados_temperatura_semanais)=NULL
rownames(dados_tipo_semanais_feriado)=NULL
x1=dados_carga_semanais
x2=dados_temperatura_semanais
x3=dados_tipo_semanais_feriado
rm(dados_carga_semanais)
rm(dados_temperatura_semanais)
rm(dados_tipo_semanais_feriado)
PERFIS_SEMANAIS=list(dados_carga_semanais=x1,dados_temperatura_semanais=x2,dados_tipo_semanais_feriado=x3)

x1=carga.media.semanal
x2=diff.log.carga.media.semanal
x3=Xmeses
x4=Xmesesorigem
x5=matriz_inic_fim_semana_operativa
x6=data.inic.semana
x7=data.fim.semana
x8=num.semanas.completas
x9=conjuntoA
rm(carga.media.semanal)
rm(diff.log.carga.media.semanal)
rm(Xmeses)
rm(Xmesesorigem)
rm(matriz_inic_fim_semana_operativa)
rm(data.inic.semana)
rm(data.fim.semana)
rm(conjuntoA)
rm(conjuntoC)
rm(conjuntoD)
DADOS_SEMANAIS=list(carga.media.semanal=x1,diff.log.carga.media.semanal=x2,Xmeses=x3,Xmesesorigem=x4,matriz_inic_fim_semana_operativa=x5)
MATRIZ_SEMANAL=list(PERFIS=PERFIS_SEMANAIS,DADOS_SEMANAIS=DADOS_SEMANAIS,data.inic.semana=x6,data.fim.semana=x7,num.semanas.completas=x8,CONJUNTOA=x9)
return(MATRIZ_SEMANAL)
}

#' @title Programa PREVISAO DE CARGA MENSAL COM SVM E HOLT-WINTERS
#' @name PREVMENSAL
#'
#' @description REALIZA A PREVISAO DE CARGA MENSAL COM SVM E HOLT-WINTERS
#'
#' @param SERIES_MENSAIS serie mensais
#' @param DADOS conjunto de dados
#' @param tipoestudo tipo do estudo
#' @param diretorioarquivosmodelo diretorio com modelos
#' @param monthmodel modelo mensal
#' @param hparmes paramatros para o modelo mensal
#' @param pandemia tratamento da pandemia
#'
#' @return PREVISAO DE CARGA MENSAL
PREVMENSAL<-function(SERIES_MENSAIS,DADOS,tipoestudo,diretorioarquivosmodelo,monthmodel,hparmes,pandemia){
# se monthmodel diferente de SVM entra aqui apenas para pegar estrutura de dados da previsao
total.dias.mes=SERIES_MENSAIS$total.dias.mes
serie.mensal.real<-SERIES_MENSAIS$serie.mensal.real # serie de carga
nobsmes=length(serie.mensal.real)
ndiasuteis=getbizdays(substr(names(SERIES_MENSAIS$serie.mensal),1,7),"Brazil/B3") # numero de dias uteis
ano=as.numeric(substr(names(SERIES_MENSAIS$serie.mensal),1,4))
mes=as.numeric(substr(names(SERIES_MENSAIS$serie.mensal),6,7))

if (pandemia==1){
    # corrige valores no periodo da pandemia entre marco e agosto
    print("mensagem: realizado tratamento do efeito da pandemia")
    start1=c(as.numeric(unlist(strsplit(names(serie.mensal.real)[1],"-"))[1]),as.numeric(unlist(strsplit(names(serie.mensal.real),"-"))[2]))
    seriemensal=ts(serie.mensal.real,start=start1,frequency=12) # serie sem o ultimo mes
    seriemensal=window(seriemensal,start=start1,end=c(2020,2))
    seriemensal=as_tsibble(seriemensal)
    modelo=seriemensal%>%model(ETS(value ~ error("A")+trend("A")+season("A")))
    previsto=forecast(modelo,h=6)$.mean
    indice=which(ano==2020 & (mes==3 | mes==4 | mes==5 | mes==6 | mes==7 | mes==8))
    serie.mensal.real[indice]=previsto
}

if (tipoestudo==1) {
    # REV0 PMO
    indice.mes.incompleto=which(total.dias.mes<20)
    if (length(indice.mes.incompleto)>0) {
        print("mensagem: PMO com menos de 20 dias do mes corrente, deveria ser revisao do PMO")
		    print("          tipo de estudo alterado para revisao PMO")
		    tipoestudo=0
    }
} else{
    # revisao semanal do PMO
    indice.mes.incompleto=which(total.dias.mes<=27)
    if (length(indice.mes.incompleto)>0) {
        nobsmes=length(serie.mensal.real[-indice.mes.incompleto])
        serie.mensal.real=serie.mensal.real[-indice.mes.incompleto]
    } else {
        print("mensagem: Selecionado revisao do PMO, porem deveria ser REV0 do PMO")
		    print("          tipo de estudo alterado para REV0 do PMO")
		    tipoestudo=1
    }
}

months=as.numeric(substr(names(serie.mensal.real),6,7))

# identificacao automatica de lags
if (monthmodel=="SVM"){
    if (length(which(is.na(hparmes)))>0){
       # se lags sao NA
       aux=acf(serie.mensal.real[-seq(1,12,1)],26,plot=F)$acf[-1]
       lags=which(abs(aux)>2/sqrt(length(serie.mensal.real)))
	     print("lags definidos automaticamente")
	     print(lags)
    } else {
       # se lag nao e NA
       lags=hparmes
       print("lags definidos manualmente")
	     print(lags)
    }
	nn=length(lags)
}

minimo=9999
minimovar=9999
minimoregressao=9999
set.seed(1513)

estimativa=nomescolunas=Ymescarga=Xmescarga=Xsazonal=Xdiasuteis=c() # dummy mensal

# AJUSTA MODELO SVM
if (monthmodel=="SVM"){
   for (i in (max(lags[1:nn])+1):nobsmes){
       if (!is.na(serie.mensal.real[i])){
             nomescolunas=c(nomescolunas,names(serie.mensal.real)[i])
    	     Ymescarga=c(Ymescarga,(serie.mensal.real[i]/100000))
             Xmescarga=rbind(Xmescarga,(serie.mensal.real[i-lags[1:nn]]/100000))
		     Xdiasuteis=c(Xdiasuteis,i)	# tendencia
	   }
   }
   dados_mes_treina=cbind(Xmescarga,Xdiasuteis,Ymescarga)
   colnames(dados_mes_treina)=c(paste("X",seq(1,(dim(dados_mes_treina)[2]-1),1),sep=""),"Ycarga")
   rownames(dados_mes_treina)=nomescolunas
   dados_mes_treina=data.frame(dados_mes_treina)
   melhormodelo=svm(Ycarga~.,data=dados_mes_treina,cost=1,kernel="linear",type="eps-regression") # AJUSTA SVM MENSAL
   nnlag=nn
   dados_mes_treina0=dados_mes_treina

   # calcula valores ajustados
   estimativa=predict(melhormodelo,dados_mes_treina0)

   nomescolunas=rownames(dados_mes_treina0)
   #### MES CORRENTE
   xxx=serie.mensal.real
   xxx0=xxx[1:(length(xxx)-1)] # retira o mes corrente
   start1=c(as.numeric(unlist(strsplit(names(xxx)[1],"-"))[1]),as.numeric(unlist(strsplit(names(xxx),"-"))[2]))
   seriemensal=ts(xxx0,start=start1,frequency=12) # serie sem o ultimo mes
   if (is.na(tail(xxx,1))) xxx=xxx[length(xxx)-1] # retira o NA do mês corrente
}

# periodo de previsao
ano1=as.numeric(substr(names(serie.mensal.real)[nobsmes],1,4))
mes1=as.numeric(substr(names(serie.mensal.real)[nobsmes],6,7))+1
if(mes1==13) {
   mes1=1
   ano1=ano1+1
}

# pega apenas os dois primeiros meses
data1=as.Date(paste(ano1,"-",mes1,"-",1,sep=""))
periodo=data1+seq(0,62,1)
auxnomes=names(table(months(periodo)))
indice=grep(auxnomes[which(table(months(periodo))<28)],months(periodo))
periodo=periodo[-indice] # periodo de previsao

mes1=months(periodo[1])
if (monthmodel=="SVM"){
   # primeiro mes
   #Xdiasuteis1=getbizdays(substr(periodo[grep(mes1,months(periodo))],1,7),"Brazil/B3")[1] # numero de dias uteis do mes 1
   Xdiasuteis1=tail(Xdiasuteis,1)+1 # e uma tendencia, nao e o numero de dias uteis
   dias.semanas.mes1=weekdays1(periodo[grep(mes1,months(periodo))])
   dias.fim.semana=length(grep("sabado",dias.semanas.mes1))+length(grep("domingo",dias.semanas.mes1))
   Xmescarga.mes1=serie.mensal.real[nobsmes+1-lags[1:nnlag]]/100000
   padrao=t(c(Xmescarga.mes1,Xdiasuteis1))
   colnames(padrao)=colnames(dados_mes_treina0)[1:(dim(dados_mes_treina0)[2]-1)]

   previsao.mes1=predict(melhormodelo,padrao) # estimativas para o primeiro mes
   combinada1=previsao.mes1*100000

   # segundo mes
   serie.mensal.real=c(serie.mensal.real,combinada1) # insere previsao do mes anterior no historico
   xxx=serie.mensal.real
   ano2=as.numeric(substr(names(serie.mensal.real)[nobsmes],1,4))
   mes2=as.numeric(substr(names(serie.mensal.real)[nobsmes],6,7))+1
   if(mes2==13) {
      mes2=1
      ano2=ano2+1
   }
   nobsmes=nobsmes+1
   names(xxx)[nobsmes]=paste(ano2,"-",str_pad(mes2,2,pad="0"),sep="") # mudo de linha

   ano2=as.numeric(substr(tail(periodo,1),1,4))
   mes2=months(tail(periodo,1))
   dias.semanas.mes2=weekdays1(periodo[grep(mes2,months(periodo))])
   dias.fim.semana=length(grep("sabado",dias.semanas.mes2))+length(grep("domingo",dias.semanas.mes2))

   Xdiasuteis2=tail(Xdiasuteis,1)+2
   Xmescarga.mes2=serie.mensal.real[nobsmes+1-lags[1:nnlag]]/100000
   padrao=t(c(Xmescarga.mes2,Xdiasuteis2))
   colnames(padrao)=colnames(dados_mes_treina0)[1:(dim(dados_mes_treina0)[2]-1)]

   previsao.mes2=predict(melhormodelo,padrao) # estimativas para o historico mensal
   combinada2=previsao.mes2*100000
} else {
   combinada1=combinada2=c()
   ano2=as.numeric(substr(tail(periodo,1),1,4))
   mes2=months(tail(periodo,1))
}

# metricas insample
if (monthmodel=="SVM"){
   MAD=mean(abs(Ymescarga-estimativa))*100000
   MAPE=mean(abs(Ymescarga-estimativa)/Ymescarga)*100
   RMSE=sqrt(mean((Ymescarga-estimativa)^2))*100000
   utheil=Utheil(Ymescarga,estimativa)
   print(paste("PERFORMANCE SVM PREVISAO MENSAL -> MAD MW =",round(MAD,2),"/ MAPE% =",round(MAPE,2),"/ RMSE MW =",round(RMSE,2),"/ U-Theil = ",round(utheil,2)))
} else {
   MAD=MAPE=RMSE=utheil=c()
}
RESULTADOS=list(previsaomes1=combinada1,previsaomes2=combinada2,DADOS=data.frame(Ymescarga*100000,estimativa*100000),datames=data.frame(mes1,ano1,mes2,ano2),MAD=MAD,MAPE=MAPE,RMSE=RMSE,UTHEIL=utheil)
return(RESULTADOS)
}



#' @title Programa PREVISAO DE CARGA SEMANAL
#' @name PREVSEMANAL
#'
#' @description REALIZA A PREVISAO DE CARGA SEMANAL
#'
#' @param SERIES_SEMANAIS series semanais
#' @param DADOS conjunto de dados
#' @param tipotemp modelagem da temperatura
#' @param diretorioarquivosmodelo diretorio com modelos
#' @param weekmodel modelo semanal
#' @param lags1 lags do modelos para a primeira semana
#' @param lags2 lags dos modelos das demais semandas
#'
#' @return PREVISAO DE CARGA SEMANAL
PREVSEMANAL<-function(SERIES_SEMANAIS,DADOS,tipotemp,diretorioarquivosmodelo,weekmodel,lags1,lags2){
# se weekmodel e diferente de SVM o programa entra aqui apenas para pegar a estutura de dados das previsoes
# dados de entrada para a previsao
num.semanas.completas=SERIES_SEMANAIS$num.semanas.completas
Xmesesorigem=SERIES_SEMANAIS$DADOS_SEMANAIS$Xmesesorigem
carga.media.semanal=SERIES_SEMANAIS$DADOS_SEMANAIS$carga.media.semanal
data.inic.semana=SERIES_SEMANAIS$data.inic.semana
data.fim.semana=SERIES_SEMANAIS$data.fim.semana

# previsao semanal por ETS serve de parametro para escolher entre SVM nivel e SVM taxa de crescimento
#serie_semanal=ts(carga.media.semanal,frequency=365.25/7,start=data.inic.semana[1])
serie_semanal=ts(carga.media.semanal,frequency=52,start=data.inic.semana[1])
previsao_intervalo=forecast::forecast(serie_semanal,6)

# previsao semanal por SVM por taxa e nivel
previsoes=c()

if (weekmodel=="SVM"){
    # define os lags
    if (length(which(is.na(lags1)))>0) {
        # lags para a primeira semana
		aux=pacf(carga.media.semanal,60,plot=F)$acf
        lags1=which(abs(aux)>2/sqrt(length(carga.media.semanal)))
        print("lags definidos automaticamente para a primeira semana")
        print(lags1)
	} else {
	      print("lags definidos manualmente para a primeira semana")
        print(lags1)
    }
    if (length(which(is.na(lags2)))>0) {
        #lags2=1 # lags para as demais semanas
		aux=pacf(carga.media.semanal,60,plot=F)$acf
        lags2nivel=which(abs(aux)>2/sqrt(length(carga.media.semanal)))
		aux=pacf(SERIES_SEMANAIS$DADOS_SEMANAIS$diff.log.carga.media.semanal,60,plot=F)$acf
        lags2taxa=which(abs(aux)>2/sqrt(length(SERIES_SEMANAIS$DADOS_SEMANAIS$diff.log.carga.media.semanal)))
		lags2=intersect(lags2nivel,lags2taxa)
        print("lags definidos automaticamente para as demais semanas")
        print(lags2)
    } else {
	      print("lags definidos manualmente para as demais semanas")
        print(lags2)
	}

	# ajusta modelos SVM e faz as previsoes
    for (horizonte in 1:6){
        if (horizonte==1) {
		    # para a primeira previsao semanal apenas previsao por nivel
	      aux=SVMSEMANAL(DADOS,SERIES_SEMANAIS,lags1,tipotemp,horizonte,0)
		    OBSERVADO=aux$OBSERVADO
		    ESTIMADO=aux$ESTIMADO
			previsoes=c(previsoes,aux$PREVISAO)
	    }else{
		  # para as demais semanas ha previsoes por taxa e nivel
			auxnivel=SVMSEMANAL(DADOS,SERIES_SEMANAIS,lags2,tipotemp,horizonte,0) # modelo nivel
			auxtaxa=SVMSEMANAL(DADOS,SERIES_SEMANAIS,lags2,tipotemp,horizonte,1) # modelo taxa

			if (auxnivel$FERIADO>0) {
			   # se semana tem feriado pega a menor previsao
			   previsaohorizonte=min(auxnivel$PREVISAO,auxtaxa$PREVISAO)
			} else {
			   # se semana nao tem feriado pega a mais proxima do Holt-Winters
               if (abs(auxtaxa$PREVISAO-previsao_intervalo$mean[horizonte])<abs(auxnivel$PREVISAO-previsao_intervalo$mean[horizonte])) previsaohorizonte=auxtaxa$PREVISAO
    		   if (abs(auxtaxa$PREVISAO-previsao_intervalo$mean[horizonte])>=abs(auxnivel$PREVISAO-previsao_intervalo$mean[horizonte])) previsaohorizonte=auxnivel$PREVISAO
			}
            previsoes=c(previsoes,previsaohorizonte)
        }
    }

} else{
    # modelo de previsao semanal nao e o SVM
    ESTIMADO=OBSERVADO=c()
	  previsoes=rep(NA,6)
}

# previsao de carga semanal de 1 ate 6 semanas a frente
diasemana_previsao=weekdays1(as.Date(rownames(DADOS$DATAPREV)))
inic_semana_prev=which(diasemana_previsao=="sabado")
datas.inic.semanas=as.Date(rownames(DADOS$DATAPREV)[inic_semana_prev[1]])+seq(0,(6*7),7)
datas.fim.semanas=as.Date(rownames(DADOS$DATAPREV)[inic_semana_prev[1]])+seq(6,(6*7),7)
PREV.SEMANAIS=list(previsoes=previsoes,datas.inic.semanas=datas.inic.semanas,datas.fim.semanas=datas.fim.semanas)
seriesemanalcorrente=ts(serie_semanal[1:(length(serie_semanal)-1)])
previsao_intervalo_corrente=forecast::forecast(seriesemanalcorrente,1)

# JUNTA PREVISOES SEMANAIS AO HISTORICO SEMANAL
serie.semanal.completa=c(carga.media.semanal,previsoes) # historico e previsoes
datas.inic.semanal.completa=c(data.inic.semana,as.Date(datas.inic.semanas))
datas.fim.semanal.completa=c(data.fim.semana,as.Date(datas.fim.semanas))
n.total.semanas=length(serie.semanal.completa)
x1=serie.semanal.completa
x2=datas.inic.semanal.completa
x3=datas.fim.semanal.completa
PREV.SEMANAIS.HIST=list(serie.semanal.completa=x1,datas.inic.semanal.completa=x2,datas.fim.semanal.completa=x3,n.total.semanas=n.total.semanas)
if (weekmodel=="SVM") {
   # metricas de desempenho para previsao 1 mes a frente
   MAD=mean(abs(OBSERVADO-ESTIMADO))
   MAPE=mean(abs(OBSERVADO-ESTIMADO)/OBSERVADO)*100
   RMSE=sqrt(mean((OBSERVADO-ESTIMADO)^2))
   utheil=Utheil(OBSERVADO,ESTIMADO)
   print(paste("PERFORMANCE SVM PREVISAO SEMANAL -> MAD MW =",round(MAD,2),"/ MAPE% =",round(MAPE,2),"/ RMSE MW =",round(RMSE,2),"/ U-Theil =",round(utheil,2)))
}else{
   MAD=MAPE=RMSE=utheil=c()
}
RESULTADOS.PREV.SEMANAL=list(PREV.SEMANAIS=PREV.SEMANAIS,PREV.SEMANAIS.HIST=PREV.SEMANAIS.HIST,HOLTWINTERS.SEMANAL=previsao_intervalo,HOLTWINTERS.SEMANAL.CORRENTE=previsao_intervalo_corrente,ESTIMADO=ESTIMADO,OBSERVADO=OBSERVADO,MAD=MAD,MAPE=MAPE,RMSE=RMSE,UTHEIL=utheil)
return(RESULTADOS.PREV.SEMANAL)
}


#' @title Programa RELATORIO
#' @name RELATORIO
#'
#' @description GERA RELATORIO
#'
#' @param PREVISOES_SEMANAIS previsoes semanais
#' @param PREVISOES_MENSAIS previsoes mensais
#' @param DADOS conjunto de dados
#' @param SERIES_SEMANAIS series semanais
#' @param separador separador decimal
#' @param previsao.mes1 previsao aberta para o primeiro mes
#' @param tipoinput tipo do dado de entrada csv ou dataframe
#' @param caminho diretorio dos dados de entrada
#' @param cargaglobalcorrente carga global corrente
#' @param previsaosemanacorrente previsao semana corrente
#' @param semanacorrenteinic inicio da semena corrente
#' @param semanacorrentefim fim da semana corrente
#' @param diretorioarquivosmodelo diretorio com os modelos
#' @param extra controla gravacao de arquivos
#'
#' @return RELATORIO
RELATORIO<-function(PREVISOES_SEMANAIS,PREVISOES_MENSAIS,DADOS,SERIES_SEMANAIS,separador,previsao.mes1,tipoinput,caminho,cargaglobalcorrente,previsaosemanacorrente,semanacorrenteinic,semanacorrentefim,diretorioarquivosmodelo,extra){

# previsoes mensais
PREVISOES_MENSAIS$previsaomes1=previsao.mes1$previsaomes1
mes1=as.character(PREVISOES_MENSAIS$datames$mes1)
ano1=as.numeric(PREVISOES_MENSAIS$datames$ano1)
mes2=as.character(PREVISOES_MENSAIS$datames$mes2)
ano2=as.numeric(PREVISOES_MENSAIS$datames$ano2)
if (cargaglobalcorrente==-1) {
    previsao.demanda.media.mensal.MW=c(PREVISOES_MENSAIS$previsaomes1,PREVISOES_MENSAIS$previsaomes2)
    names(previsao.demanda.media.mensal.MW)=c(paste(mes1,"/",ano1,sep=""),paste(mes2,"/",ano2,sep=""))
} else {
    previsao.demanda.media.mensal.MW=c(cargaglobalcorrente,PREVISOES_MENSAIS$previsaomes1,PREVISOES_MENSAIS$previsaomes2)
    names(previsao.demanda.media.mensal.MW)=c(names(cargaglobalcorrente),paste(mes1,"/",ano1,sep=""),paste(mes2,"/",ano2,sep=""))
}
if (extra==1) {
   filename=paste(diretorioarquivosmodelo,"/FORECASTPMO_previsao_mensal_carga_global.csv",sep="")
   if (separador==0) {
       write.table(cbind(previsao.demanda.media.mensal.MW),file=filename,sep=";",dec=".")
   } else {
       write.table(cbind(previsao.demanda.media.mensal.MW),file=filename,sep=";",dec=",")
   }
}

print("============= Previsoes Mensais da Carga Global MW ==============")
print(previsao.demanda.media.mensal.MW)

print("==== Previsoes da Carga Global MW - abertas para o primeiro mes ====")
previsaoprimeiromes=previsao.mes1$previsaomes1
names(previsaoprimeiromes)=mes1
previsoesparciais=c(previsao.mes1$previsoes.parciais,previsaoprimeiromes) # a desagregacao do primeiro mes em semana foi feita antes
pesosprevisoesparciais=c(previsao.mes1$pesos,sum(previsao.mes1$pesos))
primeiro.mes.aberto=data.frame(previsoesparciais,pesosprevisoesparciais)
colnames(primeiro.mes.aberto)=c("Previsoes parciais MW","Pesos")
if (extra==1) {
   filename=paste(diretorioarquivosmodelo,"/FORECASTPMO_previsao_carga_global_mes_1_aberta.csv",sep="")
   if (separador==0) {
       write.table(primeiro.mes.aberto,file=filename,sep=";",dec=".")
   } else {
       write.table(primeiro.mes.aberto,file=filename,sep=";",dec=",")
   }
}
names(primeiro.mes.aberto)=c("MW","Dias")
print(primeiro.mes.aberto)

# previsoes semanais
previsao.demanda.media.semanal.MW=c(previsaosemanacorrente,PREVISOES_SEMANAIS$PREV.SEMANAIS$previsoes)
datas.inic.semanas=c(semanacorrenteinic,PREVISOES_SEMANAIS$PREV.SEMANAIS$datas.inic.semanas)
datas.fim.semanas=c(semanacorrentefim,PREVISOES_SEMANAIS$PREV.SEMANAIS$datas.fim.semanas)
names(previsao.demanda.media.semanal.MW)=as.character(datas.fim.semanas[1:7])
aux=data.frame(as.Date(datas.inic.semanas[1:7]),as.Date(datas.fim.semanas[1:7]),previsao.demanda.media.semanal.MW)
rownames(aux)=NULL
colnames(aux)=c("inicio","fim","Demanda Media MW")
if (extra==1) {
   filename=paste(diretorioarquivosmodelo,"/FORECASTPMO_previsao_semanal_carga_global.csv",sep="")
   if (separador==0) {
       write.table(aux,file=filename,sep=";",dec=".",row.names=F)
   } else {
       write.table(aux,file=filename,sep=";",dec=",",row.names=F)
   }
}
print("============ Previsoes Semanais da Carga Global MW ==============")
print(previsao.demanda.media.semanal.MW)

MENSAL=previsao.demanda.media.mensal.MW
PRIMEIROMES=primeiro.mes.aberto
SEMANAL=previsao.demanda.media.semanal.MW
#DIARIO=previsao.demanda.media.diaria.MW
return(list(MENSAL=MENSAL,PRIMEIROMES=PRIMEIROMES,SEMANAL=SEMANAL))
}



#' @title Programa LEITORADATAFRAME
#' @name LEITORADATAFRAME
#'
#' @description Realiza a leitura dos dados em formato dataframe
#'
#' @param dataframes nome do dataframe
#' @param tipotemp modelagem da temperatura
#'
#' @return Matriz com os dados lidos
LEITORADATAFRAME<-function(dataframes,tipotemp){
arqcarga=dataframes[["CARGAHIST"]] # arqcarga nome do arquivo com dados de carga CARGAHIST
if (tipotemp!=3) arqtemphist=dataframes[["TEMPHIST"]] # arqtemphist nome do arquivo com temperatura TEMPHIST
arqferiados=dataframes[["FERIADOS"]] # arqferiados nome do arquivo com feriados FERIADOS
arqhorizonte=dataframes[["HORIZONTE"]] # arqhorizonte nome do arquivo com dados do horizonte de previsao HORIZONTE
if (tipotemp!=3) arqtempprev=dataframes[["TEMPPPREV"]] # arqtempprev nome do arquivo com temperatura prevista TEMPREVISTA
#separadordec=dataframes[["SEPARADOR"]] # separadordec separador decimal 0 e ponto, diferente de 0 e virgula
separadordec=0

# VARIAVEIS DE SAIDA: DATAHIST: data.frame contendo dados de carga para cada dia do historico
#                               cada linha representa um dia
#                               colunas guardam a demanda media horaria, feriado e temperaturas
#                     DATAPREV: data.frame contendo dados para cada dia do horizonte de previsao
#                               cada linha representa um dia
#                               coluna guardam feriado, temperaturas previstas
#                     SERIEHIST: data.frame contendo dados historicos de carga, temperatura, feriados
#                     SERIEPREV: data.frame contendo dados previstos de temperatura, feriados e horario de verao
#                     DATAHIST, DATAPREV, SERIEHIST e SERIEPREV sao gravados na lista DADOSLIDOS
#                     MERGE: DATA FRAME COM MERGE DE DADOS DO PERIODO HISTORICO E PREVISAO
#
#=======================================================
# IDENTIFICA E CORRIGE EVENTUAIS ERROS NO CARGAHIST
# DECORRENTES DE PROBLEMAS COM O FIM DO HORARIO DE VERAO
#=======================================================
indice=duplicated(arqcarga$Data)
if (length(which(indice==T))>0){
   arqcarga$Carga[(which(indice==T)-1)]=(arqcarga$Carga[which(indice==T)]+arqcarga$Carga[(which(indice==T)-1)])/2
   arqcarga=arqcarga[-which(indice==T),]
}

#=======================================================
# LEITURA DO ARQUIVO COM DADOS DO HORIZONTE DE PREVISAO
#=======================================================
dados=arqhorizonte
# datas de inicio e fim do horizonte de previsao nas duas primeiras linhas de dados
indice=which(dados[,1]=="Instante inicial da previsao") # identifica linha da data inicial da previsao
data_inicio_prev=as.Date(paste(dados[indice,2],"-",dados[indice,3],"-",dados[indice,4],sep=""))
hora_inicio_prev=paste(dados[indice,5],":",dados[indice,6],sep="")
indice=which(dados[,1]=="Data final da previsao") # identifica linha da data final da previsao
data_final_prev=as.Date(paste(dados[indice,2],"-",dados[indice,3],"-",dados[indice,4],sep="")) # data final informada pelo usuario
hora_final_prev=paste(dados[indice,5],":",dados[indice,6],sep="")
if (weekdays1(data_final_prev)=="sabado") delta = 6
if (weekdays1(data_final_prev)=="domingo") delta = 5
if (weekdays1(data_final_prev)=="segunda-feira") delta = 4
if (weekdays1(data_final_prev)=="terca-feira") delta = 3
if (weekdays1(data_final_prev)=="quarta-feira") delta = 2
if (weekdays1(data_final_prev)=="quinta-feira") delta = 1
if (weekdays1(data_final_prev)=="sexta-feira") delta = 0
if (delta!=0) {
    print(paste("Mensagem: Horizonte de previsao informado",data_final_prev))
    data_final_prev=data_final_prev+delta
    print(paste("Mensagem: Horizonte de previsao alterado para",data_final_prev))
} else {
    print(paste("Mensagem: Horizonte de previsao informado",data_final_prev))
}
dias_previsao=seq(as.Date(data_inicio_prev), as.Date(data_final_prev), "days") # datas dos perfis
numdiasprev=length(dias_previsao)

# DATAS DOS FERIADOS NO HORIZONTE DE PREVISAO
indiceferiadoprev=which(dados[,1]=="feriado") # identifica linhas em dados com feriados
numferiados_prev=length(indiceferiadoprev)
x_feriados_prev=rep(0,numdiasprev)
if (numferiados_prev>0) {
    # entra aqui se ha feriados no horizonte de previsao
    for (i in 1:numferiados_prev) {
         ano=dados[indiceferiadoprev[i],2]
         mes=dados[indiceferiadoprev[i],3]
         dia=dados[indiceferiadoprev[i],4]
         feriados_horizonte=as.Date(paste(ano,"-",mes,"-",dia,sep=""))
         auxindice=grep(as.character(feriados_horizonte),as.character(dias_previsao),fixed=T)
         if (length(auxindice)>0) x_feriados_prev[auxindice]=dados[indiceferiadoprev[i],7][[1]][1] # 2026
    }
}
dadosprev=dados
print("======================== Leitura de dados ========================")
print("Leitura do data.frame com dados do horizonte de previsao")
rm(dados)

#=====================================================================
# LEITURA DO ARQUIVO COM DADOS DE CARGA E MONTAGEM DA SERIE HISTORICA
#=====================================================================
dados=arqcarga
data_carga=dados$Data
carga=dados$Carga

# gera sequencia de datas dos dias no historico
data_inic_hist=data_carga[1]
data_fim_hist=tail(data_carga,1)
dias_historico=seq(as.Date(data_inic_hist), as.Date(data_fim_hist), "days") # datas dos perfis
numdias=length(dias_historico) # numero de dias no historico com dados completos e incompletos
print("Leitura do data.frame com dados de carga")
rm(dados)

#=================================
# LEITURA DO ARQUIVO COM FERIADOS
#=================================
dados=arqferiados
data_feriados=as.Date(dados$Data)
x_feriados=rep(0,length(dias_historico))
numferiados=length(data_feriados)
for (i in 1:numferiados) {
     #indice=grep(data_feriados[i],as.character(dias_historico))
     indice=grep(data_feriados[i],(dias_historico))

     x_feriados[indice]=dados$Tipo[i]
}
rm(dados)
print("Leitura do data.frame com dados de feriados")

#=============================================
# LEITURA DO ARQUIVO COM DADOS DE TEMPERATURA
#=============================================
perfis_temperatura=matrix(0,numdias,3) # inicializa matriz de perfis
if (tipotemp!=3) {
    dados=arqtemphist
    data_temp=as.Date(dados$Data)
    for (i in 1:numdias) {
        indice=grep(as.character(dias_historico[i]),data_temp,fixed=T) # procura data informada pelo ONS em dias_historico
       	if (length(indice)>0) perfis_temperatura[i,]=c(dados$Exo_TmpMax[indice],dados$Exo_TmpMed[indice],dados$Exo_TmpMin[indice])
    }
    rownames(perfis_temperatura)=as.character(dias_historico)
    rm(dados)
    print("Leitura do data.frame com historico das variaveis exogenas")
}else{
    rownames(perfis_temperatura)=as.character(dias_historico)
}
#======================================
# CRIA DATA.FRAME COM DADOS HISTORICOS
#======================================
DATAHIST=data.frame(carga,x_feriados,perfis_temperatura)
SERIEHIST=data.frame(carga,x_feriados,perfis_temperatura)
colnames(SERIEHIST)=c("carga","feriado","temperatura_max","temperatura_media","temperatura_min")

#================================================
# LEITURA DO ARQUIVO COM PREVISAO DE TEMPERATURA
#================================================
perfis_temperatura_prev=matrix(0,numdiasprev,3) # inicializa matriz de perfis
if (tipotemp!=3) {
   dados=arqtempprev
   data_temprev=as.Date(dados$Data)
   data_inic_prev=data_temprev[1]
   data_fim_prev=as.Date(tail(data_temprev,1))+62 # 2 meses alem da ultima hora com temperatura prevista
   for (i in 1:numdiasprev) {
        indice=grep(as.character(dias_previsao[i]),data_temprev,fixed=T) # procura data informada pelo ONS em dias_historico
   	    if (length(indice)>0) perfis_temperatura_prev[i,1:3]=c(dados$Exo_TmpMax[indice],dados$Exo_TmpMed[indice],dados$Exo_TmpMin[indice])
   }
   rownames(perfis_temperatura_prev)=as.character(dias_previsao)
   rm(dados)
   print("Leitura do data.frame com previsoes das variaveis exogenas")
}else{
   rownames(perfis_temperatura_prev)=as.character(dias_previsao)
}

#====================================================
# CRIA DATA.FRAME COM DADOS DO HORIZONTE DE PREVISAO
#====================================================
DATAPREV=data.frame(x_feriados_prev,perfis_temperatura_prev)
SERIEPREV=data.frame(x_feriados_prev,perfis_temperatura_prev)

#=============================
# MERGE HISTORICO E HORIZONTE
#=============================
data_final_merge=as.Date(tail(dias_previsao,1))
datas=seq(as.Date(data_carga[1]),data_final_merge,1) # sequencia de datas desde o primeiro dia do historico
merge_feriados=rep(0,length(datas))
merge_feriados[1:length(x_feriados)]=x_feriados
if (numferiados_prev>0) {
    for (i in 1:numferiados_prev) {
         ano=dadosprev[indiceferiadoprev[i],2]
         mes=dadosprev[indiceferiadoprev[i],3]
         dia=dadosprev[indiceferiadoprev[i],4]
         feriados_horizonte=as.Date(paste(ano,"-",mes,"-",dia,sep=""))
         merge_feriados[which(datas==feriados_horizonte)]=dadosprev[indiceferiadoprev[i],7][[1]][1] # 2026
    }
}
MERGE=data.frame(merge_feriados) # MERGE HORARIO DE VERAO E FERIADOS
rownames(MERGE)=as.character(datas)
print("merge de dados historicos e previsoes concluido")
# EXPORTA LISTA DADOSLIDOS
DADOSLIDOS=list(DATAHIST=DATAHIST,DATAPREV=DATAPREV,SERIEHIST=SERIEHIST,SERIEPREV=SERIEPREV,MERGE=MERGE,separador=separadordec)
print("leitura de dados concluida")
return(DADOSLIDOS)
}


#' @title Programa WEEKDAYS1
#' @name weekdays1
#'
#' @description RETIRA O ACENTO DE STRINGS
#'
#' @param data conjunto de dados
#'
#' @return STRINGS SEM ACENTO
################# FUNCAO TIRA ACENTO DE DIA DA SEMANA
weekdays1 <-function(data) {
                # data = data
				# diasemana = dia da semana com acento
                # diasemanaSA = dia da semana sem acento

				datanum=as.numeric(format(as.Date(data),"%w"))
				diasemanaSA=datanum
				diasemanaSA[which(datanum==0)]="domingo"
				diasemanaSA[which(datanum==1)]="segunda-feira"
				diasemanaSA[which(datanum==2)]="terca-feira"
				diasemanaSA[which(datanum==3)]="quarta-feira"
				diasemanaSA[which(datanum==4)]="quinta-feira"
				diasemanaSA[which(datanum==5)]="sexta-feira"
				diasemanaSA[which(datanum==6)]="sabado"

				# diasemana=weekdays(as.Date(data))
				# diasemanaSA=iconv(diasemana, to = "ASCII//TRANSLIT")
				return(diasemanaSA)
}

#' @title Programa PREVDIA
#' @name PREVDIA
#'
#' @description Realiza a previsao da carga media diaria por regressao dinamica
#'
#' @param DADOS conjunto de dados
#' @param tipotemp modelagem da temperatura
#' @param extra controla
#'
#' @return previsao diaria
PREVDIA<-function(DADOS,tipotemp,extra){
         # https://otexts.com/fpp3/forecasting.html

   		   # marca feriados B3 nao marcados pelo ONS
		     diasemana2023=wday(as.Date(rownames(DADOS$DATAHIST)))
         tipodia2023=is.bizday(as.Date(rownames(DADOS$DATAHIST)),cal="Brazil/B3")
         feriados2023=which(tipodia2023==FALSE & (diasemana2023 >1 & diasemana2023 <=7) )
         aux2023=DADOS$DATAHIST[feriados2023,2]
         DADOS$DATAHIST[feriados2023,2]=ifelse(aux2023>0,aux2023,2)

		     print("Calcula fatores para desagregacao da carga mensal em semanal")
		     aux=data.frame(as.Date(rownames(DADOS$DATAHIST)),DADOS$DATAHIST)
		     rownames(aux)=NULL
		     names(aux)=c("date","carga","feriado","tmax","tmedia","tmin")
         dadosdiarios=as_tibble(aux)
		     #dadosdiarios=dadosdiarios%>%mutate(Holiday=ifelse(feriado>0,1,0))
 		     #dadosdiarios=dadosdiarios%>%mutate(feriado=ifelse(is.bizday(date,"Brazil/B3")==FALSE,1,0))	# workday = 0 , no workday = 1
		     dadosdiarios=dadosdiarios%>%mutate(DayType=ifelse(wday(date)==1 | wday(date)==7,"Weekend","Weekday"))
		     dadosdiarios=dadosdiarios%>%mutate(Holiday=ifelse(feriado==1 & DayType=="Weekday",1,0)) # marca feriados com is.bizday e wday
		     dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios # monta tsibble

		     dadosdiarios=dadosdiarios%>%mutate(mes=as.factor(month(date)))
		     dadosdiarios=dadosdiarios%>%mutate(DayType=as.factor(wday(date)))
         dadosdiarios=cria_interacoes(dadosdiarios)
		     dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios

     		 # ajusta modelo de regressao dinamica para previsao da carga diaria
		     fit <- dadosdiarios %>%
	  		     model(ARIMA(carga ~ PDQ(0, 0, 0) + trend() + xdom + xseg + xter + xqua + xqui + xsex + Holiday + xjan + xfev + xmar + xabr + xmai + xjun + xjul + xago + xset + xout + xnov) )

         ##########################
         # aqui começa a previsao #
         ##########################
		     # marca feriados B3 nao marcados pelo ONS
		     diasemana2023=wday(as.Date(rownames(DADOS$DATAPREV)))
         tipodia2023=is.bizday(as.Date(rownames(DADOS$DATAPREV)),cal="Brazil/B3")
         feriados2023=which(tipodia2023==FALSE & (diasemana2023 >1 & diasemana2023 <=7) )
         aux2023=DADOS$DATAHIST[feriados2023,1]
         DADOS$DATAHIST[feriados2023,1]=ifelse(aux2023>0,aux2023,1)

    		 # prepara dados para o previsor
	    	 aux=data.frame(as.Date(rownames(DADOS$DATAPREV)),DADOS$DATAPREV) # padroes de entrada
 		     rownames(aux)=NULL
 		     names(aux)=c("date","feriado","tmax","tmedia","tmin")
         dadosdiariosprev=as_tibble(aux)
		     dadosdiariosprev=dadosdiariosprev%>%mutate(Holiday=ifelse(feriado>0,1,0))
 		     #dadosdiariosprev=dadosdiariosprev%>%mutate(feriado=ifelse(is.bizday(date,"Brazil/B3")==FALSE,1,0))	# workday = 0 , no workday = 1
		     dadosdiariosprev=dadosdiariosprev%>%mutate(DayType=ifelse(wday(date)==1 | wday(date)==7,"Weekend","Weekday"))
		     dadosdiariosprev=dadosdiariosprev%>%mutate(Holiday=ifelse(feriado==1 & DayType=="Weekday",1,0)) # marca feriados com is.bizday e wday
 		     dadosdiariosprev=dadosdiariosprev%>%mutate(DayType=as.factor(wday(date)))
         dadosdiariosprev=dadosdiariosprev%>%mutate(mes=as.factor(month(date)))
	       dadosdiariosprev%>%as_tsibble(index=date) -> dadosdiariosprev

    	 	 # calcula medias historicas das temperaturas para cada dia do horizonte
	    	 diaprev=substr(dadosdiariosprev$date,6,10) # dias do periodo de previsao
		     diahist=substr(dadosdiarios$date,6,10) # dias do periodo historico
		     matriz_temp_dia=c()
		     for (i in 1:dim(dadosdiariosprev)[1]) {
		         indice=grep(diaprev[i],diahist)
		         if (i==1) {
		            matriz_temp_dia=apply(dadosdiarios[indice,c(4,5,6)],2,mean)
             }else{
		            matriz_temp_dia=rbind(matriz_temp_dia,apply(dadosdiarios[indice,c(4,5,6)],2,mean))
		         }
		     }
         # na primeira semana tem previsao de temperatura
		     for (i in 1:dim(dadosdiariosprev)[1]){
		         if (dadosdiariosprev$tmax[i]!=0) {
			          # substitua pela temperatura prevista caso ela seja dada
    	          matriz_temp_dia[i,]=c(dadosdiariosprev$tmax[i],dadosdiariosprev$tmedia[i],dadosdiariosprev$tmin[i]) # mantem a previsao de temperatura para a primeira semana
			       }
         }
		     # substitui temperaturas pelas temperaturas previstas
		     dadosdiariosprev=dadosdiariosprev%>%mutate(tmax=matriz_temp_dia[,1])
		     dadosdiariosprev=dadosdiariosprev%>%mutate(tmedia=matriz_temp_dia[,2])
		     dadosdiariosprev=dadosdiariosprev%>%mutate(tmin=matriz_temp_dia[,3])
		     dadosdiariosprev=cria_interacoes(dadosdiariosprev)
         saida_previsor=forecast(fit,dadosdiariosprev)

    		 previsao=saida_previsor$".mean"
		     aux=data.frame(aux,previsao)
         return(list(PREVISOES_DIARIAS=aux))
}


#' @title Programa SVMSEMANAL
#' @name SVMSEMANAL
#'
#' @description Realiza a previsao da carga media semanal por SVM
#'
#' @param DADOS conjunto de dados
#' @param SERIES_SEMANAIS series semanais
#' @param lags lags da carga
#' @param tipotemp modelagem da temperatura
#' @param horizonte horizonte de previsao
#' @param tipomodelo modelo
#'
#' @return previsao semanal
SVMSEMANAL<-function(DADOS,SERIES_SEMANAIS,lags,tipotemp,horizonte,tipomodelo){
          # tipomodelo = 0 modelo nivel
		  # tipomodelo = 1 modelo taxa apenas para horizonte > 1

          # MODELO SVM PARA PREVISAO DA CARGA SEMANAL
          num.semanas.completas=SERIES_SEMANAIS$num.semanas.completas
          Xmeses=SERIES_SEMANAIS$DADOS_SEMANAIS$Xmeses
		  Xmesesorigem=SERIES_SEMANAIS$DADOS_SEMANAIS$Xmesesorigem
		  dados_temperatura_semanais=SERIES_SEMANAIS$PERFIS$dados_temperatura_semanais
		  dados_tipo_semanais_feriado=SERIES_SEMANAIS$PERFIS$dados_tipo_semanais_feriado
		  carga.media.semanal=SERIES_SEMANAIS$DADOS_SEMANAIS$carga.media.semanal
		  data.inic.semana=SERIES_SEMANAIS$data.inic.semana
          data.fim.semana=SERIES_SEMANAIS$data.fim.semana

		  if (tipomodelo==1 & horizonte==1) tipomodelo=0
		  if (tipomodelo==1) {
		     sinal=SERIES_SEMANAIS$DADOS_SEMANAIS$diff.log.carga.media.semanal # modelo taxa
		     Ycarga0=tail(carga.media.semanal,1) # carga da ultima semana
		  } else {
		     print(paste("previsao",horizonte,"semana a frente"))
		  }
		  # MONTA PADROES ENTRADA E SAIDA PARA CADA VARIAVEL
		  # variavel temperatura
		  if (horizonte==1){
             if (tipotemp==0 | tipotemp==4) Xtemp=apply(dados_temperatura_semanais[(max(lags)+1):num.semanas.completas,],1,maximosemNA) # temperatura maxima semanal
             if (tipotemp==1) Xtemp=apply(dados_temperatura_semanais[(max(lags)+1):num.semanas.completas,],1,mediasemNA) # temperatura media semanal
             if (tipotemp==2){
                 Xtemp1=apply(dados_temperatura_semanais[(max(lags)+1):num.semanas.completas,],1,maximosemNA) # temperatura maxima semanal
                 Xtemp2=apply(dados_temperatura_semanais[(max(lags)+1):num.semanas.completas,],1,mediasemNA) # temperatura media semanal
                 Xtemp=cbind(Xtemp1,Xtemp2)
             }
		  }

          ultima_semana=week(data.fim.semana[(max(lags)+horizonte):(num.semanas.completas)])
		  ultima_semana=ifelse(ultima_semana>=52,1,0) # marca ultima semana do ano

		  #variavel feriado na semana da previsao
          Xferiados=dados_tipo_semanais_feriado[(max(lags)+horizonte):(num.semanas.completas),c(1,3,4,5,6,7)] # feriados nos dias uteis e sabado

          Xferiados1=0*Xferiados # para recodificar os feriados
		  # recodifica feriados
          if (length(which((Xferiados[,1]>0 & Xferiados[,1]<=4) | Xferiados[,1]==6 | Xferiados[,1]==8))>0) Xferiados1[which((Xferiados[,1]>0 & Xferiados[,1]<=4) | Xferiados[,1]==6 | Xferiados[,1]==8),1]=1 # feriado sábado
          if (length(which((Xferiados[,2]>0 & Xferiados[,2]<=4) | Xferiados[,2]==6 | Xferiados[,2]==8))>0) Xferiados1[which((Xferiados[,2]>0 & Xferiados[,2]<=4) | Xferiados[,2]==6 | Xferiados[,2]==8),2]=1 # feriado segunda
          if (length(which((Xferiados[,3]>0 & Xferiados[,3]<=4) | Xferiados[,3]==6 | Xferiados[,3]==8))>0) Xferiados1[which((Xferiados[,3]>0 & Xferiados[,3]<=4) | Xferiados[,3]==6 | Xferiados[,3]==8),3]=1 # feriado terca
          if (length(which((Xferiados[,4]>0 & Xferiados[,4]<=4) | Xferiados[,4]==5 | Xferiados[,4]==6 | Xferiados[,1]==8))>0) Xferiados1[which((Xferiados[,4]>0 & Xferiados[,4]<=4) | Xferiados[,4]==5 | Xferiados[,4]==6 | Xferiados[,4]==8),4]=1 # feriado quarta
          if (length(which((Xferiados[,5]>0 & Xferiados[,5]<=4) | Xferiados[,5]==6 | Xferiados[,5]==8))>0) Xferiados1[which((Xferiados[,5]>0 & Xferiados[,5]<=4) | Xferiados[,5]==6 | Xferiados[,5]==8),5]=1 # feriado quinta
          if (length(which((Xferiados[,6]>0 & Xferiados[,6]<=4) | Xferiados[,6]==6 | Xferiados[,6]==8))>0) Xferiados1[which((Xferiados[,6]>0 & Xferiados[,6]<=4) | Xferiados[,6]==6 | Xferiados[,6]==8),6]=1 # feriado sexta
	      Xferiados1=apply(Xferiados1,1,somasemNA) # 2023 soma feriados na semana
		  Xferiados1=ifelse(Xferiados1>0,1,0) # 2023

          # variavel feriado na semana corrente
          Xferiados2=dados_tipo_semanais_feriado[(max(lags):(num.semanas.completas-horizonte)),c(1,3,4,5,6,7)] # feriados nos dias uteis
          Xferiadobase=0*Xferiados2
          if (length(which((Xferiados2[,1]>0 & Xferiados2[,1]<=4) | Xferiados2[,1]==6 | Xferiados2[,1]==8))>0) Xferiadobase[which((Xferiados2[,1]>0 & Xferiados2[,1]<=4) | Xferiados2[,1]==6 | Xferiados2[,1]==8),1]=1 # feriado segunda
          if (length(which((Xferiados2[,2]>0 & Xferiados2[,2]<=4) | Xferiados2[,2]==6 | Xferiados2[,2]==8))>0) Xferiadobase[which((Xferiados2[,2]>0 & Xferiados2[,2]<=4) | Xferiados2[,2]==6 | Xferiados2[,2]==8),2]=1 # feriado segunda
          if (length(which((Xferiados2[,3]>0 & Xferiados2[,3]<=4) | Xferiados2[,3]==6 | Xferiados2[,3]==8))>0) Xferiadobase[which((Xferiados2[,3]>0 & Xferiados2[,3]<=4) | Xferiados2[,3]==6 | Xferiados2[,3]==8),3]=1 # feriado terca
          if (length(which((Xferiados2[,4]>0 & Xferiados2[,4]<=4) | Xferiados2[,4]==5 | Xferiados2[,4]==6 | Xferiados2[,4]==8))>0) Xferiadobase[which((Xferiados2[,4]>0 & Xferiados2[,4]<=4) | Xferiados2[,4]==5 | Xferiados2[,4]==6 | Xferiados2[,4]==8),4]=1 # feriado quarta
          if (length(which((Xferiados2[,5]>0 & Xferiados2[,5]<=4) | Xferiados2[,5]==6 | Xferiados2[,5]==8))>0) Xferiadobase[which((Xferiados2[,5]>0 & Xferiados2[,5]<=4) | Xferiados2[,5]==6 | Xferiados2[,5]==8),5]=1 # feriado quinta
          if (length(which((Xferiados2[,6]>0 & Xferiados2[,6]<=4) | Xferiados2[,6]==6 | Xferiados2[,6]==8))>0) Xferiadobase[which((Xferiados2[,6]>0 & Xferiados2[,6]<=4) | Xferiados2[,6]==6 | Xferiados2[,6]==8),6]=1 # feriado sexta
          Xferiadobase=apply(Xferiadobase,1,somasemNA) # soma feriados na semana
		  Xferiadobase=ifelse(Xferiadobase>0,1,0) # 2023

          # variavel carga
          Ycarga=Xcarga=base=valorMW=XXMW0=c()
          for (i in (max(lags)+1):(num.semanas.completas-horizonte+1)) {
		      if (tipomodelo==0){
                 Ycarga=c(Ycarga,carga.media.semanal[i+horizonte-1]) # target
				 Xcarga=rbind(Xcarga,carga.media.semanal[i-lags]) # valores passados
			  } else {
				 Ycarga=c(Ycarga,sum(sinal[i:(i+horizonte-1)])) # target
				 Xcarga=rbind(Xcarga,sinal[i-lags]) # valores passados
			  }
              base=c(base,carga.media.semanal[i-1])
			  valorMW=c(valorMW,carga.media.semanal[i+horizonte-1])
			  #XXMW0=c(XXMW0,log(tail(carga.media.semanal[i-1],1)))
			  XXMW0=c(XXMW0,log(carga.media.semanal[i-1]))

          }

		  # variavel meses
          matmeses=matrix(0,length(Ycarga),11)
          contador=0
          for (i in (max(lags)+horizonte):num.semanas.completas) {
              contador=contador+1
              if (Xmeses[i]!=12) matmeses[contador,Xmeses[i]]=1
          }

		  # TREINA MODELO SVM
          set.seed(1513)
          nn=length(lags)

		  # tendencia
   		  xtrend=seq(1,length(Ycarga),1)

		  if (horizonte==1) {
			 # na previsao da primeira semana pode ter temperatura como exogena
             if (tipotemp!=3) {
                dados_treina=cbind(Xcarga[,1:nn],Xtemp,Xferiados1,matmeses,Xferiadobase,xtrend,ultima_semana,Ycarga)
                #dados_treina=cbind(Xcarga[,1:nn],Xtemp,Xferiados1,matmeses,Xferiadobase,xtrend,Ycarga)
             } else {
                dados_treina=cbind(Xcarga[,1:nn],Xferiados1,matmeses,Xferiadobase,xtrend,ultima_semana,Ycarga)
                #dados_treina=cbind(Xcarga[,1:nn],Xferiados1,matmeses,Xferiadobase,xtrend,Ycarga)
             }
		  } else {
			 if (tipomodelo==0){
                # modelo MW
		  	    dados_treina=cbind(Xcarga[,1:nn],Xferiados1,matmeses,Xferiadobase,xtrend,ultima_semana,Ycarga)
		  	    #dados_treina=cbind(Xcarga[,1:nn],Xferiados1,matmeses,Xferiadobase,xtrend,Ycarga)
			 }else{
			    # modelo taxa
			    dados_treina=cbind(Xcarga[,1:nn],Xferiados1,matmeses,XXMW0,xtrend,ultima_semana,Ycarga) # nov 2023
			    #dados_treina=cbind(Xcarga[,1:nn],Xferiados1,matmeses,XXMW0,xtrend,Ycarga)
			 }
		  }
		  rownames(dados_treina)=NULL
          colnames(dados_treina)=c(paste("X",seq(1,(dim(dados_treina)[2]-1),1),sep=""),"Y")
          dados_treina=data.frame(dados_treina)

		  # conjunto de treinamento apenas com padroes de semanas com feriados
          #dados_treina_feriados=dados_treina_feriados[which(dados_treina_feriados[,1]>0),-1]
		  #rownames(dados_treina_feriados)=NULL
          #colnames(dados_treina_feriados)=c(paste("X",seq(1,(dim(dados_treina_feriados)[2]-1),1),sep=""),"Y")

          # AJUSTA SVM
    	  aux_sigmoide=tune(svm, Y ~., data = data.frame(dados_treina),ranges = list(kernel=c("sigmoid"),cost = c(1,10)))
    	  #aux_radial=tune(svm, Y ~., data = data.frame(dados_treina),ranges = list(kernel=c("radial"),cost = c(1,10),gamma=c(0.1,1)))
    	  aux_linear=tune(svm, Y ~., data = data.frame(dados_treina),ranges = list(kernel=c("linear"),cost = c(1,10)))

		  if (aux_linear$best.performance <= aux_sigmoide$best.performance) aux=aux_linear
  		  if (aux_linear$best.performance > aux_sigmoide$best.performance) aux=aux_sigmoide
		  #if ((aux_linear$best.performance <= aux_sigmoide$best.performance) & (aux_linear$best.performance <= aux_radial$best.performance)) aux=aux_linear
		  #if ((aux_radial$best.performance <= aux_sigmoide$best.performance) & (aux_radial$best.performance <= aux_linear$best.performance)) aux=aux_radial
		  #if ((aux_sigmoide$best.performance <= aux_linear$best.performance) & (aux_sigmoide$best.performance <= aux_radial$best.performance)) aux=aux_sigmoide

          melhormodelo=aux$best.model

          nnlag=nn
          dados_treina0=dados_treina
  		  rm(dados_treina)

          # MAPE E MAD insample
 		  estimado=c()
		  observado=c()
		  if (horizonte==1){
             # só calcula metrica insample no modelo de nivel 1 passao a frente
  	         observado=valorMW
		     names(observado)=data.fim.semana[(max(lags)+horizonte):num.semanas.completas]
             estimado=predict(melhormodelo,dados_treina0)
		     if (length(observado)!=length(estimado)) {
                # entra aqui se houve algum NA no predict
		        observado=observado[as.numeric(names(estimado))]
		     }
		  }

         # PREVISAO
		 XXtrend=tail(xtrend,1)+horizonte
         # monta padrao de entrada das variaveis para previsao
         if (horizonte==1) {
            # PREVISAO 1 SEMANA A FRENTE
            diasemana_previsao=weekdays1(as.Date(rownames(DADOS$DATAPREV)))
            inic_semana_prev=which(diasemana_previsao=="sabado") # indices dos sabados, semana operativa comeca nos sabados
            if (length(inic_semana_prev)>1) {
               fim_semana_prev=inic_semana_prev[2:length(inic_semana_prev)]-1 # indices das sextas, semana operativa termina na sexta
            } else {
               stop("horizonte de previsao menor que uma semana")
            }
			inicio=inic_semana_prev[1]
			final=fim_semana_prev[1]
			ultima_semana=week(as.Date(rownames(DADOS$DATAPREV))[final])
			ultima_semana=ifelse(ultima_semana>=52,1,0)
		 } else {
		    # PREVISAO DAS DEMAIS SEMANAS
			inicsem=as.Date(data.inic.semana[num.semanas.completas]+horizonte*7)
            ifimsem=as.Date(data.fim.semana[num.semanas.completas]+horizonte*7)
            inicio=grep(as.character(inicsem),rownames(DADOS$DATAPREV))
			final=grep(as.character(ifimsem),rownames(DADOS$DATAPREV))
			ultima_semana=week(as.Date(rownames(DADOS$DATAPREV))[final])
			ultima_semana=ifelse(ultima_semana>=52,1,0)
		 }

         # variavel feriados
         feriados.semanal=DADOS$DATAPREV[inicio:final,1] # igual Xferiados1aux
		 xferiados1=rep(0,7) # igual Xferiados1
         for (i in 1:length(feriados.semanal)) {
             if ((feriados.semanal[i]>0 & feriados.semanal[i]<=4) | feriados.semanal[i]==5 | feriados.semanal[i]==6 | feriados.semanal[i]==8) xferiados1[i]=1 # feriado na semana previsao
         }
		 xferiados1=sum(xferiados1[c(1,3,4,5,6,7)])
		 if (xferiados1>0) xferiados1=1
         XXferiadobase=sum(tail(Xferiados1,1)) # feriado na semana anterior
		 if (XXferiadobase>0) XXferiadobase=1

		 # variavel meses, pega o mes modal
         aux=substr(rownames(DADOS$DATAPREV)[inicio:final],6,7)
         Xmeses1=rep(0,11)
         if (as.numeric(names(which(table(aux)==max(table(aux)))))!=12){
            Xmeses1[as.numeric(names(which(table(aux)==max(table(aux)))))]=1
         }

		 # variavel temperatura
		 if (horizonte==1){
            if (tipotemp!=3){
               temperatura.semanal=c()
               for (i in inic_semana_prev[1]:fim_semana_prev[1]) {
                   temperatura.semanal=c(temperatura.semanal,as.numeric(DADOS$DATAPREV[i,2]))
               }
            }
            if (tipotemp==0 | tipotemp==4) Xtemp1=max(temperatura.semanal)
            if (tipotemp==1) Xtemp1=mean(temperatura.semanal)
            if (tipotemp==2) Xtemp1=c(max(temperatura.semanal),mean(temperatura.semanal))
		 }

 		 # valores passados da carga
		 if (tipomodelo==0){
            Xcarga1=Ycarga[length(Ycarga)+1-lags[1:nnlag]]
	     } else {
            Xcarga1=sinal[length(sinal)+1-lags[1:nnlag]]
         }
         Ycarga0=tail(carga.media.semanal,1) # carga da ultima semana

         # padrao de entrada para previsao
         if (tipomodelo==1){
		       # modelo taxa
               padrao.entrada.previsor=c(Xcarga1,xferiados1,Xmeses1,log(tail(carga.media.semanal,1)),XXtrend,ultima_semana) # nov 2023
 			   names(padrao.entrada.previsor)=paste("X",seq(1,length(padrao.entrada.previsor),1),sep="")
			   if (xferiados1>0) {
                  # se tem feriado na semana prevista pega a menor previsao
                  previsao.svm_linear=predict(aux_linear$best.model,data.frame(t(padrao.entrada.previsor))) # previsao da taxa de crescimento para a primeira semana do horizonte de previsao
		          previsao.svm_sigmoide=predict(aux_sigmoide$best.model,data.frame(t(padrao.entrada.previsor))) # previsao da taxa de crescimento para a primeira semana do horizonte de previsao
  			      if (previsao.svm_linear<=previsao.svm_sigmoide) previsao.svm=previsao.svm_linear
 			      if (previsao.svm_linear>previsao.svm_sigmoide) previsao.svm=previsao.svm_sigmoide
               } else {
                  previsao.svm=predict(melhormodelo,data.frame(t(padrao.entrada.previsor))) # previsao da taxa de crescimento para a primeira semana do horizonte de previsao
               }
               previsao=Ycarga0*exp(previsao.svm)
         } else {
               # modelo nivel
		       if (horizonte==1){
                  if (tipotemp!=3) {
                     padrao.entrada.previsor=c(Xcarga1,Xtemp1,xferiados1,Xmeses1,XXferiadobase,XXtrend,ultima_semana)
                  } else {
                     padrao.entrada.previsor=c(Xcarga1,xferiados1,Xmeses1,XXferiadobase,XXtrend,ultima_semana)
                  }
				  names(padrao.entrada.previsor)=paste("X",seq(1,length(padrao.entrada.previsor),1),sep="")
 			      if (xferiados1>0) {
  				     #previsao.svm=predict(melhormodelo1,data.frame(t(padrao.entrada.previsor)))
				     # se tem feriado na semana prevista pega a menor previsao
                     previsao.svm_linear=predict(aux_linear$best.model,data.frame(t(padrao.entrada.previsor))) # previsao da taxa de crescimento para a primeira semana do horizonte de previsao
		             previsao.svm_sigmoide=predict(aux_sigmoide$best.model,data.frame(t(padrao.entrada.previsor))) # previsao da taxa de crescimento para a primeira semana do horizonte de previsao
 			         if (previsao.svm_linear<=previsao.svm_sigmoide) previsao.svm=previsao.svm_linear
                     if (previsao.svm_linear>previsao.svm_sigmoide) previsao.svm=previsao.svm_sigmoide
                  } else {
                     previsao.svm=predict(melhormodelo,data.frame(t(padrao.entrada.previsor))) # previsao da taxa de crescimento para a primeira semana do horizonte de previsao
				  }
 		       }else{
			      # previsao alem da primeira semana do horizonte
		          if(xferiados1>0){
       	 	        padrao.entrada.previsor=c(Xcarga1,xferiados1,Xmeses1,XXferiadobase,XXtrend,ultima_semana)
          	        names(padrao.entrada.previsor)=paste("X",seq(1,length(padrao.entrada.previsor),1),sep="")

		            #previsao.svm=predict(melhormodelo1,data.frame(t(padrao.entrada.previsor)))
		            # se tem feriado na semana prevista pega a menor previsao
                    previsao.svm_linear=predict(aux_linear$best.model,data.frame(t(padrao.entrada.previsor))) # previsao da taxa de crescimento para a primeira semana do horizonte de previsao
		            previsao.svm_sigmoide=predict(aux_sigmoide$best.model,data.frame(t(padrao.entrada.previsor))) # previsao da taxa de crescimento para a primeira semana do horizonte de previsao
			        if (previsao.svm_linear<=previsao.svm_sigmoide) previsao.svm=previsao.svm_linear
			        if (previsao.svm_linear>previsao.svm_sigmoide) previsao.svm=previsao.svm_sigmoide
		          } else {
			        # entra aqui se nao ha feriados no horizonte de previsao, ajusta SVM sem semanas com feriados
			        indiceferiados=which(dados_treina0[,(nn+1)]>0)
	                dados_treina_local=dados_treina0[-indiceferiados,] # retira feriados e junto a ultima semana do ano
	                dados_treina_local=dados_treina_local[,-(nn+1)] # retira coluna de feriados
    				dados_treina_local=dados_treina_local[,-(dim(dados_treina_local)[2]-1)]# retira dado da ultima semana

   	                rownames(dados_treina_local)=NULL
                    colnames(dados_treina_local)=c(paste("X",seq(1,(dim(dados_treina_local)[2]-1),1),sep=""),"Y")
		    	    aux_sigmoide=tune(svm, Y ~., data = data.frame(dados_treina_local),ranges = list(kernel=c("sigmoid"),cost = c(1,10)))
    	            aux_linear=tune(svm, Y ~., data = data.frame(dados_treina_local),ranges = list(kernel=c("linear"),cost = c(1,10)))
		            if (aux_linear$best.performance <= aux_sigmoide$best.performance) melhormodelo=aux_linear$best.model
		            if (aux_linear$best.performance > aux_sigmoide$best.performance) melhormodelo=aux_sigmoide$best.model

	                padrao.entrada.previsor=c(Xcarga1,Xmeses1,XXferiadobase,XXtrend)
                    names(padrao.entrada.previsor)=paste("X",seq(1,(dim(dados_treina_local)[2]-1),1),sep="")
 	                previsao.svm=predict(melhormodelo,data.frame(t(padrao.entrada.previsor))) # previsao da taxa de crescimento para a primeira semana do horizonte de previsao
			      }
			   }
			   previsao=previsao.svm
		 }
         return(list(PREVISAO=previsao,OBSERVADO=observado,ESTIMADO=estimado,FERIADO=xferiados1))
}

#' @title Programa PREVSEMREGDIN
#' @name PREVSEMREGDIN
#'
#' @description Realiza a previsao da carga media semanal por regressao dinamica
#'
#' @param DADOS conjunto de dados
#' @param tipotemp modelagem da temperatura
#' @param nharm numero de componente harmonicas
#' @param extra controal gravacao de arquivo
#' @param diretorioarquivosmodelo diretorio com arquivos dos modelos
#' @param hiperparametros hiperpatametros dos modelos
#'
#' @return previsao semanal
PREVSEMREGDIN<-function(DADOS,tipotemp,nharm,extra,diretorioarquivosmodelo,hiperparametros){
     # https://otexts.com/fpp3/forecasting.html
		 print("== Primeiro modelo reg. dinamica para previsao da carga semanal ==")

		 # marca feriados B3 nao marcados pelo ONS
		 diasemana2023=wday(as.Date(rownames(DADOS$DATAHIST))) # dia da semana
     tipodia2023=is.bizday(as.Date(rownames(DADOS$DATAHIST)),cal="Brazil/B3") # classifica em dias uteis e em fim de semana/feriado
     feriados2023=which(tipodia2023==FALSE & ((diasemana2023>1 & diasemana2023<7) | (DADOS$DATAHIST[,2]==6|DADOS$DATAHIST[,2]==8))) # apenas feriados de segunda ate sexta
     aux2023=DADOS$DATAHIST[feriados2023,2] # marcacao do ONS nos feriados B3
     DADOS$DATAHIST[feriados2023,2]=ifelse(aux2023>0,aux2023,1) # marca com 1 feriados B3 nao marcados pelo ONS
		 DADOS$DATAHIST[which( (diasemana2023==1|diasemana2023==7) & (month(as.Date(rownames(DADOS$DATAHIST)))>1 & month(as.Date(rownames(DADOS$DATAHIST)))<12) ),2]=0 # cancela feriados sabados e domingos entre fevereiro e novembro

		 # leitura de dados diarios do historico
		 aux=data.frame(as.Date(rownames(DADOS$DATAHIST)),DADOS$DATAHIST)
		 rownames(aux)=NULL
		 names(aux)=c("date","carga","feriado","tmax","tmedia","tmin")
     dadosdiarios=as_tibble(aux) # monta tibble
		 dadosdiarios=dadosdiarios%>%mutate(Holiday=ifelse( (feriado>=1 & feriado<=4) | (feriado==6) | (feriado==8),1,0)) # dias especiais selecionados
		 dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios # monta tsibble
		 dadosdiarios=dadosdiarios%>%mutate(DayType=ifelse(wday(date)==1 | wday(date)==7,"Weekend","Weekday"))
		 #dadosdiarios=dadosdiarios%>%mutate(feriado=ifelse(Holiday==1 & (DayType=="Weekday" | month(date)==12),1,0)) # marca dias especiais em dias uteis e dezembro
		 dadosdiarios=dadosdiarios%>%mutate(feriado=Holiday)

		 dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios # monta tsibble

     # transforma series diarias em series semanais
     dadossemanais<-dadosdiarios%>%select(c(date,carga,feriado,tmax,tmedia,tmin,DayType))%>%
	   group_by_key() %>%
		    index_by(year_week = ~ yearweek(.,week_start = 6)) %>%
            summarise(
              carga_sem = mean(carga, na.rm = TRUE),
              feriado_sem = mean(feriado, na.rm = TRUE),
   			  tmax_sem = mean(ifelse(tmax>0,tmax,NA), na.rm = TRUE),
              tmedia_sem = mean(ifelse(tmedia>0,tmedia,NA), na.rm = TRUE),
              tmin_sem = mean(ifelse(tmin>0,tmin,NA), na.rm = TRUE),
     )
		 dadossemanais=dadossemanais%>%mutate(Holiday=ifelse(feriado_sem>0,1,0))
		 dadossemanais=dadossemanais%>%mutate(ultima_semana=ifelse((substr(year_week,6,8)=="W52" | substr(year_week,6,8)=="W53"),1,0))

		 # ajusta modelo de regressao dinamica para previsao da carga semanal
     modelo=as.formula(escreve_modelo_regdin1(hiperparametros,"carga_sem",tipotemp,nharm))

		 fit <- dadossemanais %>% model(ARIMA(modelo))
         resultados=augment(fit)
  	 # report(fit)
	   print(coef(fit))
 	   estimado=resultados$.fitted
		 MAD=mean(abs(resultados$.resid))
		 MAPE=100*mean(abs(resultados$.resid)/resultados$carga_sem)
		 RMSE=sqrt(mean(resultados$.resid^2))
		 utheil=Utheil(resultados$carga_sem,resultados$.fitted)
		 print(paste("PERFORMANCE PRIMEIRA REG.DINAMICA PREVISAO SEMANAL -> MAD MW =",round(MAD,2),"/ MAPE% =",round(MAPE,2),"/ RMSE MW =",round(RMSE,2),"/ U-Theil =",round(utheil,2)))
		 if (extra==1) {
            windows()
			      par(mfrow=c(2,2))
		        plot(dadossemanais$carga_sem,xlab="weeks",ylab="MW",main="dynamic reg. model to first week")
		        lines(estimado,lwd=2,col="blue")
            acf(resultados$.resid,24,main="ACF weekly residuals")
			      pacf(resultados$.resid,24,main="PACF weekly residuals")
			      hist(resultados$.resid,main="histogram of residuals",xlab="residuals")
	          filename=paste(diretorioarquivosmodelo,"/","weekly_data_dynamic_reg_first_week.csv",sep="")
		        dadossemanais=dadossemanais%>%mutate(estimado=estimado)
	          write.csv2(dadossemanais,filename)
		 }

		 ##########################
     # aqui inicia a previsao #
		 ##########################
 		 # marca feriados B3 nao marcados pelos ONS
		 diasemana2023=wday(as.Date(rownames(DADOS$DATAPREV)))
     tipodia2023=is.bizday(as.Date(rownames(DADOS$DATAPREV)),cal="Brazil/B3")
		 feriados2023=which(tipodia2023==FALSE & ((diasemana2023>1 & diasemana2023<7) | (DADOS$DATAPREV[,1]==6|DADOS$DATAPREV[,1]==8))) # apenas feriados de segunda ate sexta
     aux2023=DADOS$DATAPREV[feriados2023,1]
     #DADOS$DATAPREV[feriados2023,1]=ifelse(aux2023>0,aux2023,1)
		 #DADOS$DATAPREV[which( (diasemana2023==1|diasemana2023==7) & (month(as.Date(rownames(DADOS$DATAPREV)))>1 & month(as.Date(rownames(DADOS$DATAPREV)))<12) ),1]=0 # cancela feriados sabados e domingos entre fevereiro e novembro

		 # dados diarios do periodo de previsao
		 aux=data.frame(as.Date(rownames(DADOS$DATAPREV)),DADOS$DATAPREV) # padroes de entrada
 		 aux_historico=data.frame(as.Date(rownames(DADOS$DATAHIST)),DADOS$DATAHIST)
 		 rownames(aux)=NULL
 		 names(aux)=c("date","feriado","tmax","tmedia","tmin")
 		 if (dim(aux)[1]>7){
		    # inicia apos o dia 7 para preservar a previsao de temperatura para a primeira semana
		    for (i in 8:dim(aux)[1]){
                # pega temperaturas diarias no mesmo dia/mes da previsao nos anos anteriores, um mesmo dia tem varias temperaturas
		   	        temperaturas_diarias=DADOS$DATAHIST[day(as.Date(rownames(DADOS$DATAHIST)))==as.numeric(substr(rownames(DADOS$DATAPREV)[i],9,10)) & month(as.Date(rownames(DADOS$DATAHIST)))==as.numeric(substr(rownames(DADOS$DATAPREV)[i],6,7)),]
                # calcula as medias das temperaturas para o dia da previsao
			          aux[i,seq(3,5,1)]=apply(temperaturas_diarias[,seq(3,5,1)],2,mean)
  			}
 		 }
 		 aux <- janitor::clean_names(aux)
     dadosdiariosprev=as_tibble(aux)
 		 dadosdiariosprev=dadosdiariosprev%>%mutate(Holiday=ifelse( (feriado>=1 & feriado<=4) | (feriado==6) | (feriado==8),1,0))
		 dadosdiariosprev=dadosdiariosprev%>%mutate(DayType=ifelse(wday(date)==1 | wday(date)==7,"Weekend","Weekday"))
 		 dadosdiariosprev=dadosdiariosprev%>%mutate(feriado=ifelse(Holiday==1 & (DayType=="Weekday" | month(date)==12),1,0))
		 dadosdiariosprev%>%as_tsibble(index=date) -> dadosdiariosprev

 		 # junta dados diarios do historico e do periodo de previsao
     dadosdiariosprev<-bind_rows(dadosdiarios,dadosdiariosprev)

     # transforma series diarias em series semanais para previsao, toma media das series diarias
     dadossemanais_previsao<-dadosdiariosprev%>%select(c(date,carga,feriado,tmax,tmedia,tmin))%>%
 	   group_by_key() %>%
	   index_by(year_week = ~ yearweek(.,week_start = 6)) %>%
        summarise(
			  carga_sem=mean(carga, na.rm = TRUE),
              feriado_sem = mean(feriado, na.rm = TRUE),
			  tmax_sem = mean(ifelse(tmax>0,tmax,NA), na.rm = TRUE),
              tmedia_sem = mean(ifelse(tmedia>0,tmedia,NA), na.rm = TRUE),
              tmin_sem = mean(ifelse(tmin>0,tmin,NA), na.rm = TRUE),
        )
		 dadossemanais_previsao<-dadossemanais_previsao%>%mutate(Holiday=ifelse(feriado_sem>0,1,0))
		 dadossemanais_previsao<-dadossemanais_previsao%>%mutate(ultima_semana=ifelse((substr(year_week,6,8)=="W52" | substr(year_week,6,8)=="W53"),1,0))

     if (tipotemp>2){
        # sem temperatura
		    dadossemanais_previsao=dadossemanais_previsao%>%select(-tmax_sem,-tmedia_sem,-tmin_sem)
		 }

		 # data inicial da previsao
		 datainicial<-dadossemanais_previsao[which(is.na(dadossemanais_previsao[,2]))[1],1]

     # calcula previsao
		 xprev=dadossemanais_previsao%>%filter(yearweek(year_week,week_start = getOption("lubridate.week.start", 6))>=yearweek(datainicial$year_week[1],week_start = getOption("lubridate.week.start",6)))
		 xprev=xprev %>% select(-carga_sem)
		 saida_previsor=forecast(fit,xprev)
     #saida_previsor=forecast(fit,dadossemanais_previsao%>%filter(yearweek(year_week,week_start = getOption("lubridate.week.start", 6))>=yearweek(datainicial$year_week[1],week_start = getOption("lubridate.week.start",6))))
		 previsao=saida_previsor$".mean"
     return(list(PREVISOES_SEMANAIS=previsao,DADOS=resultados,MODELO=fit,MAD=MAD,MAPE=MAPE,RMSE=RMSE,UTHEIL=utheil))
}


#' @title Programa PREVMESREGDIN
#' @name PREVMESREGDIN
#'
#' @description Realiza a previsao da carga media mensal por regressao dinamica
#'
#' @param DADOS conjunto de dados
#' @param pega_acumulada_parcial usa resultados parciais da carga
#' @param extra controla gravacao de arquivo
#' @param diretorioarquivosmodelo diretorio com arquivos dos modelos
#' @param paramRDmes parametros do modelo de regressao dinamica
#' @param retira_ultimo_mes retira ultimo mes da serie
#' @param pandemia tratamento do periodo da pandemia
#'
#' @return previsao mensal
PREVMESREGDIN<-function(DADOS,pega_acumulada_parcial,extra,diretorioarquivosmodelo,paramRDmes,retira_ultimo_mes,pandemia){
     # https://otexts.com/fpp3/forecasting.html
		 if (pega_acumulada_parcial==1){
    	    print("==== Modelo de regressao dinamica para previsao da carga do primeiro mes ====")
	        print("====        carga acumulada parcial mensal como variavel explicativa     ====")
		 } else {
  		    print("====     Modelo de regressao dinamica para previsao da carga mensal      ====")
	        print("====  nao usa carga acumulada parcial mensal como variavel explicativa   ====")
		 }

		 # conta numero de dias uteis em cada mes
 		 ndiasuteis=getbizdays(substr(as.Date(rownames(DADOS$DATAHIST)),1,7),"Brazil/B3") # numero de dias uteis do mes de cada data
		 aux=data.frame(as.Date(rownames(DADOS$DATAHIST)),DADOS$DATAHIST,ndiasuteis) # historico
		 rownames(aux)=NULL
		 names(aux)=c("date","carga","feriado","tmax","tmedia","tmin","ndiasuteis")
     dadosdiarios=as_tibble(aux) # coloca dados no formato tibble
		 dadosdiarios=dadosdiarios%>%select(date,carga,ndiasuteis) # PREVISAO MENSAL NAO USA FERIADOS E TEMPERATURA

     if (pega_acumulada_parcial==1){
        # monta serie acumulada parcial do mes ate o dia substr(tail(aux$date,1),9,10)
	   		# calcula o acumulado parcial do mes para prever o mes completo
		    df=seq(as.Date(head(aux$date,1)),as.Date(tail(aux$date,1)),1) # datas do historico
		    result1 <- subset(df, format(df, '%d') == '01') # data inicial o dia 1 de cada mes
		  	dia_final=substr(tail(aux$date,1),9,10)
			  if (dia_final=="29" | dia_final=="30" | dia_final=="31") {
			    	auxmes=substr(aux$date,6,7) # pega mês
				    auxdia=rep(dia_final,length(df))
				    auxdia[which(auxmes=="02")]="28"
				    if (dia_final=="31"){
				        auxdia[which(auxmes=="04" | auxmes=="06" | auxmes=="09" | auxmes=="11")]="30"
				    }
		        result2 <- subset(df, format(df, '%d') == auxdia) # acumula ate o dia em result2
			  } else {
		        result2 <- subset(df, format(df, '%d') == dia_final) # acumula ate o dia em result2
			  }
		    acumulada=c()
		    for (i in 1:length(result2)){
		        i1=result1[i]
			      i2=result2[i]
				    acumulada=c(acumulada,mean(aux$carga[which(aux$date>=i1 & aux$date<=i2)]))
		    }
		 }
		 dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios # coloca dados no formato tsibble

     # transforma series diarias em series mensais
     dadosmensais<-dadosdiarios%>%select(c(date,carga,ndiasuteis))%>%
		 group_by_key() %>%
		    index_by(year_month = ~ yearmonth(.)) %>% # monthly aggregates
            summarise(
              carga_mes = mean(carga, na.rm = TRUE),
      	   	  ndiasuteis_mes=mean(ndiasuteis,na.rm=TRUE),
            )
     # inclui fator para o periodo da pandemia
     dadosmensais=dadosmensais%>%mutate(pandemia=case_when(year_month>=yearmonth("2020 mar") & year_month<=yearmonth("2020 aug") ~ 1,TRUE~0))

     if (pega_acumulada_parcial==1){
		    # entra aqui se revisao semanal (não REV0)
		    # agrega acumulado parcial no mes ao tsibble
        dadosmensais<-dadosmensais %>% mutate(acumulada=acumulada)
		  	acumulado_parcial=tail(dadosmensais$carga_mes,1)
		  	acumulado_mensal=tail(dadosmensais$acumulada,1)
		  	if (acumulado_parcial==acumulado_mensal) {
			     # tira o dado do ultimo mes, o mes corrente
			     ultimomes<-as.numeric(slice(dadosmensais,n():n())[5])
			     dadosmensais <- as_tsibble(slice(as_tibble(dadosmensais),1:(n()-1))) # remove ultima linha ou mes corrente
		  	}
      } else {
		    if (retira_ultimo_mes==1 | pega_acumulada_parcial==-1) {
   	       # retirar o ultimo dado mensal, entra aqui se revisal semanal (não REV0)
		       dadosmensais <- as_tsibble(slice(as_tibble(dadosmensais),1:(n()-1))) # remove ultima linha ou mes corrente
		    }else{
		  	   # não retira o ultimo dado mensal
    	     dadosmensais <- as_tsibble(as_tibble(dadosmensais))
		    }
      }

		  # ajusta modelo de regressao dinamica para previsao da carga mensal
 		  equacao=escreve_modelo_regdin_mes(paramRDmes,"carga_mes",pega_acumulada_parcial,pandemia)
      fit <- dadosmensais %>% model(equacao$equacao)
		  resultados=augment(fit)
	    cargamescorrente=as.numeric(tail(dadosmensais$carga_mes,1))
	 	  # report(fit)
 	    print(coef(fit))
      estimado=resultados$.fitted
		  MAD=mean(abs(resultados$.resid))
		  MAPE=100*mean(abs(resultados$.resid)/resultados$carga_mes)
		  RMSE=sqrt(mean(resultados$.resid^2))
		  utheil=Utheil(resultados$carga_mes,resultados$.fitted)
		  print(paste("PERFORMANCE REG.DINAMICA PREVISAO MENSAL -> MAD MW =",round(MAD,2),"/ MAPE% =",round(MAPE,2),"/ RMSE MW =",round(RMSE,2),"/ U-Theil =",round(utheil,2)))
 		  if (extra==1) {
         	windows()
		    	xxxtitulo="dynamic reg. fitted to monthly data"
			    if (pega_acumulada_parcial==1) xxxtitulo="dynamic reg. model to current month"
			    par(mfrow=c(2,2))
          plot(dadosmensais$carga_mes,xlab="months",ylab="MW",main=xxxtitulo)
	        lines(estimado,lwd=2,col="blue")
			    hist(resultados$.resid,main="histogram of residuals",xlab="residuals")
          acf(resultados$.resid,24,main="ACF monthly residuals")
          pacf(resultados$.resid,24,main="PACF monthly residuals")
			    dadosmensais=dadosmensais%>%mutate(estimado=estimado)
  		    filename=paste(diretorioarquivosmodelo,"/","monthly_data_dynamic_reg_model.csv",sep="")
			    write.csv2(dadosmensais,filename)
		 }

		 ##########################
     # aqui inicia a previsao #
		 ##########################
		 # ATENCAO A PREVISAO MENSAL NAO USA FERIADOS NEM TEMPERATURAS, MAS PEGA ESTAS INFORMACOES PARA OBTER O HORIZONTE DE PREVISAO
 		 ndiasuteis=getbizdays(substr(as.Date(rownames(DADOS$DATAPREV)),1,7),"Brazil/B3") # numero de dias uteis dos meses das datas
		 aux=data.frame(as.Date(rownames(DADOS$DATAPREV)),DADOS$DATAPREV,ndiasuteis) # padroes de entrada
 		 rownames(aux)=NULL
 		 names(aux)=c("date","feriado","tmax","tmedia","tmin","ndiasuteis")
     dadosdiariosprev=as_tibble(aux) # monta tibble para previsao
		 dadosdiariosprev=dadosdiariosprev%>%select(date,ndiasuteis)
		 dadosdiariosprev%>%as_tsibble(index=date) -> dadosdiariosprev

     # transforma serie diaria em serie mensal para previsao
     dadosmensais_previsao<-dadosdiariosprev%>%select(c(date,ndiasuteis))%>%
		 group_by_key() %>%
		    index_by(year_month = ~ yearmonth(.)) %>% # weekly aggregates
            summarise(
		   	      ndiasuteis_mes=mean(ndiasuteis,na.rm=TRUE),
            )

      if (pega_acumulada_parcial==1){
		     # revisao semanal, nao REV0
		     # previsao ate 1 mes a frente
			   dadosmensais_previsao <- slice(dadosmensais_previsao,1:1) # pega apenas primeira linha
 	       dadosmensais_previsao <- dadosmensais_previsao%>%add_column(acumulada=ultimomes)
	       dadosmensais_previsao <- dadosmensais_previsao%>%add_column(pandemia=0)

		     saida_previsor=forecast(fit,dadosmensais_previsao)
	   	   previsao=saida_previsor$".mean" # previsao para o mes corrente
			   dadosmensais_previsao=dadosmensais_previsao%>%mutate(previsao=previsao)
      }else{
         dadosmensais_previsao <- dadosmensais_previsao%>%add_column(pandemia=0)
         if (pega_acumulada_parcial==0){
             # REV0
		         if(head(dadosmensais_previsao$year_month,1)==tail(dadosmensais$year_month,1)) {
		            dadosmensais_previsao=dadosmensais_previsao[-1,]
             }
			    }

		      # previsao ate quatro meses a frente
		      saida_previsor=forecast(fit,dadosmensais_previsao)
	   	    previsao=saida_previsor$".mean" # previsao para os quatro meses a frente
			    dadosmensais_previsao=dadosmensais_previsao%>%mutate(previsao=previsao)
		 }
     return(list(PREVISOES_MENSAIS=previsao,DADOS=resultados,MODELO=fit,MAD=MAD,MAPE=MAPE,RMSE=RMSE,UTHEIL=utheil,cargamescorrente=cargamescorrente))
}

imprime_opcoes<-function(tipoestudo,tipomodelo,weekmodel,monthmodel,tipoinput,tipotemp,nharm){
   # IMPRIME OPCOES DE EXECUCAO
   cabecalho("1.0") # executa rotina cabecalho
   print("========================= Opcoes de execucao =====================")
   if (tipoestudo==0) {
       print("Revisao PMO")
   } else {
       print("PMO REV0")
   }
   if (weekmodel=="SVM") {
       print("Previsao da carga semanal com SVM")
   } else {
       if (weekmodel=="MRD"){
          print("Previsao da carga semanal com regressao dinamica")
          if (nharm<=0) {
             print("Modelos de regressao dinamica com ssa na modelagem da sazonalidade semanal")
	      } else {
             print(paste("Modelos de regressao dinamica semanal com",2*nharm,"componentes harmonicas"))
          }
       }else{
          print("Previsao da carga semanal com Holt-Winters")
       }
   }
   if (monthmodel=="SVM") print("previsao da carga mensal com SVM")
   if (monthmodel=="MHW") print("previsao da carga mensal com Holt-Winters")
   if (monthmodel=="MRD") print("previsao da carga mensal com regressao dinamica")
   if (monthmodel=="MBJ") print("previsao da carga mensal com modelo SARIMA")

   if (tipoinput==0) {
       print("Dados em arquivos CSV")
   } else {
       print("Dados em dataframe")
   }
   if (weekmodel!="MHW"){
      if (tipotemp==0) {
       print("Temperatura maxima no modelo de previsao semanal")
      } else {
        if (tipotemp==1) {
           print("Temperatura media no modelo de previsao semanal")
        } else {
           if (tipotemp==2) {
               print("Temperaturas media e maxima no modelo de previsao semanal")
           } else {
               if (tipotemp==3) {
                   print("Nao considera dados de temperatura na previsao semanal")
               } else {
                   print("Considera dados de temperatura com resolucao temporal diaria")
               }
           }
        }
      }
   }
}


faixa_temp<-function(x,media,dp){
            dataframe1=as.data.frame(x)
			limsup=media+dp
		    liminf=media-dp
  		    dummy1=ifelse(dataframe1[,4]>limsup,1,0)
 	        dummy2=ifelse(dataframe1[,4]<liminf,1,0)
			saida=list(quente=dummy1,frio=dummy2)
			return(saida)
}


#' @title Programa PREVSEMREGDIN2
#' @name PREVSEMREGDIN2
#'
#' @description Realiza a previsao semanal da semana 2 em diante
#'
#' @param DADOS conjunto de dados
#' @param tipotemp modelagem da temperatura
#' @param nharm numero de harmonicos
#' @param extra controla gravacao de arquivo
#' @param diretorioarquivosmodelo diretorio com arquivos dos modelos
#' @param hiperparametros hiperparametros do modelo de regressao dinamica
#'
#' @return previsao semanal
PREVSEMREGDIN2<-function(DADOS,tipotemp,nharm,extra,diretorioarquivosmodelo,hiperparametros){
         # https://otexts.com/fpp3/forecasting.html
		 print("==== Segundo modelo de regressao dinamica para previsao da carga semanal ====")

		 # marca feriados B3 nao marcados pelo ONS
		 diasemana2023=wday(as.Date(rownames(DADOS$DATAHIST)))
         tipodia2023=is.bizday(as.Date(rownames(DADOS$DATAHIST)),cal="Brazil/B3") # sepera dias em dia util (TRUE) ou feriado/fim de semana (FALSE)
         feriados2023=which(tipodia2023==FALSE & ((diasemana2023>1 & diasemana2023<7) | (DADOS$DATAHIST[,2]==6|DADOS$DATAHIST[,2]==8))) # apenas feriados de segunda ate sexta
         aux2023=DADOS$DATAHIST[feriados2023,2] # marcacoes de feriados pelo ONS nos dias de feriados da B3
         DADOS$DATAHIST[feriados2023,2]=ifelse(aux2023>0,aux2023,1) # coloca 1 nos dias marcados pela B3 mas nao pelo ONS
		 DADOS$DATAHIST[which( (diasemana2023==1|diasemana2023==7) & (month(as.Date(rownames(DADOS$DATAHIST)))>1 & month(as.Date(rownames(DADOS$DATAHIST)))<12) ),2]=0 # cancela feriados sabados e domingos entre fevereiro e novembro

		 # leitura de dados diarios do historico
		 aux=data.frame(as.Date(rownames(DADOS$DATAHIST)),DADOS$DATAHIST)
		 rownames(aux)=NULL
		 names(aux)=c("date","carga","feriado","tmax","tmedia","tmin")
         dadosdiarios=as_tibble(aux) # monta tibble
		 dadosdiarios=dadosdiarios%>%mutate(Holiday=ifelse( (feriado>=1 & feriado<=4) | (feriado==6) | (feriado==8),1,0))
		 dadosdiarios=dadosdiarios%>%mutate(DayType=ifelse(wday(date)==1 | wday(date)==7,"Weekend","Weekday")) # classifica os dias em dia da semana e fins de semana
		 #dadosdiarios=dadosdiarios%>%mutate(feriado=ifelse(Holiday==1 & (DayType=="Weekday" | month(date)==12),1,0)) # marca feriados em dias uteis ou em dezembro
		 dadosdiarios=dadosdiarios%>%mutate(feriado=Holiday) # marca feriados em dias uteis ou em dezembro

		 dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios # monta tsibble

         # transforma series diarias em series semanais
         dadossemanais<-dadosdiarios%>%select(c(date,carga,feriado,tmax,tmedia,tmin))%>%
		   group_by_key() %>%
		    index_by(year_week = ~ yearweek(.,week_start = 6)) %>%
            summarise(
              carga_sem = mean(carga, na.rm = TRUE),
              feriado_sem = mean(feriado, na.rm = TRUE),
			  tmax_sem = mean(ifelse(tmax>0,tmax,NA), na.rm = TRUE),
              tmedia_sem = mean(ifelse(tmedia>0,tmedia,NA), na.rm = TRUE),
              tmin_sem = mean(ifelse(tmin>0,tmin,NA), na.rm = TRUE),
            )
		 dadossemanais=dadossemanais%>%mutate(Holiday=ifelse(feriado_sem>0,1,0))
		 dadossemanais=dadossemanais%>%mutate(ultima_semana=ifelse((substr(year_week,6,8)=="W52" | substr(year_week,6,8)=="W53"),1,0))

		 dpx=sd(as.data.frame(dadossemanais)[,4])
		 mediax=mediasemNA(as.data.frame(dadossemanais)[,4])
 	 	 dummytempo=faixa_temp(dadossemanais,mediax,dpx) # cria dummy faixa temperatura
		 dadossemanais=dadossemanais%>%mutate(quente=dummytempo$quente)
		 dadossemanais=dadossemanais%>%mutate(frio=dummytempo$frio)

		 # ajusta modelo de regressao dinamica para previsao da carga semanal
		 equacao=escreve_modelo_regdin2(hiperparametros,"carga_sem",tipotemp,nharm)
         fit <- dadossemanais %>% model(equacao$equacao)
  	     resultados=augment(fit)
  	   # report(fit)
 	     print(coef(fit))
 	     estimado=resultados$.fitted
 		 MAD=mean(abs(resultados$.resid))
		 MAPE=100*mean(abs(resultados$.resid)/resultados$carga_sem)
		 RMSE=sqrt(mean(resultados$.resid^2))
		 utheil=Utheil(resultados$carga_sem,resultados$.fitted)
		 print(paste("PERFORMANCE SEGUNDA REG.DINAMICA PREVISAO SEMANAL -> MAD MW =",round(MAD,2),"/ MAPE% =",round(MAPE,2),"/ RMSE MW =",round(RMSE,2),"/ U-Theil =",round(utheil,2)))
		 if (extra==1) {
            windows()
			par(mfrow=c(2,2))
		    plot(dadossemanais$carga_sem,xlab="weeks",ylab="MW",main="dynamic reg. beyond the first week")
		    lines(estimado,lwd=2,col="blue")
            acf(resultados$.resid,24,main="ACF weekly residuals")
            pacf(resultados$.resid,24,main="PACF weekly residuals")
			hist(resultados$.resid,main="histogram of residuals",xlab="residuals")
			filename=paste(diretorioarquivosmodelo,"/","weekly_data_dynamic_reg.csv",sep="")
		    dadossemanais=dadossemanais%>%mutate(estimado=estimado)
            write.csv2(dadossemanais,filename)
		 }

		 ##########################
         # aqui inicia a previsao #
		 ##########################

		 # marca feriados B3 nao marcados pelos ONS
		 diasemana2023=wday(as.Date(rownames(DADOS$DATAPREV)))
         tipodia2023=is.bizday(as.Date(rownames(DADOS$DATAPREV)),cal="Brazil/B3")
		 feriados2023=which(tipodia2023==FALSE & ((diasemana2023>1 & diasemana2023<7) | (DADOS$DATAPREV[,1]==6|DADOS$DATAPREV[,1]==8))) # apenas feriados de segunda ate sexta
         aux2023=DADOS$DATAPREV[feriados2023,1]
		 # cancela para que o usuario tenha a possibilidade de marcar ou nao feriados no horizonte de previsao
         #DADOS$DATAPREV[feriados2023,1]=ifelse(aux2023>0,aux2023,1)
		 #DADOS$DATAPREV[which( (diasemana2023==1|diasemana2023==7) & (month(as.Date(rownames(DADOS$DATAPREV)))>1 & month(as.Date(rownames(DADOS$DATAPREV)))<12) ),1]=0 # cancela feriados sabados e domingos entre fevereiro e novembro

         # prepara dados para previsao
 		 # paga dados para o dias a serem previstos
		 aux=data.frame(as.Date(rownames(DADOS$DATAPREV)),DADOS$DATAPREV) # padroes de entrada para previsao
    	 rownames(aux)=NULL
 		 names(aux)=c("date","feriado","tmax","tmedia","tmin")
		 if (dim(aux)[1]>7){
		    # inicia apos o dia 7 para preservar a previsao de temperatura para a primeira semana
		    for (i in 8:dim(aux)[1]){
                # pega temperaturas diarias no mesmo dia/mes da previsao nos anos anteriores, um mesmo dia tem varias temperaturas
			    temperaturas_diarias=DADOS$DATAHIST[day(as.Date(rownames(DADOS$DATAHIST)))==as.numeric(substr(rownames(DADOS$DATAPREV)[i],9,10)) & month(as.Date(rownames(DADOS$DATAHIST)))==as.numeric(substr(rownames(DADOS$DATAPREV)[i],6,7)),]
                # calcula as medias das temperaturas para o dia da previsao
			    aux[i,seq(3,5,1)]=apply(temperaturas_diarias[,seq(3,5,1)],2,mean)
			}
		 }
 		 aux <- janitor::clean_names(aux)
     dadosdiariosprev=as_tibble(aux)
		 dadosdiariosprev=dadosdiariosprev%>%mutate(Holiday=ifelse( (feriado>=1 & feriado<=4) | (feriado==6) | (feriado==8),1,0)) # pegava feriado da deck, mas pode nao estar marcado
		 dadosdiariosprev=dadosdiariosprev%>%mutate(DayType=ifelse(wday(date)==1 | wday(date)==7,"Weekend","Weekday"))
 		 dadosdiariosprev=dadosdiariosprev%>%mutate(feriado=ifelse(Holiday==1 & (DayType=="Weekday" | month(date)==12),1,0)) # marca feriados com is.bizday e wday
		 dadosdiariosprev%>%as_tsibble(index=date) -> dadosdiariosprev

   		 # junta dados diarios do historico e do periodo de previsao
         dadosdiariosprev<-bind_rows(dadosdiarios,dadosdiariosprev)

         # transforma series diarias em series semanais para previsao, toma media das series diarias
         dadossemanais_previsao<-dadosdiariosprev%>%select(c(date,carga,feriado,tmax,tmedia,tmin))%>%
		   group_by_key() %>%
		    index_by(year_week = ~ yearweek(.,week_start=6)) %>%
            summarise(
			  carga_sem=mean(carga, na.rm = TRUE),
              feriado_sem = mean(feriado, na.rm = TRUE),
              tmax_sem = mean(ifelse(tmax>0,tmax,NA), na.rm = TRUE),
              tmedia_sem = mean(ifelse(tmedia>0,tmedia,NA), na.rm = TRUE),
              tmin_sem = mean(ifelse(tmin>0,tmin,NA), na.rm = TRUE),
            )
		 dadossemanais_previsao=dadossemanais_previsao%>%mutate(Holiday=ifelse(feriado_sem>0,1,0))
		 dadossemanais_previsao=dadossemanais_previsao%>%mutate(ultima_semana=ifelse((substr(year_week,6,8)=="W52" | substr(year_week,6,8)=="W53"),1,0))

	 	 dummytempo=faixa_temp(dadossemanais_previsao,mediax,dpx) # cria dummy faixa temperatura
		 dadossemanais_previsao=dadossemanais_previsao%>%mutate(quente=dummytempo$quente)
		 dadossemanais_previsao=dadossemanais_previsao%>%mutate(frio=dummytempo$frio)

		 # data inicial da previsao
		 datainicial<-dadossemanais_previsao[which(is.na(dadossemanais_previsao[,2]))[1],1]

		 # faz previsao
         saida_previsor=forecast(fit,dadossemanais_previsao%>%filter(yearweek(year_week,week_start = getOption("lubridate.week.start", 6))>=yearweek(datainicial$year_week[1],week_start = getOption("lubridate.week.start",6))))
		 previsao=saida_previsor$".mean"
         return(list(PREVISOES_SEMANAIS=previsao,DADOS=resultados,MODELO=fit,MAD=MAD,MAPE=MAPE,RMSE=RMSE,UTHEIL=utheil))
}

cria_interacoes<-function(dadosX){
 		 dadosX=dadosX%>%mutate(xdom=ifelse(wday(date)==1,1,0))
 		 dadosX=dadosX%>%mutate(xseg=ifelse(wday(date)==2,1,0))
 		 dadosX=dadosX%>%mutate(xter=ifelse(wday(date)==3,1,0))
 		 dadosX=dadosX%>%mutate(xqua=ifelse(wday(date)==4,1,0))
 		 dadosX=dadosX%>%mutate(xqui=ifelse(wday(date)==5,1,0))
 		 dadosX=dadosX%>%mutate(xsex=ifelse(wday(date)==6,1,0))
		 dadosX=dadosX%>%mutate(xjan=ifelse(month(date)==1,1,0))
		 dadosX=dadosX%>%mutate(xfev=ifelse(month(date)==2,1,0))
		 dadosX=dadosX%>%mutate(xmar=ifelse(month(date)==3,1,0))
		 dadosX=dadosX%>%mutate(xabr=ifelse(month(date)==4,1,0))
		 dadosX=dadosX%>%mutate(xmai=ifelse(month(date)==5,1,0))
		 dadosX=dadosX%>%mutate(xjun=ifelse(month(date)==6,1,0))
		 dadosX=dadosX%>%mutate(xjul=ifelse(month(date)==7,1,0))
		 dadosX=dadosX%>%mutate(xago=ifelse(month(date)==8,1,0))
		 dadosX=dadosX%>%mutate(xset=ifelse(month(date)==9,1,0))
		 dadosX=dadosX%>%mutate(xout=ifelse(month(date)==10,1,0))
		 dadosX=dadosX%>%mutate(xnov=ifelse(month(date)==11,1,0))
		 # interacoes
		 dadosX=dadosX%>%mutate(xdom_t=xdom*tmax)
 		 dadosX=dadosX%>%mutate(xseg_t=xseg*tmax)
 		 dadosX=dadosX%>%mutate(xter_t=xter*tmax)
 		 dadosX=dadosX%>%mutate(xqua_t=xqua*tmax)
 		 dadosX=dadosX%>%mutate(xqui_t=xqui*tmax)
 		 dadosX=dadosX%>%mutate(xsex_t=xsex*tmax)
		 dadosX=dadosX%>%mutate(xjan_t=xjan*tmax)
		 dadosX=dadosX%>%mutate(xfev_t=xfev*tmax)
		 dadosX=dadosX%>%mutate(xmar_t=xmar*tmax)
		 dadosX=dadosX%>%mutate(xabr_t=xabr*tmax)
		 dadosX=dadosX%>%mutate(xmai_t=xmai*tmax)
		 dadosX=dadosX%>%mutate(xjun_t=xjun*tmax)
		 dadosX=dadosX%>%mutate(xjul_t=xjul*tmax)
		 dadosX=dadosX%>%mutate(xago_t=xago*tmax)
		 dadosX=dadosX%>%mutate(xset_t=xset*tmax)
		 dadosX=dadosX%>%mutate(xout_t=xout*tmax)
		 dadosX=dadosX%>%mutate(xnov_t=xnov*tmax)
         return(dadosX)
}


#' @title Programa PREVMESSARIMA
#' @name PREVMESSARIMA
#'
#' @description Realiza a previsao mensal com SARIMA
#'
#' @param DADOS conjunto de dados
#' @param hiperparametros hiperparametros do SARIMA
#' @param extra controla gravacao de arquivo
#' @param diretorioarquivosmodelo diretorio com arquivos do modelo
#' @param tipoestudo tipo do estudo
#' @param retira_ultimo_mes retira ultimo mes da serie historica
#' @param pandemia tratamento do periodo da pandemia
#'
#' @return previsao mensal
PREVMESSARIMA<-function(DADOS,hiperparametros,extra,diretorioarquivosmodelo,tipoestudo,retira_ultimo_mes,pandemia){
         # https://otexts.com/fpp3/forecasting.html
		 print("==== Modelo SARIMA para previsao da carga mensal ====")

 		 ndiasuteis=getbizdays(substr(as.Date(rownames(DADOS$DATAHIST)),1,7),"Brazil/B3") # numero de dias uteis
		 aux=data.frame(as.Date(rownames(DADOS$DATAHIST)),DADOS$DATAHIST,ndiasuteis) # historico
		 rownames(aux)=NULL
		 names(aux)=c("date","carga","feriado","tmax","tmedia","tmin","ndiasuteis")
         dadosdiarios=as_tibble(aux) # coloca dados no formato tibble
		 dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios # coloca dados no formato tsibble

         # transforma serie diaria em serie mensal
         dadosmensais<-dadosdiarios%>%select(c(date,carga,ndiasuteis))%>%
		   group_by_key() %>%
		    index_by(year_month = ~ yearmonth(.)) %>% # monthly aggregates
            summarise(
              carga_mes = mean(carga, na.rm = TRUE),
			  ndiasuteis_mes=mean(ndiasuteis,na.rm=TRUE),
            )
		 #dadosmensais<-dadosmensais%>%mutate(carga_mes=carga_mes/ndiasuteis_mes) # corrige pelo numero de dias uteis

		 if (tipoestudo==0) {
		     #### REVISAO DO PMO
    		 horizonte=3
     	     dadosmensais <- as_tsibble(slice(as_tibble(dadosmensais),1:(n()-1))) # remove ultima linha ou mes corrente
		 } else {
		     #### REV0 DO PMO
    		 horizonte=3
			 if (retira_ultimo_mes==0) {
	  	        dadosmensais <- as_tsibble(as_tibble(dadosmensais))
		     } else {
     	        dadosmensais <- as_tsibble(slice(as_tibble(dadosmensais),1:(n()-1))) # remove ultima linha ou mes corrente
             }
	     }
 	     cargamescorrente=as.numeric(tail(dadosmensais$carga_mes,1))
 	     #cargamescorrente=as.numeric(tail(dadosmensais$carga_mes,1))*as.numeric(tail(dadosmensais$ndiasuteis_mes,1))

		 if (pandemia==1){
    		# corrige dados do periodo da pandemia
        print("mensagem: realizado tratamento do efeito da pandemia")
		    sem_pandemia=dadosmensais%>%filter(year_month<=yearmonth("2020 feb"))
		    modelo=sem_pandemia%>%
            model(ETS(carga_mes~error("M")+trend("A")+season("M")))
		    estimativa=modelo%>%forecast(h=6)
		    estimativa=estimativa$.mean
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 mar")),]$carga_mes=estimativa[1]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 apr")),]$carga_mes=estimativa[2]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 may")),]$carga_mes=estimativa[3]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 jun")),]$carga_mes=estimativa[4]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 jul")),]$carga_mes=estimativa[5]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 aug")),]$carga_mes=estimativa[6]
		 }

		 # ajusta modelo SARIMA para previsao da carga mensal
 		 equacao=escreve_modelo_sarima(hiperparametros,"carga_mes")
         fit <- dadosmensais %>% model(equacao$equacao)
  	     resultados=augment(fit)
   	  	 # fit <- dadosmensais %>%
     	 #	      model(ARIMA(carga_mes,stepwise=FALSE,approx=FALSE)) # AUTOARIMA

  	 # report(fit)
		 print(coef(fit))
     estimado=resultados$.fitted
 		 MAD=mean(abs(resultados$.resid))
		 MAPE=100*mean(abs(resultados$.resid)/resultados$carga_mes)
		 RMSE=sqrt(mean(resultados$.resid^2))
		 utheil=Utheil(resultados$carga_mes,resultados$.fitted)
		 print(paste("PERFORMANCE SARIMA PREVISAO MENSAL -> MAD MW =",round(MAD,2),"/ MAPE% =",round(MAPE,2),"/ RMSE MW =",round(RMSE,2),"/ U-Theil = ",round(utheil,2)))

	 	 if (extra==1) {
		    windows()
			par(mfrow=c(2,2))
            plot(dadosmensais$carga_mes,xlab="months",ylab="MW",main="SARIMA fitted to monthly data")
	        lines(estimado,lwd=2,col="blue")
            acf(resultados$.resid,24,main="ACF residuals")
            pacf(resultados$.resid,24,main="PACF residuals")
			hist(resultados$.resid,main="histogram of residuals",xlab="residuals")
			dadosmensais=dadosmensais%>%mutate(estimado=estimado)
  		    filename=paste(diretorioarquivosmodelo,"/","monthly_data_SARIMA.csv",sep="")
			write.csv2(dadosmensais,filename)
		 }

	    # PREVISAO
		saida_previsor=forecast(fit,h=horizonte)%>%hilo()

		intervalo=saida_previsor[,6]
        #saida_previsor=saida_previsor%>%mutate(dias=getbizdays(substr(as.Date(year_month),1,7),"Brazil/B3"))
        #saida_previsor=saida_previsor%>%mutate(.mean=.mean*dias)
        #intervalo=saida_previsor[,6]*saida_previsor$dias

    previsao=saida_previsor$".mean"
		datas=saida_previsor$"year_month"

    return(list(PREVISOES_MENSAIS=previsao,DADOS=resultados,MODELO=fit,MAD=MAD,MAPE=MAPE,RMSE=RMSE,UTHEIL=utheil,INTERVALOS=intervalo,cargamescorrente=cargamescorrente))
}

#' @title Programa PREVMESHW
#' @name PREVMESHW
#'
#' @description Realiza a previsao mensal com HOLT-WINTERS
#'
#' @param DADOS conjunto de dados
#' @param extra contrla gravacao de arquivo
#' @param diretorioarquivosmodelo diretorio com arquivos do modelo
#' @param tipoestudo tipo de estudo
#' @param retira_ultimo_mes retira ultimo mes da serie historica
#' @param pandemia tratamento do periodo da pandemia
#'
#' @return previsao mensal
PREVMESHW<-function(DADOS,extra,diretorioarquivosmodelo,tipoestudo,retira_ultimo_mes,pandemia){
         # https://otexts.com/fpp3/forecasting.html
		 print("======= Modelo Holt-Winters para previsao da carga mensal =======")

 		 ndiasuteis=getbizdays(substr(as.Date(rownames(DADOS$DATAHIST)),1,7),"Brazil/B3") # numero de dias uteis
		 aux=data.frame(as.Date(rownames(DADOS$DATAHIST)),DADOS$DATAHIST,ndiasuteis) # historico
		 rownames(aux)=NULL
		 names(aux)=c("date","carga","feriado","tmax","tmedia","tmin","ndiasuteis")
         dadosdiarios=as_tibble(aux) # coloca dados no formato tibble
		 dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios # coloca dados no formato tsibble

         # transforma serie diaria em serie mensal
         dadosmensais<-dadosdiarios%>%select(c(date,carga))%>%
		   group_by_key() %>%
		    index_by(year_month = ~ yearmonth(.)) %>% # monthly aggregates
            summarise(
              carga_mes = mean(carga, na.rm = TRUE),
			  ndiasuteis_mes=mean(ndiasuteis,na.rm=TRUE),
           )
  	     #dadosmensais<-dadosmensais%>%mutate(carga_mes=carga_mes/ndiasuteis_mes)

		 if (tipoestudo==0) {
		     #### REVISAO DO PMO
    		 horizonte=3
     	     dadosmensais <- as_tsibble(slice(as_tibble(dadosmensais),1:(n()-1))) # remove ultima linha ou mes corrente
		 } else {
		     #### REV0 DO PMO
    		 horizonte=3
	  	     #dadosmensais <- as_tsibble(as_tibble(dadosmensais))
			 if (retira_ultimo_mes==0) {
   	  	        dadosmensais <- as_tsibble(as_tibble(dadosmensais)) # remove ultima linha ou mes corrente
             } else {
      	        dadosmensais <- as_tsibble(slice(as_tibble(dadosmensais),1:(n()-1))) # NÃO remove ultima linha ou mes corrente
             }
	     }
	     cargamescorrente=as.numeric(tail(dadosmensais$carga_mes,1))
 	     #cargamescorrente=as.numeric(tail(dadosmensais$carga_mes,1))*as.numeric(tail(dadosmensais$ndiasuteis_mes,1))

       if (pandemia==1){
		    # corrige dados do periodo da pandemia
        print("mensagem: realizado tratamento do efeito da pandemia")
		    sem_pandemia=dadosmensais%>%filter(year_month<=yearmonth("2020 feb"))
		    modelo=sem_pandemia%>%
		           model(ETS(carga_mes~error("A")+trend("A")+season("A")))
		    estimativa=modelo%>%forecast(h=6)
		    estimativa=estimativa$.mean
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 mar")),]$carga_mes=estimativa[1]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 apr")),]$carga_mes=estimativa[2]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 may")),]$carga_mes=estimativa[3]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 jun")),]$carga_mes=estimativa[4]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 jul")),]$carga_mes=estimativa[5]
		    dadosmensais[which(dadosmensais$year_month==yearmonth("2020 aug")),]$carga_mes=estimativa[6]
		 }

		 # ajusta modelo HW para previsao da carga mensal
		 fit <- dadosmensais %>%
     		     model(
				   HWaditivo=ETS(carga_mes~error("A")+trend("A")+season("A")),
				   HWAAdA=ETS(carga_mes~error("A")+trend("Ad")+season("A")),
				   HWMAdM=ETS(carga_mes~error("M")+trend("Ad")+season("M")),
     		       HWmultiplicativo=ETS(carga_mes~error("M")+trend("A")+season("M"))
				 )
         selecionado=glance(fit)%>%filter(AICc==min(AICc,na.rm=TRUE))

         fit=fit%>%select(selecionado$.model)
		 resultados=augment(fit)
	 	 report(fit)
 		 MAD=mean(abs(resultados$.resid))
		 MAPE=100*mean(abs(resultados$.resid)/resultados$carga_mes)
		 RMSE=sqrt(mean(resultados$.resid^2))
		 utheil=Utheil(resultados$carga_mes,resultados$.fitted)
		 print(paste("PERFORMANCE HOLT-WINTERS PREVISAO MENSAL -> MAD MW =",round(MAD,2),"/ MAPE% =",round(MAPE,2),"/ RMSE MW =",round(RMSE,2),"/ U-Theil =",round(utheil,2)))

	    # PREVISAO
		saida_previsor=fit%>%forecast(h=horizonte)%>%hilo()
		intervalo=saida_previsor[,6]
    #saida_previsor=saida_previsor%>%mutate(dias=getbizdays(substr(as.Date(year_month),1,7),"Brazil/B3"))
    #saida_previsor=saida_previsor%>%mutate(.mean=.mean*dias)
    #intervalo=saida_previsor[,6]*saida_previsor$dias

    previsao=saida_previsor$".mean"
		datas=saida_previsor$"year_month"

        return(list(PREVISOES_MENSAIS=previsao,DADOS=resultados,MODELO=fit,MAD=MAD,MAPE=MAPE,RMSE=RMSE,UTHEIL=utheil,INTERVALOS=intervalo,cargamescorrente=cargamescorrente))
}

escreve_modelo_regdin1<-function(ordem,variavel,tipotemp,nharm){
       # escreve modelo de regressao dinamica
	   # ordem definida pelos hiperparametros
	   # variavel = nome da carga a ser prevista
	   # tipotemp = modelo de temperatura
	   # nharm = modelagem da sazonalidade semanal
       nomes=c("p","d","q","P","D","Q")
       indicepdq=which(!is.na(ordem[1:3]))
       indicePDQ=3+which(!is.na(ordem[4:6]))
       texto=variavel
       if (length(indicepdq)>0) {
           textopdq=paste(nomes[indicepdq],"=",ordem[indicepdq],collapse=",")
           texto=paste(texto,"~pdq(",textopdq,")",collapse="")
       }
       if (length(indicePDQ)>0) {
           textoPDQ=paste(nomes[indicePDQ],"=",ordem[indicePDQ],collapse=",")
           if (length(indicepdq)==0) texto=paste(texto,"~PDQ(",textoPDQ,")",collapse="")
           if (length(indicepdq)>0) texto=paste(texto,"+PDQ(",textoPDQ,")",collapse="")
       }
	   sinal="+"
	   if (length(indicepdq)==0 & length(indicePDQ)==0) sinal="~"
       if (tipotemp==0 & nharm>0) texto=paste(texto,sinal,"tmax_sem + Holiday + ultima_semana + fourier(K = nharm)",collapse="")
       if (tipotemp==1 & nharm>0) texto=paste(texto,sinal,"tmedia_sem + Holiday + ultima_semana + fourier(K = nharm)",collapse="")
       if (tipotemp==2 & nharm>0) texto=paste(texto,sinal,"tmax_sem + tmedia_sem + Holiday + ultima_semana + fourier(K = nharm)",collapse="")
	   if (tipotemp>2 & nharm>0) texto=paste(texto,sinal,"Holiday + fourier(K = nharm)",collapse="")
	   return(texto)
}

escreve_modelo_regdin2<-function(ordem,variavel,tipotemp,nharm){
       # escreve modelo de regressao dinamica
	   # ordem definida pelos hiperparametros
	   # variavel = nome da carga a ser prevista
	   # tipotemp = modelo de temperatura
	   # nharm = modelagem da sazonalidade semanal
       nomes=c("p","d","q","P","D","Q")
       indicepdq=which(!is.na(ordem[1:3]))
       indicePDQ=3+which(!is.na(ordem[4:6]))
       texto=paste("ARIMA(",variavel,collapse=",")
       if (length(indicepdq)>0) {
           textopdq=paste(nomes[indicepdq],"=",ordem[indicepdq],collapse=",")
           texto=paste(texto,"~pdq(",textopdq,")",collapse="")
       }
       if (length(indicePDQ)>0) {
           textoPDQ=paste(nomes[indicePDQ],"=",ordem[indicePDQ],collapse=",")
           if (length(indicepdq)==0) texto=paste(texto,"~PDQ(",textoPDQ,")",collapse="")
           if (length(indicepdq)>0) texto=paste(texto,"+PDQ(",textoPDQ,")",collapse="")
       }
	   sinal="+"
	   if (length(indicepdq)==0 & length(indicePDQ)==0) sinal="~"
       if (tipotemp<=2 & nharm>0) texto=paste(texto,sinal,"frio + quente + Holiday + ultima_semana + fourier(K = nharm))",collapse="")
       if (tipotemp>2 & nharm>0) texto=paste(texto,sinal,"Holiday + ultima_semana + fourier(K = nharm))",collapse="")
       equacao=eval(parse(text=texto))
       return(list(equacao=equacao,texto=texto))
}

escreve_modelo_regdin_mes<-function(ordem,variavel,pega_acumulada_parcial,pandemia){
       # escreve modelo de regressao dinamica
	   # ordem definida pelos hiperparametros
	   # variavel = nome da carga a ser prevista
	   # pega_acumulada_parcial==1 para o caso de nao REV0
	   # pandemia == 1 inclui dummy da pandemia
       nomes=c("p","d","q","P","D","Q")
       indicepdq=which(!is.na(ordem[1:3]))
       indicePDQ=3+which(!is.na(ordem[4:6]))
       texto=paste("ARIMA(",variavel,collapse=",")
       if (length(indicepdq)>0) {
           textopdq=paste(nomes[indicepdq],"=",ordem[indicepdq],collapse=",")
           texto=paste(texto,"~pdq(",textopdq,")",collapse="")
       }
       if (length(indicePDQ)>0) {
           textoPDQ=paste(nomes[indicePDQ],"=",ordem[indicePDQ],collapse=",")
           if (length(indicepdq)==0) texto=paste(texto,"~PDQ(",textoPDQ,")",collapse="")
           if (length(indicepdq)>0) texto=paste(texto,"+PDQ(",textoPDQ,")",collapse="")
       }
	   sinal="+"
	   if (length(indicepdq)==0 & length(indicePDQ)==0) sinal="~"
       #if (pega_acumulada_parcial==1) texto=paste(texto,sinal,"acumulada + season())",collapse="")
       #if (pega_acumulada_parcial!=1) texto=paste(texto,sinal,"season())",collapse="")
	   if (pandemia==1) {
           if (pega_acumulada_parcial==1) texto=paste(texto,sinal,"acumulada + pandemia + ndiasuteis_mes + season())",collapse="")
           if (pega_acumulada_parcial!=1) texto=paste(texto,sinal,"ndiasuteis_mes + pandemia + season())",collapse="")
	   }else{
           if (pega_acumulada_parcial==1) texto=paste(texto,sinal,"acumulada + ndiasuteis_mes + season())",collapse="")
           if (pega_acumulada_parcial!=1) texto=paste(texto,sinal,"ndiasuteis_mes + season())",collapse="")
	   }

       equacao=eval(parse(text=texto))
       return(list(equacao=equacao,texto=texto))
}

escreve_modelo_sarima<-function(ordem,variavel){
       # escreve modelo de regressao dinamica
	   # ordem definida pelos hiperparametros
	   # variavel = nome da carga a ser prevista
       nomes=c("p","d","q","P","D","Q")
       indicepdq=which(!is.na(ordem[1:3]))
       indicePDQ=3+which(!is.na(ordem[4:6]))
       texto=paste("ARIMA(",variavel,collapse=",")
       if (length(indicepdq)>0) {
           textopdq=paste(nomes[indicepdq],"=",ordem[indicepdq],collapse=",")
           texto=paste(texto,"~pdq(",textopdq,")",collapse="")
       }
       if (length(indicePDQ)>0) {
           textoPDQ=paste(nomes[indicePDQ],"=",ordem[indicePDQ],collapse=",")
           if (length(indicepdq)==0) texto=paste(texto,"~PDQ(",textoPDQ,")",collapse="")
           if (length(indicepdq)>0) texto=paste(texto,"+PDQ(",textoPDQ,")",collapse="")
       }
	   if (length(indicepdq)==0 & length(indicePDQ)==0) paste(texto,"stepwise = FALSE, approx = FALSE",collapse="") # modelo auto
	   texto=paste(texto,")",collapse="")
       equacao=eval(parse(text=texto))
       return(list(equacao=equacao,texto=texto))
}

Utheil<-function(obs,prev){
      # calcula U-Theil
      ft=(prev[2:length(prev)]-obs[2:length(obs)])/obs[1:(length(obs)-1)]
      at=(obs[2:length(prev)]-obs[1:(length(obs)-1)])/obs[1:(length(obs)-1)]
      utheil=sqrt(sum(ft^2)/sum(at^2))
      return(utheil)
}

#' @title Programa PREVSEMHW
#' @name PREVSEMHW
#'
#' @description Realiza a previsao da carga media semanal por Holt-Winters
#'
#' @param DADOS conjunto de dados
#' @param tipotemp modelagem da temperatura
#' @param nharm numero de componentes harmonicas
#' @param extra controla gravacao de arquivo
#' @param diretorioarquivosmodelo diretorio com arquivos do modelo
#' @param hiperparametros hiperparametros do modelo
#'
#' @return previsao semanal
PREVSEMHW<-function(DADOS,tipotemp,nharm,extra,diretorioarquivosmodelo,hiperparametros){
	 # https://rstudio-pubs-static.s3.amazonaws.com/739393_3289bc415c8e4e3295e168a9f149685e.html
	 print("==== Previsao da carga semanal com Holt-Winters ====")
     # leitura de dados diarios do historico
	 aux=data.frame(as.Date(rownames(DADOS$DATAHIST)),DADOS$DATAHIST)
	 rownames(aux)=NULL
	 names(aux)=c("date","carga","feriado","tmax","tmedia","tmin")
     dadosdiarios=as_tibble(aux) # monta tibble
	 #dadosdiarios=dadosdiarios%>%mutate(Holiday=ifelse(feriado>0,1,0)) # pegava feriado da deck, mas pode nao estar marcado
	 dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios # monta tsibble
 	 dadosdiarios=dadosdiarios%>%mutate(Holiday=ifelse(is.bizday(date,"Brazil/B3")==FALSE,1,0))	# workday = 0 , no workday = 1
	 dadosdiarios=dadosdiarios%>%mutate(DayType=ifelse(wday(date)==1 | wday(date)==7,"Weekend","Weekday"))
	 dadosdiarios=dadosdiarios%>%mutate(feriado=ifelse(Holiday==1 & DayType=="Weekday",1,0)) # marca feriados com is.bizday e wday
	 dadosdiarios%>%as_tsibble(index=date) -> dadosdiarios # monta tsibble

     # transforma series diarias em series semanais
     dadossemanais<-dadosdiarios%>%select(c(date,carga,feriado,tmax,tmedia,tmin))%>%
	 group_by_key() %>%
	 index_by(year_week = ~ yearweek(.,week_start = 6)) %>%
         summarise(
            carga_sem = mean(carga, na.rm = TRUE)
         )

	 # ajusta modelo de Holt-Winters para previsao da carga semanal
	 my_dcmp_spec <- decomposition_model(
                     STL(carga_sem),
                     ETS(season_adjust ~ season("N"))
     )
     fit<-dadossemanais %>%
          model(stl_ets = my_dcmp_spec)
	 report(fit)

     resultados=augment(fit)
     resultados=augment(fit)[which(!is.na(resultados$.resid)),] # retiras as linhas com NA
 	 estimado=resultados$.fitted
 	 MAD=mean(abs(resultados$.resid),na.rm=T)
	 MAPE=100*mean(abs(resultados$.resid)/resultados$carga_sem)
	 RMSE=sqrt(mean(resultados$.resid^2,na.rm=T))
	 utheil=Utheil(resultados$carga_sem,resultados$.fitted)
	 print(paste("PERFORMANCE HOLT-WINTERS PREVISAO SEMANAL -> MAD MW =",round(MAD,2),"/ MAPE% =",round(MAPE,2),"/ RMSE MW =",round(RMSE,2),"/ U-Theil =",round(utheil,2)))

     # PREVISAO
 	 # dados diarios do periodo de previsao
	 aux=data.frame(as.Date(rownames(DADOS$DATAPREV)),DADOS$DATAPREV) # padroes de entrada
	 rownames(aux)=NULL
	 names(aux)=c("date","feriado","tmax","tmedia","tmin")
     dadosdiariosprev=as_tibble(aux)
	 dadosdiariosprev=dadosdiariosprev%>%mutate(Holiday=ifelse(is.bizday(date,"Brazil/B3")==FALSE,1,0))	# workday = 0 , no workday = 1
	 dadosdiariosprev=dadosdiariosprev%>%mutate(DayType=ifelse(wday(date)==1 | wday(date)==7,"Weekend","Weekday"))
	 dadosdiariosprev=dadosdiariosprev%>%mutate(feriado=ifelse(Holiday==1 & DayType=="Weekday",1,0)) # marca feriados com is.bizday e wday
	 dadosdiariosprev%>%as_tsibble(index=date) -> dadosdiariosprev

	 # junta dados diarios do historico e do periodo de previsao
     dadosdiariosprev<-bind_rows(dadosdiarios,dadosdiariosprev)

     # transforma series diarias em series semanais para previsao
     dadossemanais_previsao<-dadosdiariosprev%>%select(c(date,carga,feriado,tmax,tmedia,tmin))%>%
           group_by_key() %>%
		      index_by(year_week = ~ yearweek(.,week_start = 6)) %>%
              summarise(
			    carga_sem=mean(carga, na.rm = TRUE),
                feriado_sem = mean(feriado, na.rm = TRUE),
			    tmax_sem = mean(ifelse(tmax>0,tmax,NA), na.rm = TRUE),
                tmedia_sem = mean(ifelse(tmedia>0,tmedia,NA), na.rm = TRUE),
                tmin_sem = mean(ifelse(tmin>0,tmin,NA), na.rm = TRUE),
            )
	 dadossemanais_previsao<-dadossemanais_previsao%>%mutate(Holiday=ifelse(feriado_sem>0,1,0))

	 # data inicial da previsao
	 datainicial<-dadossemanais_previsao[which(is.na(dadossemanais_previsao[,2]))[1],1]

	 # faz previsao
     saida_previsor=forecast(fit,dadossemanais_previsao%>%filter(yearweek(year_week,week_start = getOption("lubridate.week.start", 6))>=yearweek(datainicial$year_week[1],week_start = getOption("lubridate.week.start",6))))
	 previsao=saida_previsor$".mean"
     return(list(PREVISOES_SEMANAIS=previsao,DADOS=resultados,MODELO=fit,MAD=MAD,MAPE=MAPE,RMSE=RMSE,UTHEIL=utheil))
}

concilia_com_retricao<-function(dias,semanais,mes,restricao,feriados){
  # concilia previsoes semanais e mensais com restricoes de que algumas nao mudam com o ajuste
  # restricao de que algumas previsoes base nao mudam apos a reconciliacao
  # restricao = posicao da previsao que nao muda no vetor semanais
  m=length(semanais) # numero de previsoes semanais
  n=m+1 # numero de previsoes semanais mais uma mensal
  k=length(restricao) # numero de previsoes semanais imutaveis

  feriados[which(feriados>=1)]=1
  if (length(which(is.na(feriados)))>0) feriados[which(is.na(feriados))]=0
  feriados=feriados[1:(length(semanais)-length(restricao))]

  previsoes=c(mes,as.numeric(semanais))
  w0=c(sum(dias),dias)
  previsoes=previsoes*w0

  S=rep(1,length(semanais))
  S1=S[-restricao]
  S2=rep(1,k)
  S1til=rbind(S1,diag(length(S1)))
  vchapeu=c(mes-S2*as.numeric(semanais[restricao]),as.numeric(semanais[-restricao]))

  vetor1=w0
  vetor1=vetor1[-(1+restricao)]
  #vetor1[1]=1000*vetor1[1]
  vetor1[1]=1*vetor1[1]  # MUDEI AQUI PASSOU A SER O TOTAL DE DIAS DO MES 2024
  #vetor1[1]=50-length(restricao)
  #vetor1[2:length(vetor1)]=feriados*100+(1-feriados)*100
  Wv=diag(vetor1)
  #Wv=diag(n-k)
  #Wv=c(0,feriados)*9+1
  #Wv=diag(Wv[1:(n-k)])

  G1=solve(t(S1til)%*%solve(Wv)%*%S1til)%*%t(S1til)%*%solve(Wv)
  b1=rbind(cbind(G1,matrix(0,(m-k),k)),cbind(matrix(0,k,(n-k)),diag(k)))
  b2=diag(n)-rbind(cbind(matrix(0,(n-m),(n-k)),t(as.matrix(S2,1,2))),matrix(0,m,n))
  Gchapeu=b1%*%b2

  S=rbind(rep(1,m),diag(m))
  peso=S%*%Gchapeu
  # as previsoes imutaveis ficam no final
  previsoes1=c(previsoes[-(restricao+1)],previsoes[restricao+1])
  w01=c(w0[-(restricao+1)],w0[restricao+1])
  ajustada=peso%*%previsoes1/w01
  ajustada=ajustada[,1]

  # coloca na ordem
  posicao=seq(1,length(previsoes),1)
  ajustada1=ajustada
  ajustada1[posicao[-(restricao+1)]]=ajustada[1:(n-k)]
  ajustada1[posicao[restricao+1]]=ajustada[(n-k+1):n]
  names(ajustada1)=c("MES",names(semanais))
  return(ajustada1)
}

concilia<-function(dias,semanais,mes,feriados){

          # concilia previsoes mensais e semanais
          m=length(semanais) # numero de previsoes semanais
          n=m+1 # numero de previsoes semanais mais uma mensal
          feriados=feriados[1:length(semanais)]
		      feriados[which(feriados>=1)]=1
  	      if (length(which(is.na(feriados)))>0) feriados[which(is.na(feriados))]=0
          previsoes=c(mes,as.numeric(semanais))

          w0=c(sum(dias),dias)
          previsoes=previsoes*w0
          S=rbind(rep(1,m),diag(m))
          #W=diag(n)
    		  W=diag(c(50,(feriados*7+(1-feriados)*2)))
          G=solve(t(S)%*%solve(W)%*%S)%*%t(S)%*%solve(W)
          peso=S%*%G
          ajustada=peso%*%previsoes/w0
          ajustada=ajustada[,1]
          names(ajustada)=c("MES",names(semanais))
          return(ajustada)
}


#' combinaprev: forecast combination
#' @param baselearners list of objects generated by running different ForecastPMO models
#' @param tipoprevisao selects the type of forecasts to be combined.
#' \itemize{
#'   \item  `0`: combines the individual forecasts that have not been reconciled
#'   \item  `1`: 1 combines the individual forecasts that have been previously reconciled (final forecasts)
#' }
#' @param metcombina selects the method for combining forecasts.
#' \itemize{
#'   \item  `0`: median of the weekly forecasts and median of the monthly forecasts
#'   \item  `1`: mean of the weekly forecasts and mean of the monthly forecasts
#'   \item  `2`: weighted average of the forecasts using the inverse of the error variance (Bates and Granger
#'   \item  `3`: stacking with an SVM meta-model
#' }
#' @param conciliar Method for reconciling the combined forecasts
#' \strong{For REV0:}
#' \itemize{
#'   \item \code{0}: Adjusts the combined weekly forecasts for the first month
#'   so that their average equals the combined monthly forecast.
#'   \item \code{1}: Reconciles the combined forecasts using the Minimum Trace
#'   (MinT) method.
#'   \item \code{2}: Adjusts the combined monthly forecast for the first month
#'   so that it equals the average of the combined weekly forecasts.
#' }
#' \strong{For regular revisions:}
#' \itemize{
#'   \item \code{0}: Adjusts the combined monthly forecast for the current
#'   month so that it equals the average of the combined weekly forecasts.
#'   \item \code{1}: Reconciles the combined forecasts using the MinT method.
#' }
#'
#' @return combined and reconciled monthly and weekly forecasts
#'
#' @author
#' José Pessanha
#'
#' @export
combinaprev<-function(baselearners,tipoprevisao,metcombina,conciliar){
   # COMBINA PREVISOES
   # tipoprevisao = 1 previsoes individuais previamente conciliadas (previsoes finais)
   #              = 0 previsoes individuais nao conciliadas
   # metcombina = 0 mediana das previsoes semanais e mediana das previsoes mensais
   #            = 1 media das previsoes semanais e media das previsoes mensais
   #            = 2 media ponderada pelo inverso da variancia do erro (Bates e Granger)
   #            = 3 svm das previsoes semanais e mensais
   # conciliar  = se REV0: 0 ajusta a previsao combinada semanal para fechar a previsao combinada mensal
   #                       1 concilia previsoes combinadas pelo metodo MINT
   #                       2 ajusta previsao mensal combinada para fechar com as previsoes semanais combinadas
   #              se revisao ordinaria: 0 ajusta previsao mensal combinada para fechar com as previsoes semanais combinadas
   #                                    1 concilia previsoes combinadas pelo metodo MINT

   nmodelos=length(baselearners)
   nomes=nomesmes=c()
   for (i in 1:nmodelos){
       # HISTORICO SEMANAL
       if (length(grep("REGRESSAO DINAMICA",baselearners[[i]]$modelo_semanal))>0){
          datas=as.Date(baselearners[[i]]$serie_semanal$year_week)+6
          cargaobs=baselearners[[i]]$serie_semanal$carga_sem
          cargaprev=baselearners[[i]]$serie_semanal$.fitted
          nomes=c(nomes,paste("reg.din_",baselearners[[i]]$modelo_semanal,i,sep=""))
       }
       if (length(grep("SVM",baselearners[[i]]$modelo_semanal))>0){
          datas=as.Date(rownames(baselearners[[i]]$serie_semanal))
          cargaobs=baselearners[[i]]$serie_semanal$carga_sem
          cargaprev=baselearners[[i]]$serie_semanal$.fitted
          nomes=c(nomes,paste("SVM_",baselearners[[i]]$modelo_semanal,i,sep=""))
       }
       if (length(grep("HOLT-WINTERS",baselearners[[i]]$modelo_semanal))>0){
          datas=as.Date(baselearners[[i]]$serie_semanal$year_week)+6
          cargaobs=baselearners[[i]]$serie_semanal$carga_sem
          cargaprev=baselearners[[i]]$serie_semanal$.fitted
          nomes=c(nomes,paste("HW_",baselearners[[i]]$modelo_semanal,i,sep=""))
       }
       # HISTORICO MENSAL
       if (length(grep("REGRESSAO DINAMICA",baselearners[[i]]$modelo_mensal))>0){
          datasmes=baselearners[[i]]$serie_mensal$year_month
          cargaobsmes=baselearners[[i]]$serie_mensal$carga_mes
          cargaprevmes=baselearners[[i]]$serie_mensal$.fitted
          nomesmes=c(nomesmes,paste(baselearners[[i]]$modelo_semanal,"_",baselearners[[i]]$modelo_mensal,i,sep=""))
       }
       if (length(grep("SVM",baselearners[[i]]$modelo_mensal))>0){
          datasmes=yearmonth(rownames(baselearners[[i]]$serie_mensal))
          cargaobsmes=baselearners[[i]]$serie_mensal$carga_mes
          cargaprevmes=baselearners[[i]]$serie_mensal$.fitted
          nomesmes=c(nomesmes,paste(baselearners[[i]]$modelo_semanal,"_",baselearners[[i]]$modelo_mensal,i,sep=""))
       }
       if (length(grep("HOLT-WINTERS",baselearners[[i]]$modelo_mensal))>0){
          datasmes=baselearners[[i]]$serie_mensal$year_month
          cargaobsmes=baselearners[[i]]$serie_mensal$carga_mes
          cargaprevmes=baselearners[[i]]$serie_mensal$.fitted
          nomesmes=c(nomesmes,paste(baselearners[[i]]$modelo_semanal,"_",baselearners[[i]]$modelo_mensal,i,sep=""))
       }
       if (length(grep("SARIMA",baselearners[[i]]$modelo_mensal))>0){
          datasmes=baselearners[[i]]$serie_mensal$year_month
          cargaobsmes=baselearners[[i]]$serie_mensal$carga_mes
          cargaprevmes=baselearners[[i]]$serie_mensal$.fitted
          nomesmes=c(nomesmes,paste(baselearners[[i]]$modelo_semanal,"_",baselearners[[i]]$modelo_mensal,i,sep=""))
       }
       # PREVISOES
       if (i==1) {
          # semana
          aux=as_tibble(data.frame(datas,cargaobs,cargaprev))
          matriz=aux
          if (tipoprevisao==0) prevsem=baselearners[[i]]$PREVISOES_SEMANAIS_ANTES$PREV.SEMANAIS$previsoes
          if (tipoprevisao==1) prevsem=baselearners[[i]]$previsao_semanal
          # mes
          auxmes=as_tibble(data.frame(datasmes,cargaobsmes,cargaprevmes))
          matrizmes=auxmes
          if (tipoprevisao==0) prevmes=baselearners[[i]]$PREVISOES_MENSAIS_ANTES
          if (tipoprevisao==1) prevmes=baselearners[[i]]$previsao_mensal
       }else{
          # semana
          aux=as_tibble(data.frame(datas,cargaprev))
          matriz=inner_join(matriz,aux,by="datas")
          if (tipoprevisao==0) prevsem=cbind(prevsem,baselearners[[i]]$PREVISOES_SEMANAIS_ANTES$PREV.SEMANAIS$previsoes)
          if (tipoprevisao==1) prevsem=cbind(prevsem,baselearners[[i]]$previsao_semanal)
          # mes
          auxmes=as_tibble(data.frame(datasmes,cargaprevmes))
          matrizmes=inner_join(matrizmes,auxmes,by="datasmes")
          if (tipoprevisao==0) prevmes=cbind(prevmes,baselearners[[i]]$PREVISOES_MENSAIS_ANTES)
          if (tipoprevisao==1) prevmes=cbind(prevmes,baselearners[[i]]$previsao_mensal)
       }
   }
   colnames(prevsem)=nomes
   colnames(prevmes)=nomesmes

   if (tipoprevisao==0){
       # se considera previsoes individuais antes da conciliacao
       ZZ=prevsem
       aux=c()
       for (j in 1:nmodelos){
           aux=c(aux,baselearners[[i]]$previsao_semanal[1])
       }
       ZZ=rbind(as.numeric(aux),ZZ)
       rownames(ZZ)=NULL
       ZZ=data.frame(ZZ)
       rownames(ZZ)=names(baselearners[[1]]$previsao_semanal)
       prevsem=ZZ
   }

   if (baselearners[[1]]$tipo_estudo=="REV0 do PMO" & tipoprevisao==0){
      # se REV0 tem que incluir a previsao para o mes vigente
      ZZ=prevmes
      aux=c()
      for (j in 1:nmodelos){
          aux=c(aux,baselearners[[i]]$previsao_mensal[1])
      }
      ZZ=rbind(as.numeric(aux),ZZ)
      rownames(ZZ)=NULL
      ZZ=data.frame(ZZ)
      rownames(ZZ)=names(baselearners[[1]]$previsao_mensal)
      prevmes=ZZ
   }

   mediana<-function(x){quantile(x,0.5)}
   if (metcombina==0){
      # combina previsoes pela mediana
      prevcombsem=apply(prevsem,1,mediana) # mediana das previsoes semanais
      prevcombmes=apply(prevmes,1,mediana) # mediana das previsoes mensais
   }
   if (metcombina==1){
      # combina previsoes pela media
      prevcombsem=apply(prevsem,1,mean) # media das previsoes semanais
      prevcombmes=apply(prevmes,1,mean) # media das previsoes mensais
   }
   if (metcombina==2){
      # media ponderada pelo inverso da variancia do erro (Bates e Granger)
      pesos=c()
      pesosmes=c()
      for (j in 1:nmodelos){
          coluna=2+j
          desvios=data.frame(matriz[,2]-matriz[,coluna])$cargaobs
          pesos=c(pesos,1/var(desvios))
          desvios=data.frame(matrizmes[,2]-matrizmes[,coluna])$cargaobs
          pesosmes=c(pesosmes,1/var(desvios))
      }
      pesos=pesos/sum(pesos)
      pesosmes=pesosmes/sum(pesosmes)
      prevcombsem=(as.matrix(prevsem,dim(prevsem)[1],dim(prevsem)[2])%*%pesos)[,1]
      prevcombmes=(as.matrix(prevmes,dim(prevmes)[1],dim(prevmes)[2])%*%pesosmes)[,1]
   }
   # HISTORICO DAS SEMANAS
   nomes=c("datas","carga_obs",nomes)
   names(matriz)=nomes
   # HISTORICO DOS MESES
   nomesmes=c("datas","carga_obs",nomesmes)
   names(matrizmes)=nomesmes

   if (metcombina==3){
      # combina por svm treinado a partir do historico
      # SEMANAS
      #nomes=c("datas","carga_obs",nomes)
      #names(matriz)=nomes
      # MESES
      #nomesmes=c("datas","carga_obs",nomesmes)
      #names(matrizmes)=nomesmes

      ###################
      # combina semanas #
      ###################
      Y=matriz[,2] # coluna com carga observada
      X=matriz[,-2] # deixa apenas as colunas com previsoes semanais da carga
      XX=as.matrix(X[,-1])
      YY=as.matrix(Y)
      YY=YY[,1]
      dadossvm=data.frame(YY,XX)
      modelosvm = svm(YY~.,data=dadossvm)

	    #aux_sigmoide=tune(svm, YY ~., data = dadossvm,ranges = list(kernel=c("sigmoid"),cost = c(1,10)))
   	  #aux_radial=tune(svm, YY ~., data = dadossvm,ranges = list(kernel=c("radial"),cost = c(1,10),gamma=c(0.1,1)))
      #aux_linear=tune(svm, YY ~., data = dadossvm,ranges = list(kernel=c("linear"),cost = c(1,10)))
      #if (aux_linear$best.performance <= aux_sigmoide$best.performance) modelosvm=aux_linear
  	  #if (aux_linear$best.performance > aux_sigmoide$best.performance) modelosvm=aux_sigmoide
	    #if ((aux_linear$best.performance <= aux_sigmoide$best.performance) & (aux_linear$best.performance <= aux_radial$best.performance)) modelosvm=aux_linear
	    #if ((aux_radial$best.performance <= aux_sigmoide$best.performance) & (aux_radial$best.performance <= aux_linear$best.performance)) modelosvm=aux_radial
	    #if ((aux_sigmoide$best.performance <= aux_linear$best.performance) & (aux_sigmoide$best.performance <= aux_radial$best.performance)) modelosvm=aux_sigmoide
	    #modelosvm=modelosvm$best.model

      # previsao semanal combinada
      ZZ=prevsem
      rownames(ZZ)=NULL
      ZZ=data.frame(ZZ)
      prevcombsem=predict(modelosvm,newdata=ZZ)
      names(prevcombsem)=names(baselearners[[1]]$previsao_semanal)

      #################
      # combina meses #
      #################
      Y=matrizmes[,2] # coluna com carga observada
      X=matrizmes[,-2] # mantem apenas as cargas previstas
      XX=as.matrix(X[,-1])
      YY=as.matrix(Y)
      YY=YY[,1]
      dadossvm=data.frame(YY,XX)
      modelosvm = svm(YY~.,data=dadossvm,kernel="linear")
      # previsao mensal combinada
      ZZ=prevmes
      rownames(ZZ)=NULL
      ZZ=data.frame(ZZ)
      prevcombmes=predict(modelosvm,newdata=ZZ)
      names(prevcombmes)=names(baselearners[[1]]$previsao_mensal)
   }

   # conciliacao das previsoes
   if (baselearners[[1]]$tipo_estudo!="revisao semanal do PMO"){
     # REV0
     # identifica previsao mensal a ser conciliada
     carga=baselearners[[1]]$primeiro_mes_aberto # pode pegar qualquer modelo base, pegou o primeiro para ter a estrutura
     indice=grep(tail(rownames(carga),1),names(prevcombmes))
     prevmes_antes_ajuste=prevcombmes[indice]
     # identifica previsoes semanais a serem conciliadas
     datas_prev_sem=names(prevcombsem) # datas das previsoes combinadas
     mm=dim(baselearners[[1]]$primeiro_mes_aberto)[1]-1
     indice=which((as.Date(datas_prev_sem)>=rownames(baselearners[[1]]$primeiro_mes_aberto)[1] & as.Date(datas_prev_sem)<=rownames(baselearners[[1]]$primeiro_mes_aberto)[mm]) | ((as.Date(datas_prev_sem)-6)>=rownames(baselearners[[1]]$primeiro_mes_aberto)[1] & (as.Date(datas_prev_sem)-6)<=rownames(baselearners[[1]]$primeiro_mes_aberto)[mm]))
     # 2026 indice=which(as.Date(datas_prev_sem)>=rownames(baselearners[[1]]$primeiro_mes_aberto)[1] & as.Date(datas_prev_sem)<=rownames(baselearners[[1]]$primeiro_mes_aberto)[mm])
     prevsem_antes_ajuste=prevcombsem[indice]

     # identifica numero de dias em cada semana no primeiro mes
     #indice=which(rownames(baselearners[[1]]$primeiro_mes_aberto)>=as.Date(datas_prev_sem)[1])
     datas0=as.Date(datas_prev_sem[indice])
     aux <- as.Date(datas0[1])
     inicio_mes <- floor_date(aux, "month")
     fim_mes <- ceiling_date(aux, "month") - days(1)
     resultado <- tibble(data_fim = datas0) |>
        mutate(
          data_inicio = data_fim - days(6),
          inicio = pmax(data_inicio, inicio_mes),
          fim = pmin(data_fim, fim_mes),
          dias = pmax(0, as.integer(fim - inicio) + 1)
        ) |>
        filter(dias > 0) |>
        group_by(data_fim) |>
        summarise(dias = sum(dias), .groups = "drop")
     dias=resultado$dias
     #dias=carga$Dias[-dim(carga)[1]]

     # concilia previsoes , previsao mensal seguida das previsoes semanais
	   if (conciliar==0){
	      fator=as.numeric(prevmes_antes_ajuste/((prevsem_antes_ajuste%*%dias)/sum(dias)))
		    conciliada=c(prevmes_antes_ajuste,fator*prevsem_antes_ajuste)
	   }
     if (conciliar==1) conciliada=concilia_baselearners(dias,prevsem_antes_ajuste,prevmes_antes_ajuste,baselearners[[1]]$lista_feriados_semanais)
	   if (conciliar==2) conciliada=c((prevsem_antes_ajuste%*%dias)/sum(dias),prevsem_antes_ajuste)
     #names(conciliada)[2:(2+mm-1)]=rownames(baselearners[[1]]$primeiro_mes_aberto)[1:mm]

     # substitui as previsoes conciliadas nos objetos de saida
     saidao=baselearners[[1]]
     indice_mes=grep(tail(rownames(saidao$primeiro_mes_aberto),1),names(saidao$previsao_mensal))
	   saidao$previsao_mensal=prevcombmes
     saidao$previsao_mensal[indice_mes]=conciliada[1]
     #aux=names(conciliada)[1+indice]
     aux=names(conciliada)[-1]
	   saidao$previsao_semanal=prevcombsem
     datas=names(saidao$previsao_semanal)
     for (i in 1:length(aux)){
         #saidao$previsao_semanal[min(which(aux[i]<=datas))]=as.numeric(conciliada[1+indice][i])
         saidao$previsao_semanal[min(which(aux[i]<=datas))]=as.numeric(conciliada[-1][i])
     }
     saidao$primeiro_mes_aberto<- NULL
   } else {
     # REVISOES ORDINARIAS
     # identifica previsao mensal a ser conciliada
     carga=baselearners[[1]]$primeiro_mes_aberto
     indice=grep(tail(rownames(carga),1),names(prevcombmes))
     prevmes_antes_ajuste=prevcombmes[indice]
     # identifica previsoes semanais a serem conciliadas
     datas_prev_sem=names(prevcombsem) # datas das previsoes combinadas
     mm=dim(baselearners[[1]]$primeiro_mes_aberto)[1]-1
     indice=which((as.Date(datas_prev_sem)>=rownames(baselearners[[1]]$primeiro_mes_aberto)[1] & as.Date(datas_prev_sem)<=rownames(baselearners[[1]]$primeiro_mes_aberto)[mm]) | ((as.Date(datas_prev_sem)-6)>=rownames(baselearners[[1]]$primeiro_mes_aberto)[1] & (as.Date(datas_prev_sem)-6)<=rownames(baselearners[[1]]$primeiro_mes_aberto)[mm]))
     # 2026 indice=which(as.Date(datas_prev_sem)>=rownames(baselearners[[1]]$primeiro_mes_aberto)[1] & as.Date(datas_prev_sem)<=rownames(baselearners[[1]]$primeiro_mes_aberto)[mm])
     prevsem_antes_ajuste=prevcombsem[indice]
     # identifica numero de dias em cada semana no primeiro mes
     indice=which(rownames(baselearners[[1]]$primeiro_mes_aberto)>as.Date(datas_prev_sem)[1])
     carga$MW[indice]=as.numeric(prevsem_antes_ajuste)[-1] # MUDEI AQUI
     # 2026 carga$MW[indice]=as.numeric(prevsem_antes_ajuste)
     prevsem_antes_ajuste=carga$MW[-dim(carga)[1]]
     dias=carga$Dias[-dim(carga)[1]]
     restricao=which(carga$Dias==1)
     # concilia previsoes
	   if (conciliar!=1) conciliada=c((prevsem_antes_ajuste%*%dias)/sum(dias),prevsem_antes_ajuste)
     if (conciliar==1) conciliada=concilia_com_retricao(dias,prevsem_antes_ajuste,prevmes_antes_ajuste,restricao,baselearners[[1]]$lista_feriados_semanais)
     names(conciliada)[2:(2+mm-1)]=rownames(baselearners[[1]]$primeiro_mes_aberto)[1:mm]
     # substitui nos objetos de saida
     saidao=baselearners[[1]]
     saidao$primeiro_mes_aberto[dim(carga)[1],1]=conciliada[1]
     saidao$primeiro_mes_aberto[indice,1]=conciliada[1+indice]
	   saidao$previsao_mensal=prevcombmes
     saidao$previsao_mensal[1]=conciliada[1]
     aux=names(conciliada)[1+indice]
	   saidao$previsao_semanal=prevcombsem
     datas=names(saidao$previsao_semanal)
     for (i in 1:length(aux)){
         saidao$previsao_semanal[min(which(aux[i]<=datas))]=as.numeric(conciliada[1+indice][i])
     }
   }

   #combinadas<-list(hist_baselearners_semanais=matriz,hist_baselearners_mensais=matrizmes,prev_baselearners_semanais=prevsem,prev_baselearners_mensais=prevmes,prev_comb_sem_ANTES_CONCILIA=prevcombsem,prev_comb_mes_ANTES_CONCILIA=prevcombmes,primeiro_mes_aberto=saidao$primeiro_mes_aberto,previsao_semanal=saidao$previsao_semanal,previsao_mensal=saidao$previsao_mensal)
   combinadas<-list(hist_baselearners_semanais=matriz,hist_baselearners_mensais=matrizmes,prev_baselearners_semanais=prevsem,prev_baselearners_mensais=prevmes,prev_comb_sem_ANTES_CONCILIA=prevcombsem,prev_comb_mes_ANTES_CONCILIA=prevcombmes,previsao_semanal=saidao$previsao_semanal,previsao_mensal=saidao$previsao_mensal)

   return(combinadas)
}

concilia_baselearners<-function(dias,semanais,mes,feriados){

  #datas0=as.Date(names(semanais))
  #aux <- as.Date(datas0[1])
  #inicio_mes <- floor_date(aux, "month")
  #fim_mes <- ceiling_date(aux, "month") - days(1)
  #resultado <- tibble(data_fim = datas0) |>
  #             mutate(
  #                data_inicio = data_fim - days(6),
  #                inicio = pmax(data_inicio, inicio_mes),
  #                fim = pmin(data_fim, fim_mes),
  #                dias = pmax(0, as.integer(fim - inicio) + 1)
  #             ) |>
  #             filter(dias > 0) |>
  #             group_by(data_fim) |>
  #             summarise(dias = sum(dias), .groups = "drop")
  #dias=resultado$dias

  # concilia previsoes mensais e semanais
  m=length(semanais) # numero de previsoes semanais
  n=m+1 # numero de previsoes semanais mais uma mensal
  feriados=feriados[1:length(semanais)]
  feriados[which(feriados>=1)]=1
  if (length(which(is.na(feriados)))>0) feriados[which(is.na(feriados))]=0
  previsoes=c(mes,as.numeric(semanais))

  w0=c(sum(dias),dias)
  previsoes=previsoes*w0
  S=rbind(rep(1,m),diag(m))
  #W=diag(n)
  W=diag(c(50,(feriados*7+(1-feriados)*2)))
  G=solve(t(S)%*%solve(W)%*%S)%*%t(S)%*%solve(W)
  peso=S%*%G
  ajustada=peso%*%previsoes/w0
  ajustada=ajustada[,1]
  names(ajustada)=c("MES",names(semanais[1:length(dias)]))
  return(ajustada)
}
